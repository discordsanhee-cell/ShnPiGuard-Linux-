/*
    SnhGuard 기본 YARA 룰 세트 (시작용)
    실제 배포 전에는 최신 공개 YARA 룰셋(예: YARA-Rules 프로젝트 등)을 추가로 병합해서 쓰는 걸 추천합니다.
*/

rule Suspicious_PowerShell_Encoded_Command
{
    meta:
        description = "인코딩된 PowerShell 명령 실행 패턴"
        severity = "medium"
    strings:
        $enc1 = "-EncodedCommand" nocase
        $enc2 = "-enc " nocase
        $bypass = "-ExecutionPolicy Bypass" nocase
    condition:
        any of them
}

rule Suspicious_Double_Extension
{
    meta:
        description = "이중 확장자로 실행파일을 문서처럼 위장 (예: invoice.pdf.exe)"
        severity = "high"
    strings:
        $pdf_exe = ".pdf.exe" nocase
        $doc_exe = ".doc.exe" nocase
        $jpg_exe = ".jpg.exe" nocase
        $xls_exe = ".xls.exe" nocase
    condition:
        any of them
}

rule PE_With_Suspicious_Imports
{
    meta:
        description = "키로깅/인젝션에 흔히 쓰이는 API 조합"
        severity = "high"
    strings:
        $mz = { 4D 5A }
        $api1 = "SetWindowsHookExA"
        $api2 = "GetAsyncKeyState"
        $api3 = "VirtualAllocEx"
        $api4 = "WriteProcessMemory"
        $api5 = "CreateRemoteThread"
    condition:
        $mz at 0 and 2 of ($api1, $api2, $api3, $api4, $api5)
}

rule Possible_Ransomware_Note
{
    meta:
        description = "랜섬웨어 협박 메모 텍스트 패턴"
        severity = "critical"
    strings:
        $s1 = "your files have been encrypted" nocase
        $s2 = "decrypt your files" nocase wide ascii
        $s3 = "bitcoin wallet" nocase
        $s4 = "pay the ransom" nocase
    condition:
        2 of them
}

rule Suspicious_Startup_Persistence_Script
{
    meta:
        description = "레지스트리 Run 키/스케줄러 등록을 시도하는 스크립트"
        severity = "medium"
    strings:
        $reg1 = "CurrentVersion\\Run" nocase
        $sched = "schtasks" nocase
        $s1 = "reg add" nocase
    condition:
        any of them
}
