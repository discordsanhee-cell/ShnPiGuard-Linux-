"""
SnhGuard (Windows) - 트레이 아이콘
pystray로 상태 표시 + 우클릭 메뉴(수동 검사, 격리소 열기, 종료) 제공.
"""
import threading
import logging

import pystray
from PIL import Image, ImageDraw

from config import DEFAULT_WATCH_DIRS, QUARANTINE_DIR
from scanner import scan_directory
from quarantine import list_quarantine
from watcher import start_watching

logger = logging.getLogger("SnhGuard.tray")

_detected_count = 0


def _make_icon_image(color="#2ecc71"):
    img = Image.new("RGB", (64, 64), "white")
    d = ImageDraw.Draw(img)
    d.ellipse((8, 8, 56, 56), fill=color)
    d.text((22, 24), "S", fill="white")
    return img


def _run_full_scan(icon, item):
    global _detected_count
    icon.notify("전체 검사를 시작합니다...", "SnhGuard")
    total_detected = 0
    for d in DEFAULT_WATCH_DIRS:
        results = scan_directory(d)
        total_detected += sum(1 for r in results if r["detected"])
    _detected_count = total_detected
    icon.icon = _make_icon_image("#e74c3c" if total_detected else "#2ecc71")
    icon.notify(f"검사 완료 - {total_detected}개 탐지 및 격리됨", "SnhGuard")


def _open_quarantine(icon, item):
    import os
    os.startfile(QUARANTINE_DIR)


def _show_status(icon, item):
    q = list_quarantine()
    icon.notify(f"현재 격리소에 {len(q)}개 항목 있음", "SnhGuard 상태")


def _quit(icon, item):
    icon.stop()


def run_tray():
    icon = pystray.Icon(
        "SnhGuard",
        _make_icon_image(),
        "SnhGuard - 실행 중",
        menu=pystray.Menu(
            pystray.MenuItem("지금 전체 검사", _run_full_scan),
            pystray.MenuItem("상태 확인", _show_status),
            pystray.MenuItem("격리소 열기", _open_quarantine),
            pystray.MenuItem("종료", _quit),
        ),
    )

    # 백그라운드 스레드에서 실시간 감시 시작
    watch_thread = threading.Thread(target=start_watching, kwargs={"blocking": True}, daemon=True)
    watch_thread.start()

    icon.run()
