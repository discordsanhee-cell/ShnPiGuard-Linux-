# SnhGuard (Windows) 설치 스크립트
# 관리자 권한 PowerShell에서 실행: powershell -ExecutionPolicy Bypass -File install.ps1

Write-Host "=== SnhGuard Windows 설치 시작 ===" -ForegroundColor Cyan

$InstallDir = "$env:ProgramFiles\SnhGuard"
$LocalDataDir = "$env:LOCALAPPDATA\SnhGuard"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# 1) Python 설치 확인
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Host "Python이 설치되어 있지 않습니다. https://www.python.org 에서 먼저 설치해주세요." -ForegroundColor Red
    exit 1
}

# 2) 프로그램 파일 복사
Write-Host "프로그램 파일을 $InstallDir 로 복사합니다..."
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
Copy-Item -Path "$ScriptDir\*.py" -Destination $InstallDir -Force
New-Item -ItemType Directory -Force -Path "$LocalDataDir\rules" | Out-Null
Copy-Item -Path "$ScriptDir\rules\*.yar" -Destination "$LocalDataDir\rules" -Force

# 3) 파이썬 패키지 설치
Write-Host "파이썬 패키지를 설치합니다 (yara-python, watchdog, pystray, Pillow, pywin32)..."
python -m pip install --upgrade pip | Out-Null
python -m pip install -r "$ScriptDir\requirements.txt"

# 4) ClamAV 안내 (보조 엔진, 선택사항)
$clamPath = "C:\Program Files\ClamAV\clamscan.exe"
if (-not (Test-Path $clamPath)) {
    Write-Host ""
    Write-Host "[참고] ClamAV(보조 엔진)가 설치되어 있지 않습니다." -ForegroundColor Yellow
    Write-Host "필수는 아니지만(YARA가 메인 엔진) 설치하면 더 좋습니다: https://www.clamav.net/downloads" -ForegroundColor Yellow
    Write-Host ""
}

# 5) 작업 스케줄러에 로그온 시 자동 실행 등록
Write-Host "로그온 시 자동 실행을 등록합니다..."
$TaskName = "SnhGuard-AutoStart"
$Action = New-ScheduledTaskAction -Execute "pythonw.exe" -Argument "`"$InstallDir\main.py`""
$Trigger = New-ScheduledTaskTrigger -AtLogOn
$Principal = New-ScheduledTaskPrincipal -UserId "$env:USERNAME" -RunLevel Highest
$Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Principal $Principal -Settings $Settings | Out-Null

Write-Host ""
Write-Host "=== 설치 완료 ===" -ForegroundColor Green
Write-Host "다음 로그온부터 자동으로 실행됩니다. 지금 바로 실행하려면:"
Write-Host "  pythonw `"$InstallDir\main.py`""
