"""
SnhGuard (Windows) - 진입점
"""
import logging

from config import LOG_FILE
from scanner import load_rules
from tray import run_tray


def setup_logging():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
        handlers=[
            logging.FileHandler(LOG_FILE, encoding="utf-8"),
            logging.StreamHandler(),
        ],
    )


def main():
    setup_logging()
    logging.getLogger("SnhGuard.main").info("SnhGuard 시작")
    load_rules()
    run_tray()


if __name__ == "__main__":
    main()
