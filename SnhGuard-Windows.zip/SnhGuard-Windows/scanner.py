"""
SnhGuard (Windows) - 스캔 엔진
1차: YARA 룰 매칭 (메인 엔진)
2차: ClamAV clamscan (보조 엔진, YARA에서 안 걸린 파일 대상)
"""
import os
import glob
import logging
import subprocess

import yara

from config import RULES_DIR, CLAMSCAN_PATH
from quarantine import quarantine_file

logger = logging.getLogger("SnhGuard.scanner")

_compiled_rules = None


def load_rules():
    """rules/ 폴더의 모든 .yar 파일을 컴파일."""
    global _compiled_rules
    rule_files = glob.glob(os.path.join(RULES_DIR, "*.yar"))
    if not rule_files:
        logger.warning("YARA 룰 파일이 없습니다. rules/ 폴더를 확인하세요.")
        _compiled_rules = None
        return

    filepaths = {os.path.splitext(os.path.basename(p))[0]: p for p in rule_files}
    try:
        _compiled_rules = yara.compile(filepaths=filepaths)
        logger.info(f"YARA 룰 {len(filepaths)}개 로드 완료")
    except yara.SyntaxError as e:
        logger.error(f"YARA 룰 컴파일 실패: {e}")
        _compiled_rules = None


def scan_file_yara(filepath: str):
    """단일 파일을 YARA로 스캔. 매치된 룰 이름 리스트 반환."""
    if _compiled_rules is None:
        load_rules()
    if _compiled_rules is None:
        return []

    try:
        matches = _compiled_rules.match(filepath, timeout=30)
        return [m.rule for m in matches]
    except yara.Error as e:
        logger.warning(f"YARA 스캔 실패 ({filepath}): {e}")
        return []


def scan_file_clamav(filepath: str) -> bool:
    """ClamAV clamscan으로 보조 스캔. 탐지되면 True."""
    if not os.path.exists(CLAMSCAN_PATH):
        logger.debug("ClamAV가 설치되어 있지 않아 보조 스캔을 건너뜁니다.")
        return False
    try:
        result = subprocess.run(
            [CLAMSCAN_PATH, "--no-summary", filepath],
            capture_output=True, text=True, timeout=60
        )
        # clamscan 종료 코드: 0=정상, 1=탐지됨, 2=오류
        return result.returncode == 1
    except Exception as e:
        logger.warning(f"ClamAV 스캔 실패 ({filepath}): {e}")
        return False


def scan_and_handle(filepath: str, auto_quarantine: bool = True):
    """
    파일 하나를 YARA -> (안 걸리면) ClamAV 순으로 검사하고
    탐지 시 자동 격리. 결과 dict 반환.
    """
    if not os.path.isfile(filepath):
        return {"path": filepath, "detected": False, "engine": None}

    yara_hits = scan_file_yara(filepath)
    if yara_hits:
        reason = f"YARA: {', '.join(yara_hits)}"
        if auto_quarantine:
            quarantine_file(filepath, reason=reason)
        logger.warning(f"[탐지] {filepath} - {reason}")
        return {"path": filepath, "detected": True, "engine": "YARA", "rules": yara_hits}

    if scan_file_clamav(filepath):
        reason = "ClamAV 보조 엔진 탐지"
        if auto_quarantine:
            quarantine_file(filepath, reason=reason)
        logger.warning(f"[탐지] {filepath} - {reason}")
        return {"path": filepath, "detected": True, "engine": "ClamAV"}

    return {"path": filepath, "detected": False, "engine": None}


def scan_directory(directory: str, auto_quarantine: bool = True):
    """폴더 전체를 재귀적으로 스캔."""
    results = []
    for root, _, files in os.walk(directory):
        for name in files:
            fp = os.path.join(root, name)
            results.append(scan_and_handle(fp, auto_quarantine=auto_quarantine))
    return results
