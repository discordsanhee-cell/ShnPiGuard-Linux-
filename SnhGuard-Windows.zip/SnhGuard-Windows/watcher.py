"""
SnhGuard (Windows) - 실시간 감시
watchdog 라이브러리로 지정 폴더의 새 파일/수정 파일을 감지해서 즉시 스캔.
(Linux의 inotify 대신 Windows에서는 ReadDirectoryChangesW를 내부적으로 사용)
"""
import time
import logging

from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

from config import DEFAULT_WATCH_DIRS
from scanner import scan_and_handle

logger = logging.getLogger("SnhGuard.watcher")


class SnhGuardEventHandler(FileSystemEventHandler):
    def on_created(self, event):
        if not event.is_directory:
            self._scan_later(event.src_path)

    def on_modified(self, event):
        if not event.is_directory:
            self._scan_later(event.src_path)

    def _scan_later(self, path):
        # 파일이 완전히 쓰여질 시간을 잠깐 준다
        time.sleep(1.5)
        try:
            result = scan_and_handle(path)
            if result["detected"]:
                logger.warning(f"실시간 감시 - 위협 탐지 및 격리: {path}")
        except FileNotFoundError:
            pass  # 임시파일 등으로 이미 사라진 경우


def start_watching(paths=None, blocking=True):
    """지정 폴더들에 대해 실시간 감시 시작."""
    paths = paths or DEFAULT_WATCH_DIRS
    observer = Observer()
    handler = SnhGuardEventHandler()

    for p in paths:
        observer.schedule(handler, p, recursive=True)
        logger.info(f"실시간 감시 시작: {p}")

    observer.start()
    if not blocking:
        return observer

    try:
        while True:
            time.sleep(2)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
    return observer
