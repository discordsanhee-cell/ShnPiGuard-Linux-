"""
SnhGuard (Windows) - 격리소 관리
탐지된 파일을 변조(XOR)해서 실행 불가능한 형태로 저장하고,
복원 및 영구 삭제(덮어쓰기 후 삭제)를 지원.
"""
import os
import json
import time
import uuid
import random
import logging

from config import QUARANTINE_DIR, QUARANTINE_XOR_KEY, SECURE_DELETE_PASSES

logger = logging.getLogger("SnhGuard.quarantine")

INDEX_FILE = os.path.join(QUARANTINE_DIR, "index.json")


def _load_index():
    if os.path.exists(INDEX_FILE):
        try:
            with open(INDEX_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def _save_index(index):
    with open(INDEX_FILE, "w", encoding="utf-8") as f:
        json.dump(index, f, ensure_ascii=False, indent=2)


def _xor_bytes(data: bytes, key: int = QUARANTINE_XOR_KEY) -> bytes:
    return bytes(b ^ key for b in data)


def quarantine_file(filepath: str, reason: str = "YARA/ClamAV 탐지") -> str:
    """탐지된 파일을 변조 후 격리소로 이동. 격리 ID를 반환."""
    if not os.path.exists(filepath):
        raise FileNotFoundError(filepath)

    qid = uuid.uuid4().hex
    dest_path = os.path.join(QUARANTINE_DIR, qid + ".quar")

    with open(filepath, "rb") as f:
        data = f.read()
    obfuscated = _xor_bytes(data)

    with open(dest_path, "wb") as f:
        f.write(obfuscated)

    # 원본 안전 삭제
    secure_delete(filepath)

    index = _load_index()
    index[qid] = {
        "original_path": filepath,
        "quarantined_at": time.time(),
        "reason": reason,
        "size": len(data),
    }
    _save_index(index)
    logger.info(f"격리 완료: {filepath} -> {qid} ({reason})")
    return qid


def restore_file(qid: str, restore_to: str = None) -> str:
    """격리된 파일을 원본 위치(또는 지정 경로)로 복원."""
    index = _load_index()
    if qid not in index:
        raise KeyError(f"격리 항목 없음: {qid}")

    entry = index[qid]
    src_path = os.path.join(QUARANTINE_DIR, qid + ".quar")
    target = restore_to or entry["original_path"]

    with open(src_path, "rb") as f:
        obfuscated = f.read()
    data = _xor_bytes(obfuscated)

    os.makedirs(os.path.dirname(target), exist_ok=True)
    with open(target, "wb") as f:
        f.write(data)

    secure_delete(src_path)
    del index[qid]
    _save_index(index)
    logger.info(f"복원 완료: {qid} -> {target}")
    return target


def delete_permanently(qid: str):
    """격리된 파일을 영구 삭제 (덮어쓰기 후 삭제)."""
    index = _load_index()
    if qid not in index:
        raise KeyError(f"격리 항목 없음: {qid}")

    path = os.path.join(QUARANTINE_DIR, qid + ".quar")
    secure_delete(path)
    del index[qid]
    _save_index(index)
    logger.info(f"영구 삭제 완료: {qid}")


def secure_delete(path: str, passes: int = SECURE_DELETE_PASSES):
    """파일을 무작위 데이터로 여러 번 덮어쓴 뒤 삭제."""
    if not os.path.exists(path):
        return
    length = os.path.getsize(path)
    try:
        with open(path, "r+b") as f:
            for _ in range(passes):
                f.seek(0)
                f.write(os.urandom(length))
                f.flush()
                os.fsync(f.fileno())
    except Exception as e:
        logger.warning(f"덮어쓰기 실패, 바로 삭제 시도: {e}")
    finally:
        os.remove(path)


def list_quarantine():
    """격리소 목록 반환."""
    return _load_index()
