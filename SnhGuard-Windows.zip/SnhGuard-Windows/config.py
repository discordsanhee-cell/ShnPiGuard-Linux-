"""
SnhGuard (Windows) - 공통 설정
"""
import os

APP_NAME = "SnhGuard"

# %LOCALAPPDATA%\SnhGuard 아래에 모든 데이터 보관
BASE_DIR = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), APP_NAME)

RULES_DIR = os.path.join(BASE_DIR, "rules")
QUARANTINE_DIR = os.path.join(BASE_DIR, "quarantine")
LOG_DIR = os.path.join(BASE_DIR, "logs")
LOG_FILE = os.path.join(LOG_DIR, "snhguard.log")

# 감시할 기본 폴더 (다운로드, 바탕화면, USB 드라이브는 watcher가 동적으로 추가)
DEFAULT_WATCH_DIRS = [
    os.path.join(os.path.expanduser("~"), "Downloads"),
    os.path.join(os.path.expanduser("~"), "Desktop"),
]

# ClamAV for Windows 설치 경로 (기본 설치 시 이 경로)
CLAMSCAN_PATH = r"C:\Program Files\ClamAV\clamscan.exe"
FRESHCLAM_PATH = r"C:\Program Files\ClamAV\freshclam.exe"

# 격리 파일 변조(간단 XOR) 키 - 실제 배포 시 무작위 생성 후 안전하게 보관 권장
QUARANTINE_XOR_KEY = 0xA5

# 영구 삭제 시 덮어쓰기 횟수
SECURE_DELETE_PASSES = 3

for d in (BASE_DIR, RULES_DIR, QUARANTINE_DIR, LOG_DIR):
    os.makedirs(d, exist_ok=True)
