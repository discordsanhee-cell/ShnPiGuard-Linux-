#!/usr/bin/env bash
#
# SnhPiGuard-install.sh - 4중 엔진 (YARA + ClamAV 실시간 / rkhunter + Maldet 정기점검) 설치 스크립트
#
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
    echo "[!] root 권한이 필요합니다: sudo ./SnhPiGuard-install.sh"
    exit 1
fi

REAL_USER="${SUDO_USER:-$(whoami)}"
REAL_HOME=$(getent passwd "$REAL_USER" | cut -d: -f6)
INSTALL_DIR="/opt/snhpiguard"
YARA_RULES_DIR="${INSTALL_DIR}/yara_rules"
AUTOSTART_TRAY_FILE="${REAL_HOME}/.config/autostart/snhpiguard-tray.desktop"
DESKTOP_SHORTCUT_FILE="${REAL_HOME}/Desktop/SnhPiGuard.desktop"

echo "=== 1/9: 필수 패키지 및 YARA 설치 ==="
apt-get update
apt-get install -y clamav clamav-daemon clamav-freshclam python3-tk python3-pip \
    yara git curl libnotify-bin python3-pil python3-xlib

# --- 트레이 아이콘용 패키지 ---------------------------------------------------
#  python3-gi, gir1.2-gtk-3.0       : GTK 바인딩
#  gir1.2-ayatanaappindicator3-0.1  : AppIndicator(StatusNotifier). Wayland 에서 트레이 아이콘이 보이려면
#                                     반드시 필요하다 (없으면 pystray 가 화면에 안 보이는 백엔드로 떨어짐)
#  libglib2.0-bin                   : gdbus (트레이 호스트 진단용)
# 트레이는 부가 기능이므로 설치에 실패해도 백신 설치는 계속 진행한다.
apt-get install -y python3-gi gir1.2-gtk-3.0 libglib2.0-bin || \
    echo "[!] python3-gi / GTK 설치 실패 - 트레이 아이콘이 표시되지 않을 수 있습니다."
apt-get install -y gir1.2-ayatanaappindicator3-0.1 || \
apt-get install -y gir1.2-appindicator3-0.1 || \
    echo "[!] AppIndicator 라이브러리 설치 실패 - Wayland 에서는 트레이 아이콘이 표시되지 않습니다."

# --- 압축파일 내부 검사용 프로그램 ---------------------------------------------
#  p7zip(-full) : 7z 압축 해제,  unrar : rar 압축 해제
#  zip/tar/tar.gz/tar.bz2/tar.xz/gz/bz2/xz 는 파이썬 표준 라이브러리만으로 처리되므로 별도 설치가 필요 없다.
#  unrar 는 배포판에 따라 non-free/contrib 저장소가 꺼져 있으면 설치가 안 될 수 있다 - 부가 기능이므로
#  실패해도 계속 진행하며, 이 경우 rar 파일은 격리는 되어도 내부까지는 검사하지 못한다.
apt-get install -y p7zip-full || apt-get install -y p7zip || \
    echo "[!] p7zip 설치 실패 - 7z 압축 파일 내부는 검사하지 못합니다."
apt-get install -y unrar || apt-get install -y unrar-free || \
    echo "[!] unrar 설치 실패 - rar 압축 파일 내부는 검사하지 못합니다 (설치돼도 격리 자체는 정상 동작합니다)."

# --- 루트킷 검사기(rkhunter) --------------------------------------------------
# YARA/ClamAV 는 파일을 실시간으로 보고, rkhunter 는 하루 한 번 시스템 자체가 이미
# 변조됐는지(루트킷/숨겨진 프로세스 등) 정밀 점검한다. 부가 기능이므로 실패해도 계속 진행한다.
apt-get install -y rkhunter || \
    echo "[!] rkhunter 설치 실패 - 루트킷 정기 점검 기능이 동작하지 않습니다 (백신 본 기능은 정상 동작)."
if command -v rkhunter >/dev/null 2>&1; then
    rkhunter --update --nocolors >/dev/null 2>&1 || \
        echo "[!] rkhunter 규칙 업데이트 실패(오프라인일 수 있음) - 기본 규칙으로 계속합니다."
    # propupd 는 "지금 이 시스템 상태"를 정상 기준선으로 저장한다. 이후 새 프로그램을 설치하는 등
    # 정상적인 변경을 했다면 다시 실행해서 기준선을 갱신해야 그때마다 오탐(경고)이 뜨지 않는다.
    rkhunter --propupd --nocolors >/dev/null 2>&1 || \
        echo "[!] rkhunter 기준선(propupd) 설정 실패"
fi

# --- Maldet (Linux Malware Detect) -------------------------------------------
# 웹쉘/PHP 악성코드처럼 서버형 위협에 특화된 자체 시그니처 엔진. apt 저장소에 없어서
# rfxn.com 원본 tar 파일을 받아 설치한다 - 다른 패키지보다 실패 가능성이 더 높은 방식이라,
# 실패해도(네트워크 문제 등) 백신 본 기능에는 전혀 영향이 없도록 전부 실패 허용으로 처리한다.
if ! command -v maldet >/dev/null 2>&1 && [[ ! -x /usr/local/sbin/maldet ]]; then
    echo "  Maldet(Linux Malware Detect) 설치 중..."
    MALDET_TMP="$(mktemp -d)"
    if curl -fsSL "https://www.rfxn.com/downloads/maldetect-current.tar.gz" \
            -o "${MALDET_TMP}/maldetect.tar.gz" 2>/dev/null && \
       tar -xzf "${MALDET_TMP}/maldetect.tar.gz" -C "$MALDET_TMP" 2>/dev/null; then
        MALDET_SRC_DIR=$(find "$MALDET_TMP" -maxdepth 1 -type d -name 'maldetect-*' | head -1)
        if [[ -n "$MALDET_SRC_DIR" ]]; then
            (cd "$MALDET_SRC_DIR" && sh ./install.sh) >/dev/null 2>&1 || \
                echo "[!] Maldet 설치 스크립트 실행 실패"
        else
            echo "[!] Maldet 압축 해제 결과에서 소스 폴더를 찾지 못했습니다."
        fi
    else
        echo "[!] Maldet 다운로드 실패(rfxn.com 접속 불가일 수 있음) - git 저장소로 다시 시도합니다."
        if git clone --depth 1 https://github.com/rfxn/linux-malware-detect.git \
                "${MALDET_TMP}/lmd-git" >/dev/null 2>&1; then
            (cd "${MALDET_TMP}/lmd-git" && sh ./install.sh) >/dev/null 2>&1 || \
                echo "[!] Maldet(git) 설치 스크립트 실행 실패"
        else
            echo "[!] Maldet 설치 실패 - 이 검사 기능만 빠지고 나머지는 정상 동작합니다."
        fi
    fi
    rm -rf "$MALDET_TMP"
fi
if command -v maldet >/dev/null 2>&1 || [[ -x /usr/local/sbin/maldet ]]; then
    # 우리 자체 격리 시스템(변조 저장)을 쓰므로 maldet 자체 격리/이메일 알림은 꺼 둔다.
    MALDET_CONF="/usr/local/maldetect/conf.maldet"
    if [[ -f "$MALDET_CONF" ]]; then
        sed -i 's/^quarantine_hits=.*/quarantine_hits="0"/' "$MALDET_CONF"
        sed -i 's/^quarantine_clean=.*/quarantine_clean="0"/' "$MALDET_CONF"
        sed -i 's/^email_alert=.*/email_alert="0"/' "$MALDET_CONF"
    fi
    maldet --update >/dev/null 2>&1 || echo "[!] Maldet 시그니처 업데이트 실패(오프라인일 수 있음)"
fi

if ! python3 -c "import yara" 2>/dev/null; then
    apt-get install -y python3-yara || \
    pip3 install --break-system-packages yara-python || \
    pip3 install yara-python
fi

if ! python3 -c "import watchdog" 2>/dev/null; then
    apt-get install -y python3-watchdog || \
    pip3 install --break-system-packages watchdog || \
    pip3 install watchdog
fi

# pystray 는 0.19.5 이상이 필요하다 (0.19.5 에서 appindicator 백엔드 표시 관련 수정이 들어감).
# 주의: root(디스플레이 없음)에서 "import pystray" 는 설치돼 있어도 실패할 수 있어서 버전 메타데이터로 확인한다.
if ! python3 -c 'import importlib.metadata as m; v=tuple(int(x) for x in m.version("pystray").split(".")[:3]); raise SystemExit(0 if v >= (0, 19, 5) else 1)' 2>/dev/null; then
    pip3 install --break-system-packages -U pystray || \
    pip3 install -U pystray || \
    apt-get install -y python3-pystray || \
    echo "[!] pystray 설치 실패 - 트레이 아이콘 없이 알림만 동작합니다."
fi

echo "=== 2/9: YARA 규칙(Rule) 데이터베이스 구축 ==="
mkdir -p "$YARA_RULES_DIR"

# 기본 EICAR 테스트 룰 작성
cat > "${YARA_RULES_DIR}/eicar.yar" << 'YARARULE'
rule EICAR_Test_File {
    meta:
        description = "Standard EICAR Anti-Virus Test File"
        author = "SnhPiGuard"
    strings:
        $eicar = "X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"
    condition:
        $eicar
}
YARARULE

# 공개 YARA 룰(트로이목마/백도어/랜섬웨어/웹쉘 등)을 내려받아 "이 시스템에서 컴파일되는 룰만" 설치하는 업데이터
YARA_UPDATER="${INSTALL_DIR}/snhpiguard_yara_update.py"
mkdir -p "$INSTALL_DIR"
cat > "$YARA_UPDATER" << 'PYEOF'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SnhPiGuard YARA 룰 업데이터

공개 YARA 룰 저장소를 내려받아 "이 시스템의 YARA 로 실제로 컴파일되는 룰"만 골라 설치한다.
  * ReversingLabs (MIT)                    : trojan, backdoor, downloader, ransomware, worm ... 오탐이 거의 없는 탐지용 룰
  * Yara-Rules community (GPLv2)           : malware, webshells, cve_rules, exploit_kits ...

사용법
  python3 snhpiguard_yara_update.py                       # 설정 파일의 모드로 업데이트
  python3 snhpiguard_yara_update.py --mode light          # 가볍게 (ReversingLabs 전체 + 웹쉘)
  python3 snhpiguard_yara_update.py --mode recommended    # 기본값 (light + malware, cve, exploit kit)
  python3 snhpiguard_yara_update.py --mode all            # 전부 (오탐이 많은 packers/crypto/capabilities 등 포함)
  python3 snhpiguard_yara_update.py --min-age-hours 24    # 마지막 업데이트가 24시간 이내면 건너뜀

  --mode 로 고른 모드는 설정 파일(yara_sources.json)에 저장되어 이후 자동 업데이트에도 쓰인다.

종료 코드
  0  = 룰이 바뀜     10 = 변화 없음 / 건너뜀     1 = 실패 (기존 룰은 그대로 유지)
"""
import os
import re
import sys
import json
import time
import glob
import hashlib
import tarfile
import argparse
import tempfile
import shutil
import urllib.request

DEFAULT_RULES_DIR = "/opt/snhpiguard/yara_rules"
DEFAULT_CONFIG = "/opt/snhpiguard/yara_sources.json"
PACK_PREFIX = "pack_"           # 이 업데이터가 관리하는 파일 접두사 (사용자가 직접 넣은 룰은 건드리지 않는다)
MAX_FILE_BYTES = 3 * 1024 * 1024
DOWNLOAD_TIMEOUT_SEC = 60
LEGACY_FILES = ("njRAT.yar", "webshells.yar")   # 예전 설치 스크립트가 받던 파일 (recommended/all 에서는 중복이라 제거)

# subdir : 압축 루트 폴더 안에서 이 폴더 아래만 사용 ("" 이면 루트 전체)
SOURCES = {
    "reversinglabs": {
        "label": "ReversingLabs",
        "urls": [
            "https://github.com/reversinglabs/reversinglabs-yara-rules/archive/refs/heads/develop.tar.gz",
            "https://codeload.github.com/reversinglabs/reversinglabs-yara-rules/tar.gz/refs/heads/develop",
        ],
        "subdir": "yara",
    },
    "yararules": {
        "label": "Yara-Rules",
        "urls": [
            "https://github.com/Yara-Rules/rules/archive/refs/heads/master.tar.gz",
            "https://codeload.github.com/Yara-Rules/rules/tar.gz/refs/heads/master",
        ],
        "subdir": "",
    },
}

# None = 그 저장소의 모든 카테고리(폴더), 집합 = 해당 폴더만
# 제외: deprecated(폐기), mobile_malware(Androguard 모듈 필요 - 이 환경에서 컴파일 불가)
MODES = {
    "light": {
        "reversinglabs": None,
        "yararules": {"webshells"},
    },
    "recommended": {
        "reversinglabs": None,
        "yararules": {"webshells", "malware", "cve_rules", "exploit_kits"},
    },
    "all": {
        "reversinglabs": None,
        "yararules": {"webshells", "malware", "cve_rules", "exploit_kits", "maldocs", "email",
                      "packers", "crypto", "antidebug_antivm", "capabilities"},
    },
}
DEFAULT_MODE = "recommended"


def out(msg):
    print(msg, flush=True)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_config(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        return cfg if isinstance(cfg, dict) else {}
    except Exception:
        return {}


def save_config(path, cfg):
    try:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
            f.write("\n")
        os.replace(tmp, path)
    except Exception as e:
        out(f"[!] 설정 저장 실패({path}): {e}")


def iter_rule_files(tf, subdir):
    """
    tar 안의 룰 파일을 (카테고리, 상대경로 조각, 내용) 으로 돌려준다.
    디스크에는 아무것도 풀지 않으므로 tar 안의 경로(../ 등)로 다른 곳을 덮어쓸 수 없다.
    """
    for m in tf:
        if not m.isreg():
            continue
        parts = [p for p in m.name.replace("\\", "/").split("/") if p not in ("", ".")]
        if ".." in parts or len(parts) < 2:
            continue
        rel = parts[1:]                       # 압축 루트 폴더 제거
        if subdir:
            if rel[0] != subdir:
                continue
            rel = rel[1:]
        if len(rel) < 2:                      # 카테고리 폴더 밖(인덱스 파일 등)은 건너뜀
            continue
        if os.path.splitext(rel[-1])[1].lower() not in (".yar", ".yara"):
            continue
        if m.size <= 0 or m.size > MAX_FILE_BYTES:
            continue
        f = tf.extractfile(m)
        if f is None:
            continue
        yield rel[0].lower(), rel, f.read()


def safe_name(src_name, rel):
    joined = "__".join(rel)
    joined = re.sub(r"[^A-Za-z0-9._-]", "_", joined)
    return f"{PACK_PREFIX}{src_name}__{joined}"


def collect_source(yara, src_name, src, wanted, staging, seen_hashes, stats):
    """한 저장소를 내려받아 컴파일되는 룰만 staging 에 저장. 성공하면 True."""
    last_err = None
    for url in src["urls"]:
        # 시도마다 따로 집계했다가 성공했을 때만 합친다 (실패한 시도가 결과에 섞이지 않도록)
        local = {"skipped_category": 0, "duplicate": 0, "rejected": [], "per_category": {}}
        local_hashes = set()
        staged_here = []
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "SnhPiGuard-yara-updater/1.0"})
            with urllib.request.urlopen(req, timeout=DOWNLOAD_TIMEOUT_SEC) as resp:
                with tarfile.open(fileobj=resp, mode="r|gz") as tf:
                    for category, rel, data in iter_rule_files(tf, src["subdir"]):
                        if wanted is not None and category not in wanted:
                            local["skipped_category"] += 1
                            continue
                        digest = sha256(data)
                        if digest in seen_hashes or digest in local_hashes:
                            local["duplicate"] += 1
                            continue
                        if re.search(rb'^\s*include\s+"', data, re.M):
                            local["rejected"].append((rel[-1], "include 문(다른 파일 필요)"))
                            continue
                        name = safe_name(src_name, rel)
                        path = os.path.join(staging, name)
                        with open(path, "wb") as fh:
                            fh.write(data)
                        try:
                            yara.compile(filepath=path)
                        except Exception as e:
                            os.remove(path)
                            msg = str(e).splitlines()[0][:100] if str(e) else "컴파일 실패"
                            local["rejected"].append((rel[-1], msg))
                            continue
                        local_hashes.add(digest)
                        staged_here.append(name)
                        key = (src_name, category)
                        local["per_category"][key] = local["per_category"].get(key, 0) + 1
            # 성공: 집계 합치기
            seen_hashes.update(local_hashes)
            stats["skipped_category"] += local["skipped_category"]
            stats["duplicate"] += local["duplicate"]
            stats["rejected"].extend(local["rejected"])
            for k, v in local["per_category"].items():
                stats["per_category"][k] = stats["per_category"].get(k, 0) + v
            return True
        except Exception as e:
            last_err = e
            for name in staged_here:            # 실패한 시도에서 저장된 파일 정리
                try:
                    os.remove(os.path.join(staging, name))
                except Exception:
                    pass
    out(f"[!] {src['label']} 내려받기 실패: {last_err}")
    return False


def existing_managed(rules_dir):
    res = {}
    for p in glob.glob(os.path.join(rules_dir, PACK_PREFIX + "*")):
        if os.path.isfile(p) and p.lower().endswith((".yar", ".yara")):
            res[os.path.basename(p)] = p
    return res


def main():
    ap = argparse.ArgumentParser(description="SnhPiGuard YARA 룰 업데이터")
    ap.add_argument("--mode", choices=sorted(MODES))
    ap.add_argument("--min-age-hours", type=float, default=0)
    ap.add_argument("--rules-dir", default=DEFAULT_RULES_DIR)
    ap.add_argument("--config", default=DEFAULT_CONFIG)
    args = ap.parse_args()

    try:
        import yara
    except Exception as e:
        out(f"[!] yara 모듈을 불러올 수 없습니다: {e}")
        return 1

    cfg = load_config(args.config)
    mode = args.mode or cfg.get("mode") or DEFAULT_MODE
    if mode not in MODES:
        out(f"[!] 알 수 없는 모드 '{mode}' -> {DEFAULT_MODE} 사용")
        mode = DEFAULT_MODE
    if args.mode and cfg.get("mode") != args.mode:
        cfg["mode"] = args.mode
        save_config(args.config, cfg)

    os.makedirs(args.rules_dir, exist_ok=True)
    stamp = os.path.join(args.rules_dir, ".last_update")
    old = existing_managed(args.rules_dir)

    if args.min_age_hours > 0 and old and os.path.exists(stamp):
        age_h = (time.time() - os.path.getmtime(stamp)) / 3600.0
        if age_h < args.min_age_hours:
            out(f"[YARA] 마지막 룰 업데이트가 {age_h:.1f}시간 전이라 건너뜁니다.")
            return 10

    # 설정 파일로 주소를 바꿀 수 있다 (미러/사설 저장소용):  {"urls": {"yararules": ["https://..."]}}
    url_override = cfg.get("urls") if isinstance(cfg.get("urls"), dict) else {}

    staging = tempfile.mkdtemp(prefix="snhpiguard_yara_")
    try:
        stats = {"skipped_category": 0, "duplicate": 0, "rejected": [], "per_category": {}}
        seen = set()
        ok_sources = []
        out(f"[YARA] 룰 업데이트 시작 (모드: {mode})")
        for src_name, wanted in MODES[mode].items():
            src = dict(SOURCES[src_name])
            if isinstance(url_override.get(src_name), list) and url_override[src_name]:
                src["urls"] = url_override[src_name]
            out(f"  - {src['label']} 내려받는 중...")
            if collect_source(yara, src_name, src, wanted, staging, seen, stats):
                ok_sources.append(src_name)

        new = {f: os.path.join(staging, f) for f in os.listdir(staging)}
        if not ok_sources or not new:
            out("[!] 설치할 수 있는 룰을 하나도 받지 못했습니다. 기존 룰을 그대로 유지합니다.")
            return 1

        # 내려받기에 성공한 저장소의 파일만 교체/삭제한다 (실패한 저장소의 기존 룰은 보존)
        def managed_by_ok(fname):
            return any(fname.startswith(f"{PACK_PREFIX}{s}__") for s in ok_sources)

        old_ok = {f: p for f, p in old.items() if managed_by_ok(f)}
        old_hash = {f: file_sha256(p) for f, p in old_ok.items()}
        new_hash = {f: file_sha256(p) for f, p in new.items()}
        changed = (old_hash != new_hash)

        if changed:
            for fname, spath in new.items():
                dst = os.path.join(args.rules_dir, fname)
                tmp = dst + ".tmpnew"
                shutil.copyfile(spath, tmp)
                os.chmod(tmp, 0o644)
                os.replace(tmp, dst)
            for fname, p in old_ok.items():
                if fname not in new:
                    try:
                        os.remove(p)
                    except Exception:
                        pass

        if mode != "light":
            for legacy in LEGACY_FILES:
                lp = os.path.join(args.rules_dir, legacy)
                if os.path.isfile(lp):
                    try:
                        os.remove(lp)
                        changed = True
                    except Exception:
                        pass

        with open(stamp, "w") as f:
            f.write(str(int(time.time())) + "\n")

        # ---- 요약 ----
        by_src = {}
        for (s, c), n in sorted(stats["per_category"].items()):
            by_src.setdefault(s, []).append(f"{c} {n}")
        out(f"[YARA] 설치된 룰 파일 {len(new)}개  (컴파일 불가로 제외 {len(stats['rejected'])}개, "
            f"중복 {stats['duplicate']}개, 모드에서 제외된 카테고리 {stats['skipped_category']}개)")
        for s, items in by_src.items():
            out(f"  · {SOURCES[s]['label']}: " + ", ".join(items))
        for fname, why in stats["rejected"][:5]:
            out(f"  · 제외 예: {fname} ({why})")
        if len(stats["rejected"]) > 5:
            out(f"  · ... 그 외 {len(stats['rejected']) - 5}개 제외")
        if len(ok_sources) < len(MODES[mode]):
            out("[!] 일부 저장소는 내려받지 못해 기존 룰을 유지했습니다.")
        out("[YARA] 변경됨" if changed else "[YARA] 변경 없음")
        return 0 if changed else 10
    finally:
        shutil.rmtree(staging, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
PYEOF
chmod +x "$YARA_UPDATER"

# 룰 모드 설정 / 오탐 제외 목록 (이미 있으면 건드리지 않는다)
[[ -f "${INSTALL_DIR}/yara_sources.json" ]] || echo '{"mode": "recommended"}' > "${INSTALL_DIR}/yara_sources.json"
if [[ ! -f "${INSTALL_DIR}/yara_exclude.txt" ]]; then
cat > "${INSTALL_DIR}/yara_exclude.txt" << 'EXCLUDE_EOF'
# 오탐(정상 파일이 격리됨)이 나는 YARA 룰 이름을 한 줄에 하나씩 적으세요. (# 뒤는 주석)
# 룰 이름은 격리소 목록의 "탐지 엔진 / 규칙" 칸에 YARA:룰이름 으로 표시됩니다.
# 이름 끝에 * 를 붙이면 그 이름으로 시작하는 룰을 전부 제외합니다.
#   예) Big_Numbers*  ->  Big_Numbers, Big_Numbers1, Big_Numbers2 ... 전부 제외
# 저장 후 GUI 의 [DB 업데이트]를 누르면 반영됩니다.
EXCLUDE_EOF
fi

echo "  공개 YARA 룰 내려받는 중... (모드: ${SNHPIGUARD_YARA_MODE:-설정 파일 값, 기본 recommended})"
python3 "$YARA_UPDATER" ${SNHPIGUARD_YARA_MODE:+--mode "$SNHPIGUARD_YARA_MODE"} || {
    rc=$?
    [[ $rc -eq 10 ]] || echo "[!] YARA 룰 내려받기 실패 - 기본(EICAR) 룰만으로 계속합니다. 나중에 sudo python3 $YARA_UPDATER 로 다시 시도하세요."
}

# 사용자가 직접 넣은 룰 파일의 문법 검사 (업데이터가 설치한 pack_* 파일은 이미 컴파일 검증을 마쳤으므로 제외)
for existing_rule in "${YARA_RULES_DIR}"/*.yar "${YARA_RULES_DIR}"/*.yara; do
    [[ -f "$existing_rule" ]] || continue
    [[ "$(basename "$existing_rule")" == pack_* ]] && continue
    if ! yara -w "$existing_rule" /bin/true >/dev/null 2>&1; then
        echo "  [정리] 기존 규칙 파일이 문법 오류를 포함하여 제외됨: $(basename "$existing_rule")"
        mv "$existing_rule" "${existing_rule}.broken"
    fi
done

echo "=== 3/9: Raspberry Pi 및 ClamAV 최적화 ==="
if grep -qi "raspberry" /proc/device-tree/model 2>/dev/null; then
    CLAMD_CONF="/etc/clamav/clamd.conf"
    if [[ -f "$CLAMD_CONF" ]]; then
        sed -i 's/^#\?MaxThreads .*/MaxThreads 1/' "$CLAMD_CONF"
        sed -i 's/^#\?MaxQueue .*/MaxQueue 20/' "$CLAMD_CONF"
    fi
fi

mkdir -p "$INSTALL_DIR" /var/log/snhpiguard /var/quarantine/snhpiguard /var/quarantine/snhpiguard/shadow_copies
chmod 700 /var/quarantine/snhpiguard

systemctl stop clamav-freshclam 2>/dev/null || true
freshclam || echo "[!] freshclam 백업 처리 진행"
systemctl enable clamav-freshclam clamav-daemon 2>/dev/null || true
systemctl restart clamav-daemon 2>/dev/null || systemctl start clamav-daemon 2>/dev/null || true

echo "=== 4/9: 다중 엔진 데몬 생성 (snhpiguard_daemon.py) ==="
cat > "${INSTALL_DIR}/snhpiguard_daemon.py" << 'PYEOF'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SnhPiGuard Multi-Engine Daemon
- 실시간(파일 단위): YARA (메인) + ClamAV (보조)
- 정기 점검(하루 1회, 시스템 단위): rkhunter (루트킷/시스템 변조) + Maldet (웹쉘/서버형 악성코드)
- Protected Folder Access: fanotify 기반 실시간 쓰기/생성 차단 확인창 + 삭제 그림자 복구
"""
import os
import sys
import time
import json
import shutil
import socket
import glob
import ctypes
import ctypes.util
import fcntl
import struct
import threading
import subprocess
import stat
import hashlib
import zipfile
import tempfile
import tarfile
import gzip
import bz2
import lzma
import re
from datetime import datetime, timedelta

SOCKET_PATH = "/tmp/snhpiguard.sock"
QUARANTINE_DIR = "/var/quarantine/snhpiguard"
QUARANTINE_INDEX = os.path.join(QUARANTINE_DIR, "quarantine_index.json")
WHITELIST_INDEX = os.path.join(QUARANTINE_DIR, "whitelist.json")
PROTECTED_INDEX = os.path.join(QUARANTINE_DIR, "protected_folders.json")
TRUSTED_APPS_INDEX = os.path.join(QUARANTINE_DIR, "trusted_apps.json")
BLOCK_EVENTS_INDEX = os.path.join(QUARANTINE_DIR, "protection_events.json")
SHADOW_DIR = os.path.join(QUARANTINE_DIR, "shadow_copies")
LOG_DIR = "/var/log/snhpiguard"
LOG_FILE = os.path.join(LOG_DIR, "snhpiguard.log")
YARA_RULES_DIR = "/opt/snhpiguard/yara_rules"
AUTO_UPDATE_INTERVAL_SEC = 4 * 3600
CONFIRM_DIALOG_SCRIPT = "/opt/snhpiguard/snhpiguard_confirm_dialog.py"
CONFIRM_TIMEOUT_SEC = 30  # 사용자가 응답하지 않으면 안전하게 거부(취소) 처리
PASSWORD_DIALOG_SCRIPT = "/opt/snhpiguard/snhpiguard_password_dialog.py"
ARCHIVE_PASSWORD_DIALOG_TIMEOUT_SEC = 120   # 사용자가 비밀번호 입력창에 응답할 시간
ARCHIVE_PASSWORD_DETECT_TIMEOUT_SEC = 5     # "비밀번호가 필요한가?" 판정에 쓰는 시간 (여기서 지연되면 다음 파일 검사가 늦어짐)
ARCHIVE_PASSWORD_VERIFY_TIMEOUT_SEC = 30    # 입력받은 비밀번호가 맞는지 확인하는 시간 (백그라운드라 조금 더 여유)
ARCHIVE_PASSWORD_MAX_ATTEMPTS = 2

# ---- 격리소 자동 청소 ----
QUARANTINE_RETENTION_DAYS = 30
QUARANTINE_CLEANUP_INTERVAL_SEC = 6 * 3600   # 6시간마다 확인

# ---- USB/외장 드라이브 자동 검사 ----
USB_SCAN_ROOTS = ("/media", "/mnt", "/run/media")
USB_SCAN_POLL_INTERVAL_SEC = 5
USB_SCAN_SETTLE_SEC = 2      # 마운트 직후 살짝 기다렸다가 검사 시작 (드라이브가 완전히 준비되도록)
USB_SCAN_IGNORE_FS = {
    "proc", "sysfs", "tmpfs", "devtmpfs", "cgroup", "cgroup2", "overlay", "squashfs",
    "devpts", "securityfs", "pstore", "bpf", "autofs", "mqueue", "debugfs", "tracefs",
    "configfs", "fusectl", "binfmt_misc", "fuse.gvfsd-fuse", "rpc_pipefs",
}

YARA_EXCLUDE_FILE = "/opt/snhpiguard/yara_exclude.txt"   # 오탐 나는 룰 이름을 한 줄에 하나씩 적으면 그 룰은 무시
YARA_UPDATER_SCRIPT = "/opt/snhpiguard/snhpiguard_yara_update.py"
YARA_RULE_MIN_AGE_HOURS = 24  # 자동 업데이트에서 YARA 룰은 하루에 한 번만 내려받는다 (수동 업데이트는 항상)

try:
    import yara
    YARA_OK = True
except ImportError:
    YARA_OK = False

try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler
    WATCHDOG_OK = True
except ImportError:
    WATCHDOG_OK = False


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def load_json(filepath):
    if os.path.exists(filepath):
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []
    return []


def save_json(filepath, data):
    try:
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def add_to_whitelist(filepath):
    db = load_json(WHITELIST_INDEX)
    abs_p = os.path.abspath(filepath)
    if abs_p not in db:
        db.append(abs_p)
        save_json(WHITELIST_INDEX, db)


def remove_from_whitelist(paths):
    db = load_json(WHITELIST_INDEX)
    norm_paths = [os.path.abspath(p) for p in paths]
    new_db = [p for p in db if os.path.abspath(p) not in norm_paths]
    save_json(WHITELIST_INDEX, new_db)
    return len(db) - len(new_db)


def is_whitelisted(filepath):
    db = load_json(WHITELIST_INDEX)
    return os.path.abspath(filepath) in db


# ---------- 보호된 폴더 / 신뢰 앱 목록 관리 ----------
def load_protected_folders():
    return load_json(PROTECTED_INDEX)


def add_protected_folder(path):
    path = os.path.abspath(path)
    db = load_protected_folders()
    if path not in db:
        db.append(path)
        save_json(PROTECTED_INDEX, db)
    return db


def remove_protected_folder(path):
    path = os.path.abspath(path)
    db = load_protected_folders()
    db = [p for p in db if p != path]
    save_json(PROTECTED_INDEX, db)
    return db


def load_trusted_apps():
    return load_json(TRUSTED_APPS_INDEX)


def add_trusted_app(path):
    path = os.path.abspath(path)
    db = load_trusted_apps()
    if path not in db:
        db.append(path)
        save_json(TRUSTED_APPS_INDEX, db)
    return db


def remove_trusted_app(path):
    path = os.path.abspath(path)
    db = load_trusted_apps()
    db = [p for p in db if p != path]
    save_json(TRUSTED_APPS_INDEX, db)
    return db


def record_block_event(action, decision, filepath, proc_path):
    db = load_json(BLOCK_EVENTS_INDEX)
    item = {
        "id": str(int(time.time() * 1000000)),
        "action": action,          # "write" | "delete"
        "decision": decision,      # "allowed" | "denied" | "restored" | "kept_deleted"
        "path": filepath,
        "process": proc_path,
        "time": now(),
    }
    db.append(item)
    if len(db) > 300:
        db = db[-300:]
    save_json(BLOCK_EVENTS_INDEX, db)
    return item


# ---------- 사용자 확인창 호출 (root 데몬 -> 로그인 세션 GUI) ----------
def get_active_display_env():
    """로그인한 실제 사용자와 DISPLAY 값을 찾아 확인창을 그 세션에 띄운다."""
    real_user = os.environ.get("SNHPIGUARD_REAL_USER", "")
    display = os.environ.get("SNHPIGUARD_DISPLAY", ":0")
    if not real_user:
        try:
            out = subprocess.run(["who"], capture_output=True, text=True, timeout=3).stdout
            for line in out.splitlines():
                parts = line.split()
                if parts:
                    real_user = parts[0]
                    break
        except Exception:
            pass
    return real_user, display


def ask_user_confirm(action, filepath, proc_path):
    """
    로그인 세션에 GUI 확인창을 띄우고 사용자의 선택을 기다린다.
    반환값: True(허용/복구) / False(차단/삭제 유지)
    확인창을 띄울 수 없거나 시간 초과 시 -> 안전 기본값(False, 거부)으로 처리.
    """
    real_user, display = get_active_display_env()
    if not real_user:
        return False, False  # (allow, remember_app)

    try:
        result = subprocess.run(
            ["sudo", "-u", real_user, "DISPLAY=" + display,
             "python3", CONFIRM_DIALOG_SCRIPT, action, filepath, proc_path],
            capture_output=True, text=True, timeout=CONFIRM_TIMEOUT_SEC + 5,
            env={**os.environ, "DISPLAY": display}
        )
        out = result.stdout.strip()
        # 대화상자는 "ALLOW", "DENY", "ALLOW_REMEMBER" 중 하나를 출력한다
        if out == "ALLOW_REMEMBER":
            return True, True
        if out == "ALLOW":
            return True, False
        return False, False
    except Exception:
        return False, False


# ---------- YARA 메인 엔진 ----------
def load_yara_exclude():
    """
    yara_exclude.txt 의 룰 이름 목록 (# 뒤는 주석).
    이름 끝에 * 를 붙이면(예: Big_Numbers*) 그 이름으로 시작하는 모든 룰을 한 번에 제외한다
    (Big_Numbers, Big_Numbers1, Big_Numbers2 ... 처럼 번호만 다른 룰이 여러 개일 때 유용하다).
    반환: (정확히 일치해야 하는 이름들의 set, 접두사로 걸러낼 패턴들의 tuple)
    """
    exact = set()
    prefixes = []
    try:
        with open(YARA_EXCLUDE_FILE, "r", encoding="utf-8") as f:
            for line in f:
                line = line.split("#", 1)[0].strip()
                if not line:
                    continue
                if line.endswith("*"):
                    prefix = line[:-1].strip()
                    if prefix:
                        prefixes.append(prefix)
                else:
                    exact.add(line)
    except Exception:
        pass
    return exact, tuple(prefixes)


class YaraScanner:
    def __init__(self, rules_dir):
        self.rules_dir = rules_dir
        self.compiled_rules = None
        self.excluded = set()
        self.excluded_prefixes = ()
        self.reload_rules()

    def reload_rules(self):
        if not YARA_OK:
            return
        rule_files = sorted(glob.glob(os.path.join(self.rules_dir, "*.yar")) +
                            glob.glob(os.path.join(self.rules_dir, "*.yara")))
        self.excluded, self.excluded_prefixes = load_yara_exclude()
        all_paths = {f"namespace_{idx}": rf for idx, rf in enumerate(rule_files)}

        compiled = None
        valid = all_paths
        skipped = []
        if all_paths:
            # 1) 전부 한 번에 컴파일 (룰이 수천 개일 때 파일별로 두 번 컴파일하는 것보다 훨씬 빠르다)
            try:
                compiled = yara.compile(filepaths=all_paths)
            except Exception:
                compiled = None
            if compiled is None:
                # 2) 문제 있는 파일만 골라내고 다시 컴파일
                valid = {}
                for ns, rf in all_paths.items():
                    try:
                        yara.compile(filepath=rf)
                        valid[ns] = rf
                    except Exception as e:
                        skipped.append((rf, str(e)))
                if valid:
                    try:
                        compiled = yara.compile(filepaths=valid)
                    except Exception as e:
                        STATE.log(f"[YARA 로드 실패] 룰 컴파일 오류: {e}")
                        compiled = None

        for rf, err in skipped:
            STATE.log(f"[YARA 규칙 제외] 문법 오류로 로드하지 않음: {rf} ({err})")

        if compiled is not None:
            self.compiled_rules = compiled
            excl_count = len(self.excluded) + len(self.excluded_prefixes)
            extra = f", 오탐 제외 룰(패턴 포함) {excl_count}개" if excl_count else ""
            STATE.log(f"[YARA 로드 완료] 유효한 규칙 파일 {len(valid)}개 적용 (제외 {len(skipped)}개{extra})")
        elif not valid:
            STATE.log("[YARA 로드 경고] 사용 가능한 유효 규칙이 없습니다.")
            self.compiled_rules = None
        # 컴파일 오류로 실패한 경우에는 이전에 로드된 룰을 그대로 유지한다

    def _is_excluded(self, rule_name):
        if rule_name in self.excluded:
            return True
        return any(rule_name.startswith(p) for p in self.excluded_prefixes)

    def scan_file(self, filepath):
        if not YARA_OK or not self.compiled_rules or not os.path.isfile(filepath):
            return False, None
        try:
            matches = self.compiled_rules.match(filepath, timeout=10)
            for m in matches:
                if self._is_excluded(str(m.rule)):
                    continue
                return True, f"YARA:{m.rule}"
        except Exception:
            pass
        return False, None


# ---------- ClamAV 보조 엔진 ----------
def clamd_available():
    for sock_path in ("/run/clamav/clamd.ctl", "/var/run/clamav/clamd.ctl"):
        if os.path.exists(sock_path):
            return True
    try:
        s = socket.create_connection(("127.0.0.1", 3310), timeout=1)
        s.close()
        return True
    except Exception:
        return False


CLAMAV_SCAN_TIMEOUT_SEC = 60
CLAMAV_POLL_INTERVAL_SEC = 0.2   # 이 간격으로 "중지 요청" 여부를 확인한다


def scan_file_clamav(filepath):
    if not os.path.isfile(filepath):
        return False, None

    if clamd_available():
        cmd = ["clamdscan", "--no-summary", "--fdpass", filepath]
    else:
        cmd = ["clamscan", "--no-summary", filepath]

    # subprocess.run(timeout=60) 처럼 한 번에 길게 기다리면 그동안 "검사 중지" 요청을 알아챌 수 없으므로,
    # 0.2초씩 짧게 나눠 기다리며 그때마다 중지 요청이 왔는지 확인한다.
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
    except Exception:
        return False, None

    start = time.monotonic()
    stdout = ""
    while True:
        try:
            stdout, _ = proc.communicate(timeout=CLAMAV_POLL_INTERVAL_SEC)
            break
        except subprocess.TimeoutExpired:
            if STATE.stop_requested or time.monotonic() - start > CLAMAV_SCAN_TIMEOUT_SEC:
                proc.kill()
                try:
                    proc.communicate(timeout=5)
                except Exception:
                    pass
                return False, None

    if proc.returncode == 1:
        sig = "ClamAV:Malware"
        for line in (stdout or "").splitlines():
            if "FOUND" in line and ": " in line:
                sig = "ClamAV:" + line.rsplit(": ", 1)[1].replace("FOUND", "").strip()
        return True, sig
    return False, None


# ---------- 격리소 파일 무력화(변조 저장) / 안전 삭제 ----------
# 격리된 파일은 내용을 그대로 두지 않고
#     [SNHQ1 헤더 8바이트] + [랜덤 키 32바이트] + [원본 내용 XOR 키스트림]
# 형태로 바꿔서 저장한다. 그래서 격리소 안에서는 실행/열람은 물론 다른 백신의 시그니처 매칭도 되지 않는다.
# (암호화가 아니라 "무력화"가 목적이다. 키가 파일 헤더에 같이 들어 있어 복구는 언제나 가능하다.)
# 삭제(영구 삭제)는 내용을 덮어쓴 뒤(랜덤 -> 0x00) 길이 0 으로 만들고 지운다.
SCRAMBLE_CHUNK = 1024 * 1024   # 키스트림 단위. 바꾸면 기존 격리 파일을 복구할 수 없으니 바꾸지 말 것
WIPE_PASSES = 2                # 덮어쓰기 횟수: 마지막 회차는 0x00, 나머지는 랜덤
Q_MAGIC = b"SNHQ1\x00\x00\x00"
Q_KEY_LEN = 32
Q_HEADER_LEN = len(Q_MAGIC) + Q_KEY_LEN

QUARANTINE_LOCK = threading.RLock()   # 격리 목록(index) 수정 직렬화
_PENDING_PASSWORD_LOCK = threading.Lock()
_PENDING_PASSWORD_PATHS = set()   # 지금 비밀번호를 물어보는 중인 압축 파일 경로
_QID_LOCK = threading.Lock()
_LAST_QID = 0


def new_q_id():
    """프로세스 안에서 절대 겹치지 않는 격리 ID (밀리초 시각 기반)."""
    global _LAST_QID
    with _QID_LOCK:
        v = int(time.time() * 1000)
        if v <= _LAST_QID:
            v = _LAST_QID + 1
        _LAST_QID = v
        return str(v)


def _remove_quietly(path):
    try:
        os.remove(path)
    except Exception:
        pass


def _keystream(key, index, length):
    """key 와 청크 번호로 결정되는 키스트림 (SHAKE-256). 같은 입력이면 항상 같은 값."""
    return hashlib.shake_256(key + index.to_bytes(8, "little")).digest(length)


def _xor_bytes(data, ks):
    n = len(data)
    return (int.from_bytes(data, "little") ^ int.from_bytes(ks, "little")).to_bytes(n, "little")


def _xor_stream(fin, fout, key):
    idx = 0
    while True:
        chunk = fin.read(SCRAMBLE_CHUNK)
        if not chunk:
            break
        fout.write(_xor_bytes(chunk, _keystream(key, idx, len(chunk))))
        idx += 1


def scramble_copy(src, dst):
    """src 내용을 변조해서 dst 에 새로 쓴다. dst 는 root 전용(0600)이며 실행 권한이 없다."""
    key = os.urandom(Q_KEY_LEN)
    with open(src, "rb") as fin:
        fd = os.open(dst, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as fout:
            fout.write(Q_MAGIC + key)
            _xor_stream(fin, fout, key)
            fout.flush()
            os.fsync(fout.fileno())


def unscramble_copy(src, dst):
    """scramble_copy 로 만든 파일에서 원본 내용을 복원해 dst 에 새로 쓴다."""
    with open(src, "rb") as fin:
        header = fin.read(Q_HEADER_LEN)
        if len(header) != Q_HEADER_LEN or header[:len(Q_MAGIC)] != Q_MAGIC:
            raise ValueError("격리 파일 형식이 올바르지 않습니다 (SNHQ1 헤더 없음)")
        key = header[len(Q_MAGIC):]
        fd = os.open(dst, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as fout:
            _xor_stream(fin, fout, key)
            fout.flush()
            os.fsync(fout.fileno())


def secure_delete(path):
    """
    파일 내용을 덮어써서(랜덤 -> 0x00, 디스크에 반영) 지운 뒤, 길이 0 으로 만들고 삭제한다.
    파일이 더 이상 존재하지 않으면 True.
    * 하드링크가 여러 개인 파일은 다른 링크의 내용까지 망가뜨리므로 덮어쓰지 않고 링크만 지운다.
    * 심볼릭 링크는 링크 자체만 지운다.
    * 주의: SD카드/SSD 는 웨어 레벨링 때문에 물리적으로 같은 셀을 덮어쓴다는 보장은 없다.
    """
    try:
        st = os.lstat(path)
    except FileNotFoundError:
        return True
    except Exception as e:
        STATE.log(f"[삭제 실패] {path}: {e}")
        return False

    try:
        if stat.S_ISREG(st.st_mode) and st.st_nlink == 1 and st.st_size > 0:
            fd = os.open(path, os.O_WRONLY | os.O_NOFOLLOW)
            try:
                for p in range(WIPE_PASSES):
                    os.lseek(fd, 0, os.SEEK_SET)
                    remaining = st.st_size
                    last_pass = (p == WIPE_PASSES - 1)
                    while remaining > 0:
                        n = min(remaining, SCRAMBLE_CHUNK)
                        buf = bytes(n) if last_pass else os.urandom(n)
                        remaining -= os.write(fd, buf)
                    os.fsync(fd)
                os.ftruncate(fd, 0)
                os.fsync(fd)
            finally:
                os.close(fd)
    except Exception as e:
        STATE.log(f"[안전 삭제 경고] 덮어쓰기에 실패했습니다 ({path}): {e}")

    try:
        os.remove(path)
        return True
    except FileNotFoundError:
        return True
    except Exception as e:
        STATE.log(f"[삭제 실패] {path}: {e}")
        return False


# ---------- 시스템 파일 보호 ----------
# 이 경로들 아래에 있는 파일은 감염이 확인돼도 자동으로 옮기거나 지우지 않는다.
# 시스템 바이너리/설정을 자동으로 움직이면 부팅이 안 되거나 서비스가 깨질 수 있기 때문이다.
# 대신 격리소 목록에 "시스템 파일" 로 표시만 해 두고, 사용자가 목록에서 직접 [영구 삭제]를
# 눌러야만 실제로 지워진다 (지울 때는 다른 격리와 동일하게 덮어쓰기 삭제).
SYSTEM_PROTECTED_PREFIXES = (
    "/bin/", "/sbin/", "/lib/", "/lib32/", "/lib64/", "/libx32/",
    "/usr/", "/etc/", "/boot/", "/proc/", "/sys/", "/run/", "/root/",
    "/var/lib/", "/var/spool/", "/var/cache/", "/snap/", "/opt/",
)


def is_system_protected_path(path):
    try:
        real = os.path.realpath(path)
    except Exception:
        real = os.path.abspath(path)
    return any(real == p.rstrip("/") or real.startswith(p) for p in SYSTEM_PROTECTED_PREFIXES)


def _record_system_protected(fpath, sig):
    """시스템 파일을 옮기거나 지우지 않고, 격리소 목록에만 '시스템 파일' 로 표시한다."""
    abs_path = os.path.abspath(fpath)
    with QUARANTINE_LOCK:
        db = load_json(QUARANTINE_INDEX)
        for it in db:
            if it.get("system_protected") and it.get("original_path") == abs_path:
                return it   # 이미 목록에 있음 - 다시 추가하지 않음
        item = {
            "id": new_q_id(),
            "original_path": abs_path,
            "quarantine_path": None,          # 아직 아무것도 옮기지 않았다
            "filename": os.path.basename(abs_path),
            "sig": sig,
            "time": now(),
            "scrambled": False,
            "system_protected": True,
        }
        db.append(item)
        save_json(QUARANTINE_INDEX, db)
    STATE.log(f"[시스템 파일 탐지] [{sig}] {abs_path} - 시스템 파일이라 자동 격리하지 않고 "
              f"목록에만 표시했습니다. 확인 후 필요하면 격리소 목록에서 직접 [영구 삭제]를 누르세요.")
    return item


# ---------- 격리 및 복구 처리 ----------
def quarantine_file_daemon(fpath, sig="Unknown"):
    if not os.path.isfile(fpath):
        return None

    if os.path.islink(fpath):
        STATE.log(f"[격리 제외] 심볼릭 링크는 격리하지 않습니다: {fpath}")
        return None

    if is_whitelisted(fpath):
        STATE.log(f"[격리 제외] 복구된 예외 파일입니다: {fpath}")
        return None

    if is_system_protected_path(fpath):
        return _record_system_protected(fpath, sig)

    q_id = new_q_id()
    base = os.path.basename(fpath)
    q_filename = f"{q_id}_{base}.quarantined"
    q_filepath = os.path.join(QUARANTINE_DIR, q_filename)

    # 1) 변조한 사본을 격리소에 만든다 (원본은 아직 그대로)
    try:
        st = os.stat(fpath)
        scramble_copy(fpath, q_filepath)
    except FileExistsError:
        STATE.log(f"[격리 실패] 같은 이름의 격리 파일이 이미 있습니다: {q_filepath}")
        return None
    except Exception as e:
        STATE.log(f"[격리 실패] {fpath}: {e}")
        _remove_quietly(q_filepath)
        return None

    item = {
        "id": q_id,
        "original_path": os.path.abspath(fpath),
        "quarantine_path": q_filepath,
        "filename": base,
        "sig": sig,
        "time": now(),
        "scrambled": True,
        # 복구할 때 되돌릴 원본 속성
        "mode": stat.S_IMODE(st.st_mode),
        "uid": st.st_uid,
        "gid": st.st_gid,
        "atime": st.st_atime,
        "mtime": st.st_mtime,
    }

    # 2) 격리 목록에 기록 (기록이 확인돼야만 원본을 지운다 - 오탐이어도 복구 가능해야 하므로)
    with QUARANTINE_LOCK:
        db = load_json(QUARANTINE_INDEX)
        db.append(item)
        save_json(QUARANTINE_INDEX, db)
        saved = any(i.get("id") == q_id for i in load_json(QUARANTINE_INDEX))
    if not saved:
        STATE.log(f"[격리 실패] 격리 목록을 저장하지 못해 원본을 그대로 둡니다: {fpath}")
        secure_delete(q_filepath)
        return None

    # 3) 원본을 덮어써서 지운다
    if not secure_delete(fpath):
        STATE.log(f"[격리 경고] 원본을 완전히 삭제하지 못했습니다 (격리본은 보관됨): {fpath}")
        return item

    STATE.log(f"[자동 격리 완료] [{sig}] {fpath} -> 격리소 이동됨 (내용 변조 저장, 원본 덮어쓰기 삭제)")
    return item


def _restore_scrambled(q_path, dest, item):
    """변조 저장된 격리 파일을 원래 내용/권한/소유자/시간으로 dest 에 복원한다."""
    tmp = q_path + ".restore.tmp"
    _remove_quietly(tmp)
    try:
        unscramble_copy(q_path, tmp)
        try:
            os.chmod(tmp, int(item.get("mode", 0o644)))
        except Exception:
            pass
        try:
            os.utime(tmp, (item["atime"], item["mtime"]))
        except Exception:
            pass
        shutil.move(tmp, dest)
    except Exception:
        _remove_quietly(tmp)
        raise
    try:
        if "uid" in item and "gid" in item:
            os.chown(dest, int(item["uid"]), int(item["gid"]))
    except Exception:
        pass


def restore_quarantine_items(q_ids):
    with QUARANTINE_LOCK:
        db = load_json(QUARANTINE_INDEX)
        restored_count = 0
        new_db = []
        for item in db:
            if item["id"] in q_ids:
                if item.get("system_protected"):
                    # 시스템 파일: 옮긴 적이 없으므로 예외 등록만 하고 목록에서 제거한다
                    add_to_whitelist(item["original_path"])
                    STATE.log(f"[복구 완료] {item['original_path']} 은 시스템 파일이라 옮긴 적이 없어 "
                              f"목록에서만 제거하고 예외로 등록했습니다.")
                    restored_count += 1
                    continue
                q_path = item["quarantine_path"]
                orig_path = item["original_path"]
                if os.path.exists(q_path):
                    # 복구되는 파일이 실시간 감시에 바로 다시 걸리지 않도록 예외를 먼저 등록한다
                    was_whitelisted = is_whitelisted(orig_path)
                    add_to_whitelist(orig_path)
                    try:
                        os.makedirs(os.path.dirname(orig_path), exist_ok=True)
                        if item.get("scrambled"):
                            _restore_scrambled(q_path, orig_path, item)
                            secure_delete(q_path)
                        else:
                            shutil.move(q_path, orig_path)   # 변조 저장 도입 전에 격리된 파일
                        STATE.log(f"[복구 완료] {orig_path} 원래 위치로 복구됨 (예외 등록)")
                        restored_count += 1
                    except Exception as e:
                        if not was_whitelisted:
                            remove_from_whitelist([orig_path])
                        STATE.log(f"[복구 실패] {orig_path}: {e}")
                        new_db.append(item)
                else:
                    STATE.log(f"[복구 오류] 파일 없음: {q_path}")
            else:
                new_db.append(item)
        save_json(QUARANTINE_INDEX, new_db)
        return restored_count


def delete_quarantine_items(q_ids):
    with QUARANTINE_LOCK:
        db = load_json(QUARANTINE_INDEX)
        deleted_count = 0
        new_db = []
        for item in db:
            if item["id"] in q_ids:
                if item.get("system_protected"):
                    # 지금까지는 건드리지 않았던 시스템 파일 - 사용자가 직접 [영구 삭제]를 눌렀을 때만 실제로 지운다
                    if secure_delete(item["original_path"]):
                        STATE.log(f"[영구 삭제 완료] {item['original_path']} (사용자가 직접 확인 후 시스템 파일을 삭제함)")
                        deleted_count += 1
                    else:
                        STATE.log(f"[영구 삭제 실패] {item['original_path']}")
                        new_db.append(item)
                    continue
                q_path = item["quarantine_path"]
                if secure_delete(q_path):
                    STATE.log(f"[영구 삭제 완료] {item['original_path']} (덮어쓰기 후 삭제)")
                    deleted_count += 1
                else:
                    STATE.log(f"[영구 삭제 실패] {q_path}")
                    new_db.append(item)
            else:
                new_db.append(item)
        save_json(QUARANTINE_INDEX, new_db)
        return deleted_count


def migrate_legacy_quarantine():
    """변조 저장 도입 전에 격리돼 원본 그대로 들어 있는 파일을 변조 저장 방식으로 바꾼다."""
    with QUARANTINE_LOCK:
        db = load_json(QUARANTINE_INDEX)
        migrated = 0
        for idx in range(len(db)):
            item = db[idx]
            if item.get("scrambled") or item.get("system_protected"):
                continue
            old_path = item.get("quarantine_path", "")
            if not old_path or not os.path.isfile(old_path):
                continue
            new_path = old_path + ".v2"
            _remove_quietly(new_path)   # 이전 전환이 중간에 끊겼다면 남은 찌꺼기
            try:
                st = os.stat(old_path)
                scramble_copy(old_path, new_path)
            except Exception as e:
                STATE.log(f"[격리소 전환 실패] {old_path}: {e}")
                _remove_quietly(new_path)
                continue

            new_item = dict(item)
            new_item.update({
                "quarantine_path": new_path,
                "scrambled": True,
                "mode": stat.S_IMODE(st.st_mode),
                "uid": st.st_uid,
                "gid": st.st_gid,
                "atime": st.st_atime,
                "mtime": st.st_mtime,
            })
            candidate = list(db)
            candidate[idx] = new_item
            save_json(QUARANTINE_INDEX, candidate)
            ok = any(i.get("id") == new_item["id"] and i.get("quarantine_path") == new_path
                     for i in load_json(QUARANTINE_INDEX))
            if ok:
                db = candidate
                secure_delete(old_path)
                migrated += 1
            else:
                secure_delete(new_path)
                save_json(QUARANTINE_INDEX, db)
                STATE.log(f"[격리소 전환 실패] 격리 목록을 저장하지 못했습니다: {old_path}")
        if migrated:
            STATE.log(f"[격리소 전환 완료] 기존 격리 파일 {migrated}개를 변조 저장 방식으로 바꿨습니다.")


# ---------- 격리소 자동 청소 ----------
# ---------- 루트킷 점검 (rkhunter) ----------
# YARA/ClamAV 는 "이 파일이 악성이냐"를 실시간으로 보고, rkhunter 는 "이 시스템 자체가 이미
# 해킹당했느냐"를 하루 한 번 정도 정밀 점검한다 (시스템 명령어 변조, 숨겨진 프로세스, 의심스러운
# 커널 모듈/포트 등). 파일 하나하나를 실시간으로 보는 게 아니라 전체 점검이라 몇 분씩 걸린다.
RKHUNTER_RESULT_FILE = "/var/log/snhpiguard/rkhunter_last.json"
RKHUNTER_CHECK_INTERVAL_SEC = 24 * 3600
RKHUNTER_CHECK_TIMEOUT_SEC = 900   # 15분
RKHUNTER_STARTUP_DELAY_SEC = 120   # 데몬이 막 시작했을 때는 다른 초기화가 끝나길 기다렸다가 시작


class RkhunterChecker:
    def __init__(self):
        self.running = False
        self._lock = threading.Lock()
        self.last_result = self._load_last()

    def _load_last(self):
        try:
            with open(RKHUNTER_RESULT_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None

    def _save_last(self, result):
        try:
            with open(RKHUNTER_RESULT_FILE, "w", encoding="utf-8") as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def available(self):
        return shutil.which("rkhunter") is not None

    def run_check_async(self, manual=False):
        with self._lock:
            if self.running:
                return False
            self.running = True
        threading.Thread(target=self._run, args=(manual,), daemon=True).start()
        return True

    def _run(self, manual):
        try:
            if not self.available():
                STATE.log("[루트킷 검사] rkhunter 가 설치돼 있지 않아 점검을 건너뜁니다.")
                return
            label = "수동" if manual else "정기"
            STATE.log(f"[루트킷 검사] {label} 점검을 시작합니다 (몇 분 정도 걸릴 수 있습니다)")
            try:
                r = subprocess.run(
                    ["rkhunter", "--check", "--skip-keypress", "--nocolors", "--report-warnings-only"],
                    capture_output=True, text=True, timeout=RKHUNTER_CHECK_TIMEOUT_SEC
                )
                output = (r.stdout or "") + (r.stderr or "")
            except subprocess.TimeoutExpired:
                STATE.log(f"[루트킷 검사] 점검이 {RKHUNTER_CHECK_TIMEOUT_SEC}초 제한을 넘어 중단했습니다.")
                return
            except Exception as e:
                STATE.log(f"[루트킷 검사] 실행 실패: {e}")
                return

            warnings = [line.strip() for line in output.splitlines() if "Warning:" in line]
            result = {
                "time": now(),
                "manual": manual,
                "warning_count": len(warnings),
                "warnings": warnings[:200],
            }
            self.last_result = result
            self._save_last(result)
            if warnings:
                STATE.log(f"[루트킷 검사] 점검 완료 - 경고 {len(warnings)}개 발견. "
                          f"GUI 의 [시스템 점검] 에서 자세히 볼 수 있습니다.")
            else:
                STATE.log("[루트킷 검사] 점검 완료 - 경고 없음.")
        finally:
            with self._lock:
                self.running = False

    def status(self):
        return {"available": self.available(), "running": self.running, "last": self.last_result}


RKHUNTER = RkhunterChecker()


def rkhunter_check_loop():
    time.sleep(RKHUNTER_STARTUP_DELAY_SEC)
    while True:
        RKHUNTER.run_check_async(manual=False)
        time.sleep(RKHUNTER_CHECK_INTERVAL_SEC)


def cleanup_old_quarantine():
    """QUARANTINE_RETENTION_DAYS(30일) 보다 오래된 격리 파일을 자동으로 영구 삭제한다.
    시스템 파일 보호 항목(quarantine_path 가 없는 것)은 손대지 않는다 - 그건 사용자가 직접 지워야 한다."""
    cutoff = datetime.now() - timedelta(days=QUARANTINE_RETENTION_DAYS)
    removed = 0
    with QUARANTINE_LOCK:
        db = load_json(QUARANTINE_INDEX)
        keep = []
        for item in db:
            q_path = item.get("quarantine_path")
            if not q_path:
                keep.append(item)   # 시스템 파일 보호 항목 - 자동으로 건드리지 않음
                continue
            try:
                ts = datetime.strptime(item.get("time", ""), "%Y-%m-%d %H:%M:%S")
            except Exception:
                keep.append(item)   # 시각을 알 수 없으면 안전하게 그대로 둔다
                continue
            if ts >= cutoff:
                keep.append(item)
                continue
            if secure_delete(q_path):
                removed += 1
            else:
                keep.append(item)
        if removed:
            save_json(QUARANTINE_INDEX, keep)
    if removed:
        STATE.log(f"[격리소 자동 청소] {QUARANTINE_RETENTION_DAYS}일 지난 격리 파일 {removed}개를 자동으로 영구 삭제했습니다.")


def quarantine_cleanup_loop():
    time.sleep(60)   # 다른 초기화가 끝나길 잠깐 기다렸다가 시작
    while True:
        try:
            cleanup_old_quarantine()
        except Exception as e:
            STATE.log(f"[격리소 자동 청소 오류] {e}")
        time.sleep(QUARANTINE_CLEANUP_INTERVAL_SEC)


# ---------- USB/외장 드라이브 자동 검사 ----------
# ---------- Maldet (Linux Malware Detect) ----------
# YARA/ClamAV/rkhunter 와 다시 다른 각도: 웹쉘/PHP 악성코드/서버형 악성코드에 특화된 자체
# 시그니처를 쓴다. 시작 오버헤드가 커서 파일 하나마다 실시간으로 돌리기엔 안 맞아서, rkhunter처럼
# 정기적으로(또는 수동으로) 지정 폴더를 훑고, 걸린 파일은 SnhPiGuard 자체 격리 시스템으로 넘긴다
# (maldet 자체 격리는 꺼 두도록 설치 스크립트에서 quarantine_hits=0 으로 설정한다).
MALDET_BIN_CANDIDATES = ("/usr/local/sbin/maldet", "maldet")
MALDET_RESULT_FILE = "/var/log/snhpiguard/maldet_last.json"
MALDET_SCAN_TIMEOUT_SEC = 1800    # 30분
MALDET_SCAN_INTERVAL_SEC = 24 * 3600
MALDET_STARTUP_DELAY_SEC = 180
MALDET_DEFAULT_TARGETS = ("/home", "/tmp", "/var/www")   # 존재하는 폴더만 실제로 검사한다

# maldet 자체 스캔 출력의 "FILE HIT LIST:" 아래에 "{TAG}시그니처이름 : /경로" 형태로 한 줄씩 나온다.
_MALDET_HIT_RE = re.compile(r'^\{[A-Za-z0-9_.]+\}\S+\s*:\s*(/\S+)', re.M)
_MALDET_SIG_RE = re.compile(r'^(\{[A-Za-z0-9_.]+\}\S+)\s*:\s*/\S+', re.M)
_MALDET_TOTAL_RE = re.compile(r'TOTAL\s+HITS?\s*:\s*(\d+)', re.I)


def _maldet_bin():
    for c in MALDET_BIN_CANDIDATES:
        if c.startswith("/"):
            if os.path.isfile(c) and os.access(c, os.X_OK):
                return c
        else:
            p = shutil.which(c)
            if p:
                return p
    return None


class MaldetScanner:
    def __init__(self):
        self.running = False
        self._lock = threading.Lock()
        self.last_result = self._load_last()

    def _load_last(self):
        try:
            with open(MALDET_RESULT_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None

    def _save_last(self, result):
        try:
            with open(MALDET_RESULT_FILE, "w", encoding="utf-8") as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def available(self):
        return _maldet_bin() is not None

    def run_scan_async(self, targets=None, manual=False):
        with self._lock:
            if self.running:
                return False
            self.running = True
        threading.Thread(target=self._run, args=(targets, manual), daemon=True).start()
        return True

    def _run(self, targets, manual):
        try:
            bin_path = _maldet_bin()
            if not bin_path:
                STATE.log("[Maldet 검사] maldet 이 설치돼 있지 않아 점검을 건너뜁니다.")
                return
            paths = [t for t in (targets or MALDET_DEFAULT_TARGETS) if os.path.isdir(t)]
            if not paths:
                STATE.log("[Maldet 검사] 검사할 폴더가 없어 건너뜁니다.")
                return

            label = "수동" if manual else "정기"
            STATE.log(f"[Maldet 검사] {label} 점검을 시작합니다 ({', '.join(paths)}) - 폴더 크기에 따라 오래 걸릴 수 있습니다")
            try:
                r = subprocess.run([bin_path, "-a"] + paths, capture_output=True, text=True,
                                    timeout=MALDET_SCAN_TIMEOUT_SEC)
                output = (r.stdout or "") + (r.stderr or "")
            except subprocess.TimeoutExpired:
                STATE.log(f"[Maldet 검사] 점검이 {MALDET_SCAN_TIMEOUT_SEC}초 제한을 넘어 중단했습니다.")
                return
            except Exception as e:
                STATE.log(f"[Maldet 검사] 실행 실패: {e}")
                return

            m = _MALDET_TOTAL_RE.search(output)
            reported_total = int(m.group(1)) if m else None
            sig_matches = _MALDET_SIG_RE.findall(output)
            path_matches = _MALDET_HIT_RE.findall(output)
            hits = list(zip(sig_matches, path_matches))

            quarantined = 0
            for sig, path in hits:
                if os.path.isfile(path):
                    item = quarantine_file_daemon(path, f"Maldet:{sig}")
                    if item:
                        quarantined += 1

            result = {
                "time": now(),
                "manual": manual,
                "targets": paths,
                "reported_total_hits": reported_total,
                "parsed_hits": len(hits),
                "quarantined": quarantined,
            }
            self.last_result = result
            self._save_last(result)

            if hits:
                STATE.log(f"[Maldet 검사] 점검 완료 - {len(hits)}개 탐지, {quarantined}개 격리했습니다.")
            elif reported_total:
                STATE.log(f"[Maldet 검사] 점검 완료 - maldet 이 {reported_total}건을 보고했지만 파일 경로를 "
                          f"정확히 읽어내지 못했습니다. 'sudo maldet --report list' 로 직접 확인하세요.")
            else:
                STATE.log("[Maldet 검사] 점검 완료 - 탐지 없음.")
        finally:
            with self._lock:
                self.running = False

    def status(self):
        return {"available": self.available(), "running": self.running, "last": self.last_result}


MALDET = MaldetScanner()


def maldet_scan_loop():
    time.sleep(MALDET_STARTUP_DELAY_SEC)
    while True:
        MALDET.run_scan_async(manual=False)
        time.sleep(MALDET_SCAN_INTERVAL_SEC)


class UsbAutoScanner:
    """
    /proc/mounts 를 주기적으로 살펴 /media, /mnt, /run/media 아래에 새로 마운트되는 지점을 찾아
    자동으로 전체 검사를 건다 (기존 '전체 검사'와 같은 run_scan_worker 를 그대로 사용하므로
    GUI 의 진행률 표시/중지 버튼이 USB 자동 검사에도 똑같이 적용된다).
    데몬이 시작되는 시점에 이미 꽂혀 있는 드라이브는 "새로 꽂힌 것"이 아니므로 검사하지 않는다.
    """

    def __init__(self):
        self._known_mounts = set()
        self._pending = []
        self._lock = threading.Lock()
        self._stop_flag = threading.Event()
        self._thread = None

    def _current_removable_mounts(self):
        mounts = set()
        try:
            with open("/proc/mounts", "r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    parts = line.split()
                    if len(parts) < 3:
                        continue
                    mp = parts[1].replace("\\040", " ")
                    fstype = parts[2]
                    if fstype in USB_SCAN_IGNORE_FS:
                        continue
                    for root in USB_SCAN_ROOTS:
                        if mp != root and mp.startswith(root + "/"):
                            mounts.add(mp)
                            break
        except Exception:
            pass
        return mounts

    def start(self):
        with self._lock:
            self._known_mounts = self._current_removable_mounts()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop_flag.set()

    def _loop(self):
        while not self._stop_flag.wait(USB_SCAN_POLL_INTERVAL_SEC):
            current = self._current_removable_mounts()
            with self._lock:
                new_ones = current - self._known_mounts
                gone_ones = self._known_mounts - current
                self._known_mounts = current
                for mp in new_ones:
                    self._pending.append(mp)
                for mp in gone_ones:
                    if mp in self._pending:
                        self._pending.remove(mp)

            if not self._pending or STATE.is_scanning:
                continue

            with self._lock:
                mp = self._pending.pop(0) if self._pending else None
            if not mp or not os.path.isdir(mp):
                continue

            STATE.log(f"[USB 자동 검사] 새 드라이브 감지: {mp} - 잠시 후 검사를 시작합니다")
            time.sleep(USB_SCAN_SETTLE_SEC)
            if not os.path.isdir(mp) or STATE.is_scanning:
                # 그새 다른 검사가 시작됐으면 이번엔 넘어가고, 다음 주기에 이 드라이브가 여전히
                # 꽂혀 있으면(=known_mounts 에 남아 있으면) 다시 시도하도록 pending 에 되돌려 놓는다
                with self._lock:
                    if mp in self._known_mounts and mp not in self._pending:
                        self._pending.append(mp)
                continue
            threading.Thread(
                target=run_scan_worker,
                args=([mp], f"USB 자동 검사 ({os.path.basename(mp)})"),
                daemon=True,
            ).start()


USB_AUTO_SCANNER = UsbAutoScanner()


# =====================================================================
#  보호된 폴더 액세스 (Controlled Folder Access)
#
#  * 생성/수정(쓰기 open) : Linux fanotify의 "permission event"
#    (FAN_OPEN_PERM)를 이용해 커널이 실제로 open() 호출을 완료하기
#    "전"에 막아 둔 상태에서 확인창을 띄우고, 사용자가 [확인]을 눌러야만
#    프로세스에 파일이 열린다 -> 진짜 차단/허용이다.
#
#  * 삭제(delete) : 리눅스 fanotify에는 unlink(삭제)를 사전에 막는
#    permission event가 존재하지 않는다 (open/access만 가능). 따라서
#    삭제는 사전 차단이 불가능하며, 대신 보호 폴더의 파일을 수정할
#    때마다 그림자 사본을 만들어 두었다가, watchdog으로 삭제를 "감지한
#    즉시" 확인창을 띄워 [복구]/[삭제 유지]를 선택하게 하는 방식으로
#    동작한다 (사실상 즉시 복구 가능한 안전장치).
# =====================================================================

FANOTIFY_OK = False
try:
    _libc = ctypes.CDLL(ctypes.util.find_library("c"), use_errno=True)

    FAN_CLASS_CONTENT = 0x00000004
    FAN_CLOEXEC = 0x00000001
    FAN_NONBLOCK = 0x00000002
    O_RDONLY = 0
    # O_LARGEFILE 값은 아키텍처마다 다르다 (x86: 0o100000, ARM/라즈베리파이: 0o400000).
    # 하드코딩하면 ARM 에서 O_NOFOLLOW 로 해석되어 fanotify_init 이 EINVAL 로 실패하므로
    # Python 이 제공하는 값을 사용한다 (없으면 0 - 커널이 알아서 처리).
    O_LARGEFILE = getattr(os, "O_LARGEFILE", 0)

    FAN_OPEN_PERM = 0x00010000
    FAN_ACCESS_PERM = 0x00020000
    FAN_ALLOW = 0x01
    FAN_DENY = 0x02

    FAN_MARK_ADD = 0x00000001
    FAN_MARK_ONLYDIR = 0x00000008

    _libc.fanotify_init.restype = ctypes.c_int
    _libc.fanotify_init.argtypes = [ctypes.c_uint, ctypes.c_uint]

    _libc.fanotify_mark.restype = ctypes.c_int
    _libc.fanotify_mark.argtypes = [
        ctypes.c_int, ctypes.c_uint, ctypes.c_uint64,
        ctypes.c_int, ctypes.c_char_p
    ]
    FANOTIFY_OK = True
except Exception:
    FANOTIFY_OK = False

# struct fanotify_event_metadata (glibc/linux 고정 레이아웃, 24바이트)
_EVENT_FMT = "IBBHQii"
_EVENT_LEN = struct.calcsize(_EVENT_FMT)
# struct fanotify_response
_RESP_FMT = "iI"
_RESP_LEN = struct.calcsize(_RESP_FMT)

AT_FDCWD = -100


class ProtectedFolderGuard:
    """fanotify permission event로 보호 폴더에 대한 쓰기/생성 open()을 가로막는다."""

    def __init__(self):
        self.fd = -1
        self.thread = None
        self.running = False
        self.marked_dirs = set()

    def available(self):
        return FANOTIFY_OK

    def start(self):
        if not FANOTIFY_OK:
            STATE.log("[보호된 폴더] 이 커널/환경에서는 fanotify를 사용할 수 없어 실시간 차단을 켤 수 없습니다.")
            return False
        if self.running:
            return True

        try:
            self.fd = _libc.fanotify_init(FAN_CLASS_CONTENT, O_RDONLY | O_LARGEFILE)
            if self.fd < 0:
                errno = ctypes.get_errno()
                STATE.log(f"[보호된 폴더] fanotify_init 실패 (root 권한/커널 지원 필요, errno={errno})")
                return False
        except Exception as e:
            STATE.log(f"[보호된 폴더] fanotify_init 예외: {e}")
            return False

        self._remark_all()
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()
        STATE.log("[보호된 폴더] 실시간 쓰기/생성 차단이 활성화되었습니다.")
        return True

    def stop(self):
        self.running = False
        if self.fd >= 0:
            try:
                os.close(self.fd)
            except Exception:
                pass
            self.fd = -1
        self.marked_dirs.clear()
        STATE.log("[보호된 폴더] 실시간 쓰기/생성 차단이 중지되었습니다.")

    def _remark_all(self):
        for folder in load_protected_folders():
            self._mark_dir(folder)

    def _mark_dir(self, folder):
        if not os.path.isdir(folder) or folder in self.marked_dirs:
            return
        try:
            mask = FAN_OPEN_PERM
            r = _libc.fanotify_mark(
                self.fd, FAN_MARK_ADD | FAN_MARK_ONLYDIR, mask,
                AT_FDCWD, folder.encode("utf-8")
            )
            if r == 0:
                self.marked_dirs.add(folder)
                STATE.log(f"[보호된 폴더] 감시 등록됨: {folder}")
            else:
                STATE.log(f"[보호된 폴더] 감시 등록 실패: {folder}")
        except Exception as e:
            STATE.log(f"[보호된 폴더] 감시 등록 예외 {folder}: {e}")

    def refresh_marks(self):
        """protected_folders.json이 바뀐 뒤 새 폴더를 추가로 마크한다."""
        if self.running:
            self._remark_all()

    def _respond(self, event_fd, allow):
        try:
            resp = struct.pack(_RESP_FMT, event_fd, FAN_ALLOW if allow else FAN_DENY)
            os.write(self.fd, resp)
        except Exception as e:
            STATE.log(f"[보호된 폴더] 응답 전송 실패: {e}")

    def _loop(self):
        buf_size = 4096
        while self.running:
            try:
                data = os.read(self.fd, buf_size)
            except OSError:
                if self.running:
                    time.sleep(0.2)
                continue
            except Exception:
                break

            offset = 0
            while offset + _EVENT_LEN <= len(data):
                event_len, vers, reserved, metadata_len, mask, event_fd, pid = struct.unpack_from(_EVENT_FMT, data, offset)
                offset += event_len if event_len >= _EVENT_LEN else _EVENT_LEN

                if event_fd < 0:
                    continue

                self._handle_event(event_fd, mask, pid)

    def _handle_event(self, event_fd, mask, pid):
        filepath = ""
        proc_path = ""
        try:
            filepath = os.readlink(f"/proc/self/fd/{event_fd}")
        except Exception:
            pass
        try:
            proc_path = os.readlink(f"/proc/{pid}/exe")
        except Exception:
            proc_path = f"pid:{pid}"

        try:
            # 쓰기 목적의 open()인지 확인 (읽기 전용 open은 통과시켜 성능/오탐 최소화)
            flags = fcntl.fcntl(event_fd, fcntl.F_GETFL)
            accmode = flags & os.O_ACCMODE
            is_write_open = accmode in (os.O_WRONLY, os.O_RDWR)
        except Exception:
            is_write_open = True  # 판정 불가 시 안전하게 쓰기로 간주

        if not is_write_open:
            self._respond(event_fd, True)
            os.close(event_fd)
            return

        trusted = os.path.abspath(proc_path) in load_trusted_apps() if proc_path.startswith("/") else False

        if trusted:
            self._respond(event_fd, True)
            os.close(event_fd)
            return

        # 신뢰되지 않은 프로그램의 쓰기 요청: 확인창을 띄우는 동안 프로세스가
        # 실제로 멈춰 있어야 하므로(=진짜 차단), fanotify 읽기 루프는 계속
        # 다른 이벤트를 처리할 수 있도록 별도 스레드에서 확인창을 띄우고
        # 응답한다. event_fd는 응답을 보낼 때까지 절대 먼저 닫지 않는다.
        threading.Thread(
            target=self.prompt_and_respond,
            args=(event_fd, filepath, proc_path),
            daemon=True
        ).start()

    def prompt_and_respond(self, event_fd, filepath, proc_path):
        allow, remember = ask_user_confirm("write", filepath, proc_path)
        self._respond(event_fd, allow)
        try:
            os.close(event_fd)
        except Exception:
            pass
        if remember and proc_path.startswith("/"):
            add_trusted_app(proc_path)
            STATE.log(f"[보호된 폴더] 항상 허용으로 등록됨: {proc_path}")
        record_block_event("write", "allowed" if allow else "denied", filepath, proc_path)
        if allow:
            STATE.log(f"[보호된 폴더 허용] {filepath} <- {proc_path} (사용자 확인)")
            snapshot_for_shadow(filepath)
        else:
            STATE.log(f"[보호된 폴더 차단] {filepath} <- {proc_path} (사용자 거부)")


GUARD = ProtectedFolderGuard()


def snapshot_for_shadow(filepath):
    """삭제 대비 그림자 사본을 1개만 유지 (최신본)."""
    try:
        if not os.path.isfile(filepath):
            return
        key = filepath.replace(os.sep, "___")
        dest = os.path.join(SHADOW_DIR, key)
        os.makedirs(SHADOW_DIR, exist_ok=True)
        shutil.copy2(filepath, dest)
    except Exception:
        pass


def restore_from_shadow(filepath):
    key = filepath.replace(os.sep, "___")
    src = os.path.join(SHADOW_DIR, key)
    if os.path.exists(src):
        try:
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            shutil.copy2(src, filepath)
            return True
        except Exception:
            return False
    return False


class ProtectedDeleteHandler(FileSystemEventHandler):
    """보호 폴더 내 삭제를 감지(사후)하고, 즉시 복구 여부를 확인창으로 묻는다."""

    def on_deleted(self, event):
        if event.is_directory:
            return
        filepath = event.src_path
        threading.Thread(target=self._handle_delete, args=(filepath,), daemon=True).start()

    def _handle_delete(self, filepath):
        proc_path = "알 수 없음 (삭제는 사전 차단이 불가능하여 삭제 프로세스를 특정할 수 없습니다)"
        allow_delete, _ = ask_user_confirm("delete", filepath, proc_path)
        if not allow_delete:
            restored = restore_from_shadow(filepath)
            record_block_event("delete", "restored" if restored else "denied", filepath, proc_path)
            if restored:
                STATE.log(f"[보호된 폴더 복구] {filepath} 삭제가 취소되어 그림자 사본에서 복구되었습니다.")
            else:
                STATE.log(f"[보호된 폴더 복구 실패] {filepath} 그림자 사본이 없어 복구할 수 없습니다.")
        else:
            record_block_event("delete", "kept_deleted", filepath, proc_path)
            STATE.log(f"[보호된 폴더] {filepath} 삭제가 사용자 확인으로 유지되었습니다.")


class DeleteWatchManager:
    def __init__(self):
        self.observer = None
        self.running = False

    def start(self):
        if not WATCHDOG_OK or self.running:
            return
        self.observer = Observer()
        for folder in load_protected_folders():
            if os.path.isdir(folder):
                self.observer.schedule(ProtectedDeleteHandler(), folder, recursive=True)
        self.observer.start()
        self.running = True

    def stop(self):
        if self.observer:
            self.observer.stop()
            self.observer.join(timeout=3)
            self.observer = None
        self.running = False

    def restart(self):
        self.stop()
        self.start()


DELETE_WATCH = DeleteWatchManager()


class DaemonState:
    def __init__(self):
        self.lock = threading.Lock()
        self.status = "대기 중"
        self.is_scanning = False
        self.current_job = ""
        self.current_file = ""
        self.logs = []
        self.smart_active = False
        self.smart_target = ""
        self.stop_requested = False
        self.stopping = False        # 사용자가 중지를 눌렀지만 아직 실제로 멈추지 않은 상태
        self.scanned_count = 0
        self.total_count = 0
        self.observer = None
        self.watch_handler = None
        self.auto_update_on = True
        self.protection_active = False

        self.log("SnhPiGuard 시작됨 - 실시간: YARA+ClamAV / 정기점검: rkhunter+Maldet")

    def log(self, msg):
        line = f"[{now()}] {msg}"
        with self.lock:
            self.logs.append(line)
            if len(self.logs) > 1000:
                self.logs.pop(0)
        try:
            with open(LOG_FILE, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            pass

    def get_dict(self):
        with self.lock:
            return {
                "status": self.status,
                "is_scanning": self.is_scanning,
                "current_job": self.current_job,
                "current_file": self.current_file,
                "logs": list(self.logs),
                "quarantine_list": load_json(QUARANTINE_INDEX),
                "whitelist": load_json(WHITELIST_INDEX),
                "stopping": self.stopping,
                "scanned_count": self.scanned_count,
                "total_count": self.total_count,
                "smart_active": self.smart_active,
                "smart_target": self.smart_target,
                "auto_update": self.auto_update_on,
                "protection_active": self.protection_active,
                "protected_folders": load_protected_folders(),
                "trusted_apps": load_trusted_apps(),
                "protection_events": load_json(BLOCK_EVENTS_INDEX)[-100:],
                "fanotify_available": FANOTIFY_OK,
                "rkhunter": RKHUNTER.status(),
                "maldet": MALDET.status(),
            }


STATE = DaemonState()
YARA_ENGINE = YaraScanner(YARA_RULES_DIR)


def dual_scan_single_file(filepath):
    if not os.path.isfile(filepath) or is_whitelisted(filepath):
        return False, None

    found, sig = YARA_ENGINE.scan_file(filepath)
    if found:
        return True, sig

    found, sig = scan_file_clamav(filepath)
    if found:
        return True, sig

    return False, None


# ---------- 압축 파일 내부 검사 (zip / tar류 / gz·bz2·xz 단일파일 / 7z / rar) ----------
# 압축을 푼 뒤 내용을 바로 검사하고, 검사가 끝나는 즉시 안전 삭제(secure_delete)합니다.
# "다시 압축해서 검사"는 하지 않습니다 - 다시 압축한 파일을 검사하면 그 압축 형식만 확인하는
# 셈이라 안의 악성코드는 그대로 통과하고, 평문 파일이 디스크에 남는 시간만 늘어나 더 위험합니다.
ARCHIVE_SCAN_ROOT = os.path.join(QUARANTINE_DIR, "archive_scan_tmp")   # root 전용(0700) 임시 해제 공간
ARCHIVE_MAX_TOTAL_BYTES = 200 * 1024 * 1024   # 압축 하나당 실제로 풀어서 검사할 총 용량 한도 (압축 폭탄 방지)
ARCHIVE_MAX_SINGLE_FILE_BYTES = 100 * 1024 * 1024
ARCHIVE_MAX_FILES = 2000
ARCHIVE_MAX_DEPTH = 3          # 압축 안에 압축이 또 있는 경우 여기까지만 따라 들어간다
ARCHIVE_SCAN_TIMEOUT_SEC = 120
ARCHIVE_EXTRACT_CHUNK = 1024 * 1024
ARCHIVE_MONITOR_INTERVAL_SEC = 0.5   # 외부 도구(7z/unrar) 해제 중 용량을 얼마나 자주 확인할지

# 이 확장자로 끝나면 압축 해제 후 이름에서 확장자를 벗겨 저장한다 (gzip/bzip2/xz 단일 파일용)
_SINGLEFILE_EXT_RE = re.compile(r'\.(gz|bz2|xz)$', re.I)


def _read_magic(filepath, n=8):
    try:
        with open(filepath, "rb") as f:
            return f.read(n)
    except Exception:
        return b""


def detect_archive_kind(filepath):
    """확장자가 아니라 실제 내용(매직 바이트/구조)으로 압축 형식을 판단한다 (이름을 바꿔도 걸리도록)."""
    if not os.path.isfile(filepath) or os.path.islink(filepath):
        return None
    try:
        if zipfile.is_zipfile(filepath):
            return "zip"
    except Exception:
        pass

    magic = _read_magic(filepath, 8)
    if magic[:6] == b"7z\xbc\xaf\x27\x1c":
        return "sevenzip"
    if magic[:6] == b"Rar!\x1a\x07":
        return "rar"

    # tar 는 압축이 없거나(gz/bz2/xz) 여러 방식이 섞여 있을 수 있어 직접 열어서 확인한다.
    # (아래 gz/bz2/xz 단일 파일 판정보다 먼저 해야 tar.gz 를 "gzip 단일 파일"로 오판하지 않는다)
    try:
        with tarfile.open(filepath, mode="r:*") as tf:
            tf.getmembers()[:1]
        return "tar"
    except Exception:
        pass

    if magic[:2] == b"\x1f\x8b":
        return "gzip"
    if magic[:3] == b"BZh":
        return "bzip2"
    if magic[:6] == b"\xfd7zXZ\x00":
        return "xz"
    return None


def is_supported_archive(filepath):
    return detect_archive_kind(filepath) is not None


def cleanup_archive_scan_root():
    """데몬 시작 시, 이전 실행이 비정상 종료돼 남은 임시 해제 파일을 정리한다."""
    if not os.path.isdir(ARCHIVE_SCAN_ROOT):
        return
    for root, dirs, files in os.walk(ARCHIVE_SCAN_ROOT, topdown=False):
        for fn in files:
            secure_delete(os.path.join(root, fn))
        for dn in dirs:
            try:
                os.rmdir(os.path.join(root, dn))
            except Exception:
                pass


def _safe_member_target(dest_dir, dest_abs, raw_name, archive_path, kind_label):
    """압축 항목 이름을 검사해서 dest_dir 밖으로 나가지 않는 실제 저장 경로를 돌려준다. 위험하면 None."""
    name = raw_name.replace("\\", "/")
    parts = [p for p in name.split("/") if p not in ("", ".")]
    if not parts or ".." in parts:
        STATE.log(f"[압축 검사] 위험한 경로를 건너뜁니다: {archive_path} -> {raw_name}")
        return None
    target = os.path.join(dest_dir, *parts)
    target_abs = os.path.abspath(target)
    if not (target_abs == dest_abs or target_abs.startswith(dest_abs + os.sep)):
        STATE.log(f"[압축 검사] 위험한 경로를 건너뜁니다: {archive_path} -> {raw_name}")
        return None
    return target


def _stream_to_target(src_read, target, budget, deadline, archive_path, member_name):
    """src_read(size)->bytes 함수로 target 에 스트리밍 저장. 한도 초과/시간 초과/중지 요청이면 None, 성공하면 기록한 바이트 수."""
    if time.monotonic() > deadline or STATE.stop_requested:
        return None
    written = 0
    try:
        fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, "wb") as out:
            while True:
                # 파일 하나가 커서 청크가 여러 번 나뉘어도, 매 청크마다 확인하므로 큰 파일 도중에도
                # "검사 중지"를 누르면 다음 청크에서 바로(1MB 안에) 멈춘다.
                if STATE.stop_requested:
                    out.close()
                    _remove_quietly(target)
                    return None
                chunk = src_read(ARCHIVE_EXTRACT_CHUNK)
                if not chunk:
                    break
                written += len(chunk)
                # 실제로 쓰인 바이트 기준 한도 검사 (선언된 크기는 위조될 수 있음)
                if written > ARCHIVE_MAX_SINGLE_FILE_BYTES or written > budget["bytes"] or time.monotonic() > deadline:
                    STATE.log(f"[압축 검사] 압축 해제 중 한도를 초과해 중단합니다: {archive_path} -> {member_name}")
                    out.close()
                    _remove_quietly(target)
                    return None
                out.write(chunk)
    except Exception as e:
        STATE.log(f"[압축 검사] 압축 해제 실패({member_name}): {e}")
        _remove_quietly(target)
        return None
    return written


def _zip_extract_safely(zip_path, dest_dir, budget, deadline, password=None):
    extracted = []
    dest_abs = os.path.abspath(dest_dir)
    pwd_bytes = password.encode("utf-8", "surrogateescape") if password else None
    try:
        with zipfile.ZipFile(zip_path) as zf:
            for info in zf.infolist():
                if info.is_dir():
                    continue
                if STATE.stop_requested:
                    STATE.log(f"[압축 검사] 사용자 중지 요청으로 나머지는 풀지 않습니다: {zip_path}")
                    break
                if time.monotonic() > deadline:
                    STATE.log(f"[압축 검사] 검사 시간 초과로 나머지는 풀지 않습니다: {zip_path}")
                    break
                if budget["files"] <= 0 or budget["bytes"] <= 0:
                    STATE.log(f"[압축 검사] 파일 개수/용량 한도를 넘어 나머지는 검사하지 않습니다: {zip_path}")
                    break
                # 심볼릭 링크 항목(유닉스 zip)은 밖의 임의 경로를 가리킬 수 있으므로 만들지 않는다
                if (info.external_attr >> 16) & 0o170000 == 0o120000:
                    STATE.log(f"[압축 검사] 심볼릭 링크 항목을 건너뜁니다: {zip_path} -> {info.filename}")
                    continue
                target = _safe_member_target(dest_dir, dest_abs, info.filename, zip_path, "zip")
                if target is None:
                    continue
                if info.file_size > ARCHIVE_MAX_SINGLE_FILE_BYTES or info.file_size > budget["bytes"]:
                    STATE.log(f"[압축 검사] 파일이 너무 커서 건너뜁니다: {zip_path} -> {info.filename}")
                    continue
                os.makedirs(os.path.dirname(target) or dest_dir, exist_ok=True)
                try:
                    with zf.open(info, pwd=pwd_bytes) as src:
                        written = _stream_to_target(src.read, target, budget, deadline, zip_path, info.filename)
                except Exception as e:
                    STATE.log(f"[압축 검사] 압축 해제 실패({info.filename}): {e}")
                    written = None
                if written is None:
                    continue
                budget["files"] -= 1
                budget["bytes"] -= written
                extracted.append(target)
    except Exception as e:
        STATE.log(f"[압축 검사] 압축 파일을 열 수 없습니다: {zip_path}: {e}")
    return extracted


def _tar_extract_safely(archive_path, dest_dir, budget, deadline):
    extracted = []
    dest_abs = os.path.abspath(dest_dir)
    try:
        with tarfile.open(archive_path, mode="r:*") as tf:
            for member in tf:
                if STATE.stop_requested:
                    STATE.log(f"[압축 검사] 사용자 중지 요청으로 나머지는 풀지 않습니다: {archive_path}")
                    break
                if time.monotonic() > deadline:
                    STATE.log(f"[압축 검사] 검사 시간 초과로 나머지는 풀지 않습니다: {archive_path}")
                    break
                if budget["files"] <= 0 or budget["bytes"] <= 0:
                    STATE.log(f"[압축 검사] 파일 개수/용량 한도를 넘어 나머지는 검사하지 않습니다: {archive_path}")
                    break
                # 일반 파일만 다룬다: 디렉터리/심볼릭링크/하드링크/장치파일/파이프는 만들지 않는다
                if not member.isfile():
                    continue
                target = _safe_member_target(dest_dir, dest_abs, member.name, archive_path, "tar")
                if target is None:
                    continue
                if member.size > ARCHIVE_MAX_SINGLE_FILE_BYTES or member.size > budget["bytes"]:
                    STATE.log(f"[압축 검사] 파일이 너무 커서 건너뜁니다: {archive_path} -> {member.name}")
                    continue
                src = tf.extractfile(member)
                if src is None:
                    continue
                os.makedirs(os.path.dirname(target) or dest_dir, exist_ok=True)
                written = _stream_to_target(src.read, target, budget, deadline, archive_path, member.name)
                if written is None:
                    continue
                budget["files"] -= 1
                budget["bytes"] -= written
                extracted.append(target)
    except Exception as e:
        STATE.log(f"[압축 검사] 압축 파일을 열 수 없습니다: {archive_path}: {e}")
    return extracted


def _singlefile_extract_safely(archive_path, kind, dest_dir, budget, deadline):
    """gzip/bzip2/xz 로 압축된 단일 파일 하나를 푼다 (예: virus.exe.gz)."""
    opener = {"gzip": gzip.open, "bzip2": bz2.open, "xz": lzma.open}[kind]
    base = os.path.basename(archive_path)
    stripped = _SINGLEFILE_EXT_RE.sub("", base)
    if not stripped or stripped == base:
        stripped = "decompressed.bin"
    target = os.path.join(dest_dir, stripped)
    if os.path.exists(target):
        target = os.path.join(dest_dir, f"{stripped}.{int(time.time() * 1000)}")
    try:
        with opener(archive_path, "rb") as src:
            written = _stream_to_target(src.read, target, budget, deadline, archive_path, stripped)
    except Exception as e:
        STATE.log(f"[압축 검사] 압축 해제 실패({archive_path}): {e}")
        written = None
    if written is None:
        return []
    budget["files"] -= 1
    budget["bytes"] -= written
    return [target]


def _external_archive_tool(kind):
    names = {"sevenzip": ("7z", "7zr", "7za"), "rar": ("unrar",)}.get(kind, ())
    for name in names:
        path = shutil.which(name)
        if path:
            return path
    return None


def _shell_safe_path(path):
    return path if not path.startswith("-") else "./" + path


def _external_tool_extract_safely(archive_path, kind, dest_dir, budget, deadline, password=None):
    """
    7z/rar 는 순수 파이썬으로 다루지 않고 외부 프로그램(p7zip/unrar)으로 해제한다.
    개별 항목 스트리밍 제어가 불가능하므로, 해제하는 동안 별도 스레드가 dest_dir 의 용량/개수를
    주기적으로 재서 한도를 넘으면 그 자리에서 프로세스를 강제 종료한다 (압축 폭탄 방지).
    """
    tool = _external_archive_tool(kind)
    if not tool:
        label = "7z(p7zip)" if kind == "sevenzip" else "unrar"
        STATE.log(f"[압축 검사] {label} 프로그램이 설치되어 있지 않아 이 압축 내부를 검사하지 못했습니다: {archive_path}")
        return []

    arg_path = _shell_safe_path(archive_path)
    pwd_flag = f"-p{password}" if password else "-p-"   # 비밀번호가 없으면 대화형 프롬프트 없이 바로 실패하게 한다
    if kind == "sevenzip":
        cmd = [tool, "x", "-y", "-bd", f"-o{dest_dir}"] + ([pwd_flag] if password else []) + [arg_path]
    else:
        cmd = [tool, "x", "-y", pwd_flag, "-inul", arg_path, dest_dir + os.sep]

    remaining = deadline - time.monotonic()
    if remaining <= 0:
        STATE.log(f"[압축 검사] 검사 시간 초과로 압축 해제를 시작하지 않습니다: {archive_path}")
        return []

    try:
        proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        STATE.log(f"[압축 검사] 압축 해제 실행 실패({archive_path}): {e}")
        return []

    aborted = {"reason": None}   # "bomb" | "stopped" | None
    stop_flag = threading.Event()

    def _dir_usage():
        total = 0
        cnt = 0
        for root, _, files in os.walk(dest_dir):
            for fn in files:
                cnt += 1
                try:
                    total += os.path.getsize(os.path.join(root, fn))
                except Exception:
                    pass
        return cnt, total

    def monitor():
        # 압축 폭탄 감시와 "검사 중지" 감시를 같은 스레드에서 짧은 간격(0.5초)으로 함께 확인한다.
        # 이렇게 해야 7z/unrar 처럼 우리가 청크 단위로 제어할 수 없는 외부 프로그램도 중지 요청에
        # proc.wait() 이 끝나기 한참 전에(최대 0.5초 안에) 반응한다.
        while not stop_flag.wait(ARCHIVE_MONITOR_INTERVAL_SEC):
            if STATE.stop_requested:
                aborted["reason"] = "stopped"
                try:
                    proc.kill()
                except Exception:
                    pass
                return
            cnt, total = _dir_usage()
            if cnt > ARCHIVE_MAX_FILES or total > ARCHIVE_MAX_TOTAL_BYTES:
                aborted["reason"] = "bomb"
                try:
                    proc.kill()
                except Exception:
                    pass
                return

    mon = threading.Thread(target=monitor, daemon=True)
    mon.start()
    try:
        proc.wait(timeout=max(1, remaining))
    except subprocess.TimeoutExpired:
        STATE.log(f"[압축 검사] 검사 시간 초과로 압축 해제를 중단합니다: {archive_path}")
        try:
            proc.kill()
            proc.wait(timeout=5)
        except Exception:
            pass
    finally:
        stop_flag.set()
        mon.join(timeout=2)

    if aborted["reason"] is not None:
        if aborted["reason"] == "bomb":
            STATE.log(f"[압축 검사] 해제 용량/개수 한도를 초과해 압축 폭탄으로 간주하고 검사를 중단했습니다: {archive_path}")
        else:
            STATE.log(f"[압축 검사] 사용자 중지 요청으로 압축 해제를 중단했습니다: {archive_path}")
        for root, dirs, files in os.walk(dest_dir, topdown=False):
            for fn in files:
                secure_delete(os.path.join(root, fn))
            for dn in dirs:
                try:
                    os.rmdir(os.path.join(root, dn))
                except Exception:
                    pass
        return []

    dest_abs = os.path.abspath(dest_dir)
    extracted = []
    for root, _, files in os.walk(dest_dir):
        for fn in files:
            p = os.path.join(root, fn)
            p_abs = os.path.abspath(p)
            if not (p_abs == dest_abs or p_abs.startswith(dest_abs + os.sep)):
                continue  # 이론상 발생하지 않지만 이중 방어
            if os.path.islink(p) or not os.path.isfile(p):
                try:
                    os.remove(p) if os.path.islink(p) else secure_delete(p)
                except Exception:
                    pass
                continue
            if budget["files"] <= 0 or budget["bytes"] <= 0:
                secure_delete(p)
                continue
            try:
                sz = os.path.getsize(p)
            except Exception:
                secure_delete(p)
                continue
            if sz > ARCHIVE_MAX_SINGLE_FILE_BYTES or sz > budget["bytes"]:
                secure_delete(p)
                continue
            budget["files"] -= 1
            budget["bytes"] -= sz
            extracted.append(p)
    return extracted


# ---------- 압축 비밀번호 처리 ----------
def _archive_needs_password(filepath, kind, timeout=ARCHIVE_PASSWORD_DETECT_TIMEOUT_SEC):
    """이 압축이 비밀번호 없이는 못 여는지 빠르게 확인한다. 판단할 수 없으면 False(그냥 시도해 본다)."""
    if kind == "zip":
        try:
            with zipfile.ZipFile(filepath) as zf:
                return any((info.flag_bits & 0x1) for info in zf.infolist() if not info.is_dir())
        except Exception:
            return False
    if kind in ("sevenzip", "rar"):
        tool = _external_archive_tool(kind)
        if not tool:
            return False
        arg_path = _shell_safe_path(filepath)
        cmd = [tool, "t", arg_path] if kind == "sevenzip" else [tool, "t", "-p-", "-inul", arg_path]
        try:
            r = subprocess.run(cmd, stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=timeout)
        except Exception:
            return False
        combined = ((r.stdout or "") + (r.stderr or "")).lower()
        return r.returncode != 0 and "password" in combined
    return False


def _verify_archive_password(filepath, kind, password, timeout=ARCHIVE_PASSWORD_VERIFY_TIMEOUT_SEC):
    """사용자가 입력한 비밀번호가 실제로 맞는지 확인한다 (검사와는 별개로, 맞는지부터 빠르게 판단)."""
    if kind == "zip":
        pwd_bytes = password.encode("utf-8", "surrogateescape")
        try:
            with zipfile.ZipFile(filepath) as zf:
                for info in zf.infolist():
                    if info.is_dir() or not (info.flag_bits & 0x1):
                        continue
                    with zf.open(info, pwd=pwd_bytes) as f:
                        f.read(1)
                    return True
            return True   # 암호화된 항목이 하나도 없으면(드묾) 통과로 본다
        except Exception:
            return False
    if kind in ("sevenzip", "rar"):
        tool = _external_archive_tool(kind)
        if not tool:
            return False
        arg_path = _shell_safe_path(filepath)
        cmd = [tool, "t", f"-p{password}", arg_path] if kind == "sevenzip" \
            else [tool, "t", f"-p{password}", "-inul", arg_path]
        try:
            r = subprocess.run(cmd, stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=timeout)
        except Exception:
            return False
        return r.returncode == 0
    return False


def ask_archive_password(filepath):
    """
    로그인 세션에 비밀번호 입력창을 띄우고 기다린다.
    반환: 입력한 비밀번호 문자열, 또는 취소/시간초과/창을 띄울 수 없으면 None.
    """
    real_user, display = get_active_display_env()
    if not real_user:
        return None
    try:
        result = subprocess.run(
            ["sudo", "-u", real_user, "DISPLAY=" + display,
             "python3", PASSWORD_DIALOG_SCRIPT, filepath],
            capture_output=True, text=True, timeout=ARCHIVE_PASSWORD_DIALOG_TIMEOUT_SEC + 5,
            env={**os.environ, "DISPLAY": display}
        )
        out = result.stdout.rstrip("\n")
        if not out or out == "CANCELLED":
            return None
        return out
    except Exception:
        return None


def _password_prompt_worker(filepath, kind):
    """
    백그라운드에서 비밀번호를 물어보고, 맞으면 그 비밀번호로 이 압축을 검사한다.
    이 함수가 도는 동안에도 나머지 파일들의 검사는 그대로 계속 진행된다 (호출한 쪽을 막지 않는다).
    """
    try:
        for attempt in range(1, ARCHIVE_PASSWORD_MAX_ATTEMPTS + 1):
            if not os.path.isfile(filepath):
                STATE.log(f"[압축 검사] 비밀번호를 물어보는 동안 파일이 사라져 검사를 중단합니다: {filepath}")
                return
            password = ask_archive_password(filepath)
            if password is None:
                STATE.log(f"[압축 검사] 비밀번호 입력을 건너뛰어 이 압축은 검사하지 않았습니다: {filepath}")
                return
            if not _verify_archive_password(filepath, kind, password):
                STATE.log(f"[압축 검사] 입력한 비밀번호가 올바르지 않습니다 ({attempt}/{ARCHIVE_PASSWORD_MAX_ATTEMPTS}): {filepath}")
                continue
            found, sig = scan_archive_file(filepath, depth=0, password=password)
            if found:
                quarantine_file_daemon(filepath, sig)
            else:
                STATE.log(f"[압축 검사] 비밀번호로 내부를 검사했습니다 - 이상 없음: {filepath}")
            return
        STATE.log(f"[압축 검사] 비밀번호를 {ARCHIVE_PASSWORD_MAX_ATTEMPTS}번 시도해도 맞지 않아 검사를 포기합니다: {filepath}")
    finally:
        with _PENDING_PASSWORD_LOCK:
            _PENDING_PASSWORD_PATHS.discard(filepath)


def request_password_scan_async(filepath, kind):
    """이 압축의 비밀번호를 백그라운드에서 물어보기 시작한다 (이미 물어보는 중이면 다시 시작하지 않는다)."""
    with _PENDING_PASSWORD_LOCK:
        if filepath in _PENDING_PASSWORD_PATHS:
            return
        _PENDING_PASSWORD_PATHS.add(filepath)
    threading.Thread(target=_password_prompt_worker, args=(filepath, kind), daemon=True).start()


def scan_archive_file(filepath, depth=0, password=None):
    """
    압축 파일을 root 전용 임시 폴더에 풀어 안의 파일들을 검사한다 (zip/tar류/gz/bz2/xz/7z/rar).
    감염 파일을 찾으면 (True, "탐지시그니처 (압축 내부: 경로)") 를 반환한다.
    풀었던 파일은 검사 직후 바로 안전 삭제하며, 이 함수가 원본 압축 파일 자체를 건드리는 일은 없다.

    비밀번호가 걸린 압축(zip/7z/rar)을 만나면 - password 인자로 이미 비밀번호를 받은 게 아닌 한 -
    지금 이 파일은 건너뛰고(False, None 반환) 백그라운드에서 비밀번호를 물어보기 시작한다.
    호출한 쪽(스마트 감시/수동 검사)은 곧바로 다음 파일 검사를 이어서 진행하게 된다.
    """
    if STATE.stop_requested:
        return False, None

    if depth > ARCHIVE_MAX_DEPTH:
        STATE.log(f"[압축 검사] 중첩 깊이 한도({ARCHIVE_MAX_DEPTH})를 넘어 더 이상 열지 않습니다: {filepath}")
        return False, None

    kind = detect_archive_kind(filepath)
    if kind is None:
        return False, None

    if password is None and kind in ("zip", "sevenzip", "rar") and _archive_needs_password(filepath, kind):
        if depth == 0:
            request_password_scan_async(filepath, kind)
            STATE.log(f"[압축 검사] 비밀번호가 필요한 압축이라 지금은 건너뛰고, 다음 파일을 이어서 검사하면서 "
                      f"백그라운드에서 비밀번호를 물어봅니다: {filepath}")
        else:
            STATE.log(f"[압축 검사] 압축 안에 비밀번호가 걸린 압축이 있어 그 부분은 건너뜁니다: {filepath}")
        return False, None

    os.makedirs(ARCHIVE_SCAN_ROOT, mode=0o700, exist_ok=True)
    os.chmod(ARCHIVE_SCAN_ROOT, 0o700)
    work = tempfile.mkdtemp(prefix="z", dir=ARCHIVE_SCAN_ROOT)
    deadline = time.monotonic() + ARCHIVE_SCAN_TIMEOUT_SEC
    budget = {"files": ARCHIVE_MAX_FILES, "bytes": ARCHIVE_MAX_TOTAL_BYTES}
    try:
        if kind == "zip":
            extracted = _zip_extract_safely(filepath, work, budget, deadline, password=password)
        elif kind == "tar":
            extracted = _tar_extract_safely(filepath, work, budget, deadline)
        elif kind in ("gzip", "bzip2", "xz"):
            extracted = _singlefile_extract_safely(filepath, kind, work, budget, deadline)
        else:   # sevenzip, rar
            extracted = _external_tool_extract_safely(filepath, kind, work, budget, deadline, password=password)

        for path in extracted:
            if STATE.stop_requested:
                break
            if not os.path.isfile(path) or os.path.islink(path):
                continue
            found, sig = dual_scan_single_file(path)
            if found:
                rel = os.path.relpath(path, work)
                return True, f"{sig} (압축 내부: {rel})"
            if is_supported_archive(path):
                found, sig = scan_archive_file(path, depth=depth + 1)
                if found:
                    rel = os.path.relpath(path, work)
                    return True, f"{sig} (압축 내부: {rel})"
        return False, None
    finally:
        for root, dirs, files in os.walk(work, topdown=False):
            for fn in files:
                secure_delete(os.path.join(root, fn))
            for dn in dirs:
                try:
                    os.rmdir(os.path.join(root, dn))
                except Exception:
                    pass
        try:
            os.rmdir(work)
        except Exception:
            pass


def scan_file_including_archives(filepath):
    """일반 파일 검사(YARA+ClamAV) 후, 압축 파일이면 이어서 내부까지 검사한다."""
    found, sig = dual_scan_single_file(filepath)
    if found:
        return found, sig
    if is_supported_archive(filepath):
        return scan_archive_file(filepath)
    return False, None


class WatchHandler(FileSystemEventHandler):
    """
    생성/이동(rename) 시 바로 검사한다. 압축 파일도 이 안에서(scan_file_including_archives) 같이 풀어서 검사된다.

    브라우저 다운로드처럼 파일이 만들어진 뒤에도 계속 이어 써지는 경우, 만들어지자마자 검사하면
    아직 다 안 받아진 상태(불완전한 압축이라 안을 못 여는 상태)로 검사가 끝나버리고, 다운로드가
    마저 끝난 뒤에는 다시 검사되지 않을 수 있다. 그래서 수정(on_modified) 이벤트도 지켜보다가,
    마지막 수정 후 DEBOUNCE_SEC 동안 조용하면(=다 받아졌다고 보고) 한 번 더 검사한다.
    """
    DEBOUNCE_SEC = 2.0
    POLL_INTERVAL_SEC = 0.5

    def __init__(self):
        self._pending = {}         # path -> 마지막 수정 시각(monotonic)
        self._scanned_size = {}    # path -> 그 크기로는 이미 검사를 마쳤음 (중복 재검사 방지)
        self._lock = threading.Lock()
        self._stop_flag = threading.Event()
        self._thread = threading.Thread(target=self._debounce_loop, daemon=True)
        self._thread.start()

    def _handle(self, path):
        if not os.path.isfile(path):
            return
        infected, sig = scan_file_including_archives(path)
        if infected:
            quarantine_file_daemon(path, sig)
        try:
            size = os.path.getsize(path)
        except Exception:
            size = -1
        with self._lock:
            self._scanned_size[path] = size
            self._pending.pop(path, None)

    def on_created(self, event):
        if not event.is_directory:
            self._handle(event.src_path)

    def on_moved(self, event):
        if not event.is_directory:
            self._handle(event.dest_path)

    def on_modified(self, event):
        if event.is_directory:
            return
        with self._lock:
            self._pending[event.src_path] = time.monotonic()

    def _debounce_loop(self):
        while not self._stop_flag.wait(self.POLL_INTERVAL_SEC):
            now = time.monotonic()
            with self._lock:
                due = [p for p, t in self._pending.items() if now - t >= self.DEBOUNCE_SEC]
            for path in due:
                with self._lock:
                    still_due = self._pending.get(path)
                if still_due is None or now - still_due < self.DEBOUNCE_SEC:
                    continue   # 그 사이 또 수정됐으면 이번엔 건너뛰고 다음 주기에 다시 확인한다
                if not os.path.isfile(path):
                    with self._lock:
                        self._pending.pop(path, None)
                    continue
                try:
                    size = os.path.getsize(path)
                except Exception:
                    continue
                if self._scanned_size.get(path) == size:
                    # 이미 이 크기로 검사를 마쳤다면(예: on_created 가 이미 처리) 다시 하지 않는다
                    with self._lock:
                        self._pending.pop(path, None)
                    continue
                self._handle(path)   # 내부에서 _pending 에서도 제거한다

    def stop(self):
        self._stop_flag.set()


def run_scan_worker(targets, label):
    STATE.is_scanning = True
    STATE.stop_requested = False
    STATE.stopping = False
    STATE.current_job = label
    STATE.scanned_count = 0
    STATE.total_count = 0
    STATE.status = f"[{label}] 대상 파일 목록을 만드는 중..."
    STATE.log(f"=== {label} 시작 (메인: YARA / 보조: ClamAV) ===")

    # 1) 검사할 파일 목록을 먼저 모은다 (전체/(진행) 표시를 정확히 하기 위해).
    #    큰 폴더를 뒤지는 동안에도 중지를 누르면 그 자리에서 목록 작성을 멈춘다.
    all_files = []
    for target in targets:
        if STATE.stop_requested:
            break
        if not os.path.exists(target):
            continue
        if os.path.isfile(target):
            all_files.append(target)
            continue
        for root, _, files in os.walk(target):
            if STATE.stop_requested:
                break
            for f in files:
                all_files.append(os.path.join(root, f))

    STATE.total_count = len(all_files)
    total_infected = 0

    # 2) 실제 검사. 파일 하나하나 사이는 물론, 압축 파일 내부(zip/tar/7z/rar)를 푸는 도중에도
    #    "검사 중지"를 누르면 늦어도 1초 안팎으로(외부 도구는 최대 0.5초 감시 주기, ClamAV 는 0.2초
    #    주기) 실제로 멈춘다.
    for fpath in all_files:
        if STATE.stop_requested:
            break
        STATE.current_file = fpath
        STATE.status = f"[{label}] 검사 중 ({STATE.scanned_count + 1}/{STATE.total_count}): {fpath}"

        infected, sig = scan_file_including_archives(fpath)
        STATE.scanned_count += 1
        if infected:
            total_infected += 1
            quarantine_file_daemon(fpath, sig)

    STATE.is_scanning = False
    STATE.stopping = False
    STATE.current_job = ""
    STATE.current_file = ""
    STATE.status = "대기 중"
    if STATE.stop_requested:
        STATE.log(f"=== {label} 중지됨 ({STATE.scanned_count}/{STATE.total_count}개 검사 후) ===")
    else:
        STATE.log(f"=== {label} 완료: 총 {total_infected}건 탐지/격리 ({STATE.scanned_count}개 검사) ===")


def update_yara_rules(force):
    """
    공개 YARA 룰(ReversingLabs, Yara-Rules)을 내려받아 갱신한다 (snhpiguard_yara_update.py).
    반환: True = 룰 파일이 바뀜, False = 변화 없음/건너뜀/실패
    """
    if not os.path.isfile(YARA_UPDATER_SCRIPT):
        return False
    cmd = ["python3", YARA_UPDATER_SCRIPT]
    if not force:
        cmd += ["--min-age-hours", str(YARA_RULE_MIN_AGE_HOURS)]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
    except Exception as e:
        STATE.log(f"[YARA 룰 업데이트 실패] {e}")
        return False
    lines = [l.strip() for l in r.stdout.splitlines() if l.strip()]
    for line in lines[-4:]:
        STATE.log(f"[YARA 룰 업데이트] {line}")
    if r.returncode == 1:
        STATE.log("[YARA 룰 업데이트] 실패 - 기존 룰을 유지합니다.")
    return r.returncode == 0


def run_update_worker(force=True):
    STATE.status = "바이러스 정의 및 YARA 룰 업데이트 중..."
    STATE.log("바이러스 DB 업데이트 시작 (ClamAV freshclam + YARA Rules)")

    try:
        r = subprocess.run(["freshclam"], capture_output=True, text=True, timeout=600)
        STATE.log(f"ClamAV 업데이트 완료")
    except Exception as e:
        STATE.log(f"ClamAV 업데이트 실패: {e}")

    changed = update_yara_rules(force)
    # 수동 업데이트는 룰 파일/제외 목록을 직접 고쳤을 수도 있으므로 항상 다시 로드한다
    if changed or force:
        YARA_ENGINE.reload_rules()
        STATE.log("YARA 규칙 데이터베이스 재로드 완료")
    STATE.status = "대기 중"


def auto_update_loop():
    while True:
        time.sleep(AUTO_UPDATE_INTERVAL_SEC)
        if STATE.auto_update_on and not STATE.is_scanning:
            STATE.log("[자동 업데이트] 정기 업데이트 실행")
            run_update_worker(force=False)


def handle_client(conn):
    try:
        conn.settimeout(10)
        data = conn.recv(65536).decode('utf-8')
        if not data:
            return
        req = json.loads(data)
        cmd = req.get("cmd")
        res = {"status": "ok"}

        if cmd == "get_state":
            res["state"] = STATE.get_dict()

        elif cmd == "start_scan":
            targets = req.get("targets", [])
            label = req.get("label", "검사")
            if STATE.is_scanning:
                res = {"status": "error", "msg": f"이미 작업 진행 중입니다 ({STATE.status})"}
            else:
                threading.Thread(target=run_scan_worker, args=(targets, label), daemon=True).start()

        elif cmd == "stop_scan":
            if STATE.is_scanning and not STATE.stop_requested:
                STATE.stop_requested = True
                STATE.stopping = True
                STATE.log("사용자 중지 요청 수신 - 진행 중인 파일까지 마무리하고 멈춥니다")

        elif cmd == "update_db":
            if STATE.is_scanning:
                res = {"status": "error", "msg": "검사 중에는 업데이트할 수 없습니다."}
            else:
                threading.Thread(target=run_update_worker, daemon=True).start()

        elif cmd == "toggle_smart":
            target = req.get("target")
            if STATE.smart_active:
                if STATE.observer:
                    STATE.observer.stop()
                    STATE.observer.join(timeout=3)
                    STATE.observer = None
                if STATE.watch_handler:
                    STATE.watch_handler.stop()
                    STATE.watch_handler = None
                STATE.smart_active = False
                STATE.smart_target = ""
                STATE.log("스마트 실시간 감시 중지됨")
            else:
                if WATCHDOG_OK and target and os.path.isdir(target):
                    handler = WatchHandler()
                    STATE.observer = Observer()
                    STATE.observer.schedule(handler, target, recursive=True)
                    STATE.observer.start()
                    STATE.watch_handler = handler
                    STATE.smart_active = True
                    STATE.smart_target = target
                    STATE.log(f"스마트 실시간 감시 시작 (YARA+ClamAV, 압축 내부 포함): {target}")

        elif cmd == "restore_quarantine":
            q_ids = req.get("q_ids", [])
            res["count"] = restore_quarantine_items(q_ids)

        elif cmd == "delete_quarantine":
            q_ids = req.get("q_ids", [])
            res["count"] = delete_quarantine_items(q_ids)

        elif cmd == "remove_whitelist":
            paths = req.get("paths", [])
            res["count"] = remove_from_whitelist(paths)

        elif cmd == "add_protected_folder":
            path = req.get("path", "")
            if not path or not os.path.isdir(path):
                res = {"status": "error", "msg": "존재하는 폴더 경로를 입력하세요."}
            else:
                add_protected_folder(path)
                GUARD.refresh_marks()
                DELETE_WATCH.restart() if DELETE_WATCH.running else None
                STATE.log(f"[보호된 폴더] 목록에 추가됨: {path}")

        elif cmd == "remove_protected_folder":
            path = req.get("path", "")
            remove_protected_folder(path)
            DELETE_WATCH.restart() if DELETE_WATCH.running else None
            STATE.log(f"[보호된 폴더] 목록에서 제거됨: {path}")

        elif cmd == "add_trusted_app":
            path = req.get("path", "")
            if not path or not os.path.isfile(path):
                res = {"status": "error", "msg": "존재하는 실행 파일 경로를 입력하세요."}
            else:
                add_trusted_app(path)
                STATE.log(f"[보호된 폴더] 신뢰 앱 추가됨: {path}")

        elif cmd == "remove_trusted_app":
            path = req.get("path", "")
            remove_trusted_app(path)
            STATE.log(f"[보호된 폴더] 신뢰 앱 제거됨: {path}")

        elif cmd == "run_rkhunter_check":
            if not RKHUNTER.available():
                res = {"status": "error", "msg": "rkhunter 가 설치돼 있지 않습니다."}
            elif not RKHUNTER.run_check_async(manual=True):
                res = {"status": "error", "msg": "이미 점검이 진행 중입니다."}

        elif cmd == "run_maldet_scan":
            if not MALDET.available():
                res = {"status": "error", "msg": "maldet 이 설치돼 있지 않습니다."}
            elif not MALDET.run_scan_async(targets=req.get("targets"), manual=True):
                res = {"status": "error", "msg": "이미 점검이 진행 중입니다."}

        elif cmd == "toggle_protection":
            if STATE.protection_active:
                GUARD.stop()
                DELETE_WATCH.stop()
                STATE.protection_active = False
            else:
                if not load_protected_folders():
                    res = {"status": "error", "msg": "먼저 보호할 폴더를 하나 이상 추가하세요."}
                else:
                    ok = GUARD.start()
                    DELETE_WATCH.start()
                    STATE.protection_active = ok

        conn.sendall((json.dumps(res) + "\n").encode('utf-8'))
    except Exception:
        pass
    finally:
        conn.close()


def main():
    cleanup_archive_scan_root()

    if os.path.exists(SOCKET_PATH):
        try:
            os.remove(SOCKET_PATH)
        except Exception:
            pass

    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    server.bind(SOCKET_PATH)
    os.chmod(SOCKET_PATH, 0o777)
    server.listen(10)

    threading.Thread(target=auto_update_loop, daemon=True).start()
    threading.Thread(target=migrate_legacy_quarantine, daemon=True).start()
    threading.Thread(target=quarantine_cleanup_loop, daemon=True).start()
    USB_AUTO_SCANNER.start()
    threading.Thread(target=rkhunter_check_loop, daemon=True).start()
    threading.Thread(target=maldet_scan_loop, daemon=True).start()

    while True:
        try:
            conn, _ = server.accept()
            threading.Thread(target=handle_client, args=(conn,), daemon=True).start()
        except Exception:
            time.sleep(0.1)


if __name__ == "__main__":
    main()
PYEOF

chmod +x "${INSTALL_DIR}/snhpiguard_daemon.py"

echo "=== 5/9: 확인창(사용자 승인 다이얼로그) 생성 (snhpiguard_confirm_dialog.py) ==="
cat > "${INSTALL_DIR}/snhpiguard_confirm_dialog.py" << 'PYEOF'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SnhPiGuard 보호된 폴더 확인창
데몬(root)이 sudo -u <실제 사용자>로 이 스크립트를 띄운다.
표준출력으로 정확히 한 줄: ALLOW / ALLOW_REMEMBER / DENY 중 하나만 출력하고 종료한다.
결과가 애매하거나 창이 응답 없이 시간 초과되면 항상 DENY로 안전하게 처리한다.
"""
import sys
import tkinter as tk

TIMEOUT_MS = 30000  # 30초 무응답 시 자동 거부


def main():
    if len(sys.argv) < 4:
        print("DENY")
        return

    action = sys.argv[1]           # "write" 또는 "delete"
    filepath = sys.argv[2]
    proc_path = sys.argv[3]

    result = {"choice": "DENY"}

    root = tk.Tk()
    root.title("SnhPiGuard - 보호된 폴더")
    root.attributes("-topmost", True)
    root.resizable(False, False)

    if action == "write":
        title_text = "파일 수정/생성 요청"
        body_text = (
            "보호된 폴더의 파일을 아래 프로그램이 수정하거나 새로 만들려고 합니다.\n"
            "허용하시겠습니까?\n\n"
            f"파일 이름: {filepath}\n"
            f"요청 프로그램: {proc_path}"
        )
        allow_label = "확인 (수정 허용)"
        deny_label = "취소 (차단)"
    else:
        title_text = "파일 삭제 감지"
        body_text = (
            "보호된 폴더에서 파일 삭제가 감지되었습니다.\n"
            "삭제를 취소하고 직전 상태로 복구하시겠습니까?\n\n"
            f"파일 이름: {filepath}"
        )
        allow_label = "취소 (삭제를 되돌리고 복구)"
        deny_label = "확인 (삭제 유지)"

    # 주의: pady=(위, 아래) 튜플은 pack()/grid() 에서만 쓸 수 있고 Label() 생성자에는 쓸 수 없다.
    tk.Label(root, text=title_text, font=("Sans", 11, "bold"), padx=16).pack(pady=(14, 4))
    tk.Label(root, text=body_text, font=("Sans", 9), padx=16, pady=6, justify="left", wraplength=420).pack()

    remember_var = tk.IntVar(value=0)
    if action == "write":
        tk.Checkbutton(root, text="이 프로그램은 앞으로 항상 허용", variable=remember_var).pack(pady=(0, 6))

    btn_frame = tk.Frame(root, padx=16, pady=12)
    btn_frame.pack()

    if action == "write":
        # 쓰기/생성 화면: [확인]=허용(ALLOW/ALLOW_REMEMBER), [취소]=차단(DENY)
        def do_allow():
            result["choice"] = "ALLOW_REMEMBER" if remember_var.get() == 1 else "ALLOW"
            root.destroy()

        def do_deny():
            result["choice"] = "DENY"
            root.destroy()

        tk.Button(btn_frame, text=allow_label, width=22, command=do_allow, bg="#2e7d32", fg="white").pack(side=tk.LEFT, padx=6)
        tk.Button(btn_frame, text=deny_label, width=16, command=do_deny, bg="#c62828", fg="white").pack(side=tk.LEFT, padx=6)
    else:
        # 삭제 화면: "복구" 버튼을 누르면 실제로는 DENY(=차단/복구)를 의미하도록 매핑
        def do_restore():
            result["choice"] = "DENY"
            root.destroy()

        def do_keep_deleted():
            result["choice"] = "ALLOW"
            root.destroy()

        tk.Button(btn_frame, text=allow_label, width=26, command=do_restore, bg="#1565c0", fg="white").pack(side=tk.LEFT, padx=6)
        tk.Button(btn_frame, text=deny_label, width=18, command=do_keep_deleted, bg="#616161", fg="white").pack(side=tk.LEFT, padx=6)

    root.after(TIMEOUT_MS, root.destroy)  # 시간 초과 시 창을 닫고 기본값(DENY) 사용
    root.update_idletasks()
    w = root.winfo_reqwidth()
    h = root.winfo_reqheight()
    sw = root.winfo_screenwidth()
    sh = root.winfo_screenheight()
    root.geometry(f"+{(sw - w) // 2}+{(sh - h) // 2}")
    root.mainloop()

    print(result["choice"])


if __name__ == "__main__":
    main()
PYEOF

chmod +x "${INSTALL_DIR}/snhpiguard_confirm_dialog.py"

echo "  압축 비밀번호 입력창도 함께 만듭니다 (snhpiguard_password_dialog.py)"
cat > "${INSTALL_DIR}/snhpiguard_password_dialog.py" << 'PYEOF'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SnhPiGuard 압축 비밀번호 입력창
데몬(root)이 sudo -u <실제 사용자>로 이 스크립트를 띄운다.
표준출력으로 비밀번호 한 줄만 출력하고 종료한다. 취소하거나 시간 초과되면 "CANCELLED" 를 출력한다.
"""
import os
import sys
import tkinter as tk

TIMEOUT_MS = 120000  # 2분 무응답 시 자동 취소


def main():
    filepath = sys.argv[1] if len(sys.argv) > 1 else "(알 수 없는 파일)"
    name = os.path.basename(filepath)

    result = {"password": None}

    root = tk.Tk()
    root.title("SnhPiGuard - 압축 비밀번호")
    root.attributes("-topmost", True)
    root.resizable(False, False)

    tk.Label(root, text="압축 비밀번호 필요", font=("Sans", 11, "bold"), padx=16).pack(pady=(14, 4))
    tk.Label(
        root,
        text=f"검사하려는 압축 파일에 비밀번호가 걸려 있습니다.\n\n파일 이름: {name}\n\n"
             f"비밀번호를 모르면 [건너뛰기]를 누르세요 - 이 압축의 내부는 검사하지 않을 뿐,\n"
             f"압축 파일 자체는 그대로 남아 있고 다른 파일 검사는 계속됩니다.",
        font=("Sans", 9), padx=16, pady=6, justify="left", wraplength=420,
    ).pack()

    pw_var = tk.StringVar()
    entry = tk.Entry(root, textvariable=pw_var, show="*", font=("Sans", 10), width=30)
    entry.pack(pady=(4, 10))
    entry.focus_set()

    btn_frame = tk.Frame(root, padx=16, pady=12)
    btn_frame.pack()

    def do_ok():
        result["password"] = pw_var.get()
        root.destroy()

    def do_cancel():
        result["password"] = None
        root.destroy()

    entry.bind("<Return>", lambda e: do_ok())
    tk.Button(btn_frame, text="확인", width=14, command=do_ok, bg="#2e7d32", fg="white").pack(side=tk.LEFT, padx=6)
    tk.Button(btn_frame, text="건너뛰기(취소)", width=16, command=do_cancel, bg="#616161", fg="white").pack(side=tk.LEFT, padx=6)

    root.after(TIMEOUT_MS, root.destroy)
    root.update_idletasks()
    w = root.winfo_reqwidth()
    h = root.winfo_reqheight()
    sw = root.winfo_screenwidth()
    sh = root.winfo_screenheight()
    root.geometry(f"+{(sw - w) // 2}+{(sh - h) // 2}")
    root.mainloop()

    if result["password"]:
        print(result["password"])
    else:
        print("CANCELLED")


if __name__ == "__main__":
    main()
PYEOF

chmod +x "${INSTALL_DIR}/snhpiguard_password_dialog.py"


echo "=== 6/9: GUI 프로그램 생성 (snhpiguard_gui.py) ==="
cat > "${INSTALL_DIR}/snhpiguard_gui.py" << 'PYEOF'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SnhPiGuard GUI - Windows 95 스타일 Multi-Engine GUI
"""
import os
import sys
import json
import socket
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext

SOCKET_PATH = "/tmp/snhpiguard.sock"

BG = "#c0c0c0"
WHITE = "#ffffff"
BLACK = "#000000"
try:
    FONT = ("MS Sans Serif", 9)
    FONT_B = ("MS Sans Serif", 9, "bold")
except Exception:
    FONT = ("Tahoma", 9)
    FONT_B = ("Tahoma", 9, "bold")
MONO = ("Courier New", 9)


def send_daemon_cmd(cmd_dict, timeout=3):
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect(SOCKET_PATH)
        s.sendall((json.dumps(cmd_dict) + "\n").encode('utf-8'))
        raw = ""
        while True:
            chunk = s.recv(4096).decode('utf-8')
            if not chunk:
                break
            raw += chunk
        s.close()
        return json.loads(raw)
    except Exception:
        return None


def bevel_frame(parent, sunken=False, **kw):
    relief = tk.SUNKEN if sunken else tk.RIDGE
    return tk.Frame(parent, bg=BG, bd=2, relief=relief, **kw)


def win_button(parent, text, command, width=13):
    return tk.Button(
        parent, text=text, command=command, width=width,
        font=FONT, bg=BG, activebackground=BG,
        relief=tk.RAISED, bd=3, highlightbackground=BG,
    )


class SnhPiGuardApp:
    QUICK_SCAN_DIRS = [
        os.path.expanduser("~/Downloads"),
        os.path.expanduser("~/Desktop"),
        "/tmp",
    ]

    def __init__(self, root):
        self.root = root
        self.root.title("SnhPiGuard - Multi-Engine (YARA+ClamAV+rkhunter+Maldet)")
        self.root.geometry("720x560")
        self.root.configure(bg=BG)

        self.last_log_count = 0
        self.treat_win = None
        self.protect_win = None

        self._build_menu()
        self._build_toolbar()
        self._build_scan_buttons()
        self._build_manage_buttons()
        self._build_body()
        self._build_statusbar()

        self.poll_daemon()

    def _build_menu(self):
        menubar = tk.Menu(self.root)
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="정의 및 YARA 룰 업데이트", command=self.update_db)
        file_menu.add_separator()
        file_menu.add_command(label="종료", command=self.root.quit)
        menubar.add_cascade(label="파일", menu=file_menu)

        view_menu = tk.Menu(menubar, tearoff=0)
        view_menu.add_command(label="치료 및 격리소 / 예외 목록", command=self.open_treat_window)
        view_menu.add_command(label="보호된 폴더 액세스", command=self.open_protect_window)
        menubar.add_cascade(label="보기", menu=view_menu)

        help_menu = tk.Menu(menubar, tearoff=0)
        help_menu.add_command(label="정보", command=lambda: messagebox.showinfo(
            "정보", "SnhPiGuard - Multi-Engine\n"
                   "- YARA (실시간)\n- ClamAV (실시간)\n"
                   "- rkhunter (하루 1회, 루트킷/시스템 변조)\n"
                   "- Maldet (하루 1회, 웹쉘/서버형 악성코드)\n"
                   "- 보호된 폴더 액세스 (fanotify)"))
        menubar.add_cascade(label="도움말", menu=help_menu)
        self.root.config(menu=menubar)

    def _build_toolbar(self):
        bar = bevel_frame(self.root)
        bar.pack(fill=tk.X, padx=4, pady=4)

        self.path_var = tk.StringVar(value=os.path.expanduser("~"))
        entry = tk.Entry(bar, textvariable=self.path_var, font=FONT, relief=tk.SUNKEN, bd=2)
        entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4, pady=4)

        win_button(bar, "폴더...", self.browse_folder, width=8).pack(side=tk.LEFT, padx=2, pady=4)
        win_button(bar, "파일...", self.browse_file, width=8).pack(side=tk.LEFT, padx=2, pady=4)
        win_button(bar, "DB 업데이트", self.update_db, width=12).pack(side=tk.LEFT, padx=2, pady=4)

    def _build_scan_buttons(self):
        bar = bevel_frame(self.root)
        bar.pack(fill=tk.X, padx=4, pady=(0, 4))
        self.btn_quick = win_button(bar, "빠른 검사", self.start_quick_scan, width=12)
        self.btn_quick.pack(side=tk.LEFT, padx=4, pady=4)
        self.btn_custom = win_button(bar, "지정 검사", self.start_custom_scan, width=12)
        self.btn_custom.pack(side=tk.LEFT, padx=2, pady=4)
        self.btn_full = win_button(bar, "전체 검사", self.start_full_home_scan, width=12)
        self.btn_full.pack(side=tk.LEFT, padx=2, pady=4)
        self.smart_btn = win_button(bar, "스마트 감시", self.toggle_smart_scan, width=13)
        self.smart_btn.pack(side=tk.LEFT, padx=2, pady=4)
        self.stop_btn = win_button(bar, "검사 중지", self.stop_scan, width=10)
        self.stop_btn.pack(side=tk.LEFT, padx=2, pady=4)
        self.stop_btn.config(state=tk.DISABLED)

    def _build_manage_buttons(self):
        bar = bevel_frame(self.root)
        bar.pack(fill=tk.X, padx=4, pady=(0, 4))
        self.treat_btn = win_button(bar, "치료/격리소", self.open_treat_window, width=11)
        self.treat_btn.pack(side=tk.LEFT, padx=4, pady=4)
        self.protect_btn = win_button(bar, "보호된 폴더", self.open_protect_window, width=11)
        self.protect_btn.pack(side=tk.LEFT, padx=2, pady=4)
        self.rkhunter_btn = win_button(bar, "시스템 점검", self.open_rkhunter_window, width=11)
        self.rkhunter_btn.pack(side=tk.LEFT, padx=2, pady=4)

    def _build_body(self):
        outer = bevel_frame(self.root, sunken=True)
        outer.pack(fill=tk.BOTH, expand=True, padx=4, pady=(0, 4))
        tk.Label(outer, text="검사 및 엔진 로그 (Main: YARA / Sec: ClamAV)", bg=BG, font=FONT_B, anchor="w").pack(fill=tk.X, padx=4)
        self.log_box = scrolledtext.ScrolledText(
            outer, font=MONO, bg=WHITE, fg=BLACK, relief=tk.SUNKEN, bd=2, height=20)
        self.log_box.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)
        self.log_box.configure(state=tk.DISABLED)

        self.progress = ttk.Progressbar(outer, mode="indeterminate")
        self.progress.pack(fill=tk.X, padx=4, pady=(0, 4))
        self.is_pbar_running = False

    def _build_statusbar(self):
        self.status_var = tk.StringVar(value="백그라운드 서비스 연결 중...")
        bar = tk.Label(self.root, textvariable=self.status_var, bg=BG, font=FONT,
                        relief=tk.SUNKEN, bd=2, anchor="w")
        bar.pack(fill=tk.X, side=tk.BOTTOM, padx=4, pady=(0, 4))

    def browse_folder(self):
        d = filedialog.askdirectory(initialdir=self.path_var.get())
        if d:
            self.path_var.set(d)

    def browse_file(self):
        f = filedialog.askopenfilename(initialdir=self.path_var.get())
        if f:
            self.path_var.set(f)

    def poll_daemon(self):
        res = send_daemon_cmd({"cmd": "get_state"})
        if res and res.get("status") == "ok":
            st = res.get("state", {})
            self.status_var.set(st.get("status", "대기 중"))

            logs = st.get("logs", [])
            if len(logs) != self.last_log_count:
                self.log_box.configure(state=tk.NORMAL)
                self.log_box.delete("1.0", tk.END)
                for line in logs:
                    self.log_box.insert(tk.END, line + "\n")
                self.log_box.see(tk.END)
                self.log_box.configure(state=tk.DISABLED)
                self.last_log_count = len(logs)

            is_scanning = st.get("is_scanning", False)
            if is_scanning:
                if not self.is_pbar_running:
                    self.progress.start(15)
                    self.is_pbar_running = True
                stopping = st.get("stopping", False)
                self.stop_btn.config(
                    state=tk.DISABLED if stopping else tk.NORMAL,
                    text="중지 처리 중..." if stopping else "검사 중지",
                )
                self.btn_quick.config(state=tk.DISABLED)
                self.btn_custom.config(state=tk.DISABLED)
                self.btn_full.config(state=tk.DISABLED)
            else:
                if self.is_pbar_running:
                    self.progress.stop()
                    self.is_pbar_running = False
                self.stop_btn.config(state=tk.DISABLED, text="검사 중지")
                self.btn_quick.config(state=tk.NORMAL)
                self.btn_custom.config(state=tk.NORMAL)
                self.btn_full.config(state=tk.NORMAL)

            if st.get("smart_active", False):
                self.smart_btn.config(text="감시 중지")
            else:
                self.smart_btn.config(text="스마트 감시")

            if st.get("protection_active", False):
                self.protect_btn.config(text="보호 ON", bg="#c8e6c9")
            else:
                self.protect_btn.config(text="보호된 폴더", bg=BG)

            rk = st.get("rkhunter", {})
            if rk.get("running"):
                self.rkhunter_btn.config(text="점검 중...", bg="#fff9c4")
            elif rk.get("last", {}) and rk["last"].get("warning_count", 0) > 0:
                self.rkhunter_btn.config(text=f"점검({rk['last']['warning_count']})", bg="#ffcdd2")
            else:
                self.rkhunter_btn.config(text="시스템 점검", bg=BG)
        else:
            self.status_var.set("백그라운드 서비스 연결 불가")

        self.root.after(500, self.poll_daemon)

    def start_quick_scan(self):
        res = send_daemon_cmd({"cmd": "start_scan", "targets": self.QUICK_SCAN_DIRS, "label": "빠른 검사"})
        if res and res.get("status") == "error":
            messagebox.showinfo("알림", res.get("msg"))

    def start_custom_scan(self):
        target = self.path_var.get().strip()
        if not target:
            messagebox.showerror("오류", "검사할 대상을 선택하세요.")
            return
        res = send_daemon_cmd({"cmd": "start_scan", "targets": [target], "label": "지정 검사"})
        if res and res.get("status") == "error":
            messagebox.showinfo("알림", res.get("msg"))

    def start_full_home_scan(self):
        res = send_daemon_cmd({"cmd": "start_scan", "targets": [os.path.expanduser("~")], "label": "전체 검사"})
        if res and res.get("status") == "error":
            messagebox.showinfo("알림", res.get("msg"))

    def stop_scan(self):
        send_daemon_cmd({"cmd": "stop_scan"})

    def update_db(self):
        res = send_daemon_cmd({"cmd": "update_db"})
        if res and res.get("status") == "error":
            messagebox.showinfo("알림", res.get("msg"))

    def toggle_smart_scan(self):
        target = self.path_var.get().strip()
        send_daemon_cmd({"cmd": "toggle_smart", "target": target})

    # ---------- 치료/격리소 및 예외 관리 창 ----------
    def open_treat_window(self):
        res = send_daemon_cmd({"cmd": "get_state"})
        if not res or res.get("status") != "ok":
            messagebox.showerror("오류", "백그라운드 서비스 통신 실패")
            return

        st = res.get("state", {})
        q_list = st.get("quarantine_list", [])
        w_list = st.get("whitelist", [])

        if self.treat_win is not None and tk.Toplevel.winfo_exists(self.treat_win):
            self.treat_win.lift()
            return

        win = tk.Toplevel(self.root)
        self.treat_win = win
        win.title("치료 / 격리소 및 예외 관리")
        win.configure(bg=BG)
        win.geometry("650x420")

        notebook = ttk.Notebook(win)
        notebook.pack(fill=tk.BOTH, expand=True, padx=6, pady=6)

        tab_q = tk.Frame(notebook, bg=BG)
        notebook.add(tab_q, text=" 격리소 ")

        tk.Label(tab_q, text="격리된 파일 목록 (복구 시 예외 등록되어 재격리 방지)",
                 bg=BG, font=FONT).pack(anchor="w", padx=4, pady=4)

        tree_frame = tk.Frame(tab_q, bg=BG, bd=2, relief=tk.SUNKEN)
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=4, pady=2)

        tree = ttk.Treeview(tree_frame, columns=("sig", "path", "time"), show="headings", selectmode="extended")
        tree.heading("sig", text="탐지 엔진 / 규칙")
        tree.heading("path", text="원래 파일 경로")
        tree.heading("time", text="격리 일시")

        tree.column("sig", width=160)
        tree.column("path", width=310)
        tree.column("time", width=130)

        tree.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        tree.configure(yscrollcommand=vsb.set)

        for item in q_list:
            tree.insert("", tk.END, iid=item["id"], values=(item["sig"], item["original_path"], item["time"]))

        def do_restore():
            selected = tree.selection()
            if not selected:
                messagebox.showinfo("알림", "복구할 항목을 선택하세요.")
                return
            res = send_daemon_cmd({"cmd": "restore_quarantine", "q_ids": list(selected)}, timeout=600)
            if res and res.get("status") == "ok":
                messagebox.showinfo("성공", f"{res.get('count', 0)}개 파일 복구 및 예외 등록 완료.")
                win.destroy()

        def do_delete():
            selected = tree.selection()
            if not selected:
                messagebox.showinfo("알림", "삭제할 항목을 선택하세요.")
                return
            if not messagebox.askyesno("경고", f"선택한 {len(selected)}개 파일을 영구 삭제할까요?"):
                return
            res = send_daemon_cmd({"cmd": "delete_quarantine", "q_ids": list(selected)}, timeout=600)
            if res and res.get("status") == "ok":
                messagebox.showinfo("완료", f"{res.get('count', 0)}개 파일 영구 삭제 완료.")
                win.destroy()

        def do_select_all_q():
            tree.selection_set(tree.get_children())

        def do_deselect_all_q():
            tree.selection_remove(tree.get_children())

        q_btns = tk.Frame(tab_q, bg=BG)
        q_btns.pack(fill=tk.X, padx=4, pady=6)
        win_button(q_btns, "모두 선택", do_select_all_q, width=10).pack(side=tk.LEFT, padx=4)
        win_button(q_btns, "선택 해제", do_deselect_all_q, width=10).pack(side=tk.LEFT, padx=4)
        win_button(q_btns, "원래 위치로 복구", do_restore, width=16).pack(side=tk.LEFT, padx=4)
        win_button(q_btns, "영구 삭제", do_delete, width=12).pack(side=tk.LEFT, padx=4)

        tab_w = tk.Frame(notebook, bg=BG)
        notebook.add(tab_w, text=" 복구된 예외 목록 ")

        tk.Label(tab_w, text="사용자가 복구하여 감시 대상에서 제외된 파일",
                 bg=BG, font=FONT).pack(anchor="w", padx=4, pady=4)

        w_frame = tk.Frame(tab_w, bg=BG, bd=2, relief=tk.SUNKEN)
        w_frame.pack(fill=tk.BOTH, expand=True, padx=4, pady=2)

        w_tree = ttk.Treeview(w_frame, columns=("path",), show="headings", selectmode="extended")
        w_tree.heading("path", text="예외 등록된 파일 경로")
        w_tree.column("path", width=600)

        w_tree.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        w_vsb = ttk.Scrollbar(w_frame, orient="vertical", command=w_tree.yview)
        w_vsb.pack(side=tk.RIGHT, fill=tk.Y)
        w_tree.configure(yscrollcommand=w_vsb.set)

        for p in w_list:
            w_tree.insert("", tk.END, values=(p,))

        def do_remove_whitelist():
            selected = w_tree.selection()
            if not selected:
                messagebox.showinfo("알림", "제외 해제할 항목을 선택하세요.")
                return
            paths = [w_tree.item(item)["values"][0] for item in selected]
            res = send_daemon_cmd({"cmd": "remove_whitelist", "paths": paths})
            if res and res.get("status") == "ok":
                messagebox.showinfo("완료", f"{res.get('count', 0)}개 항목 예외 해제 완료.")
                win.destroy()

        def do_select_all_w():
            w_tree.selection_set(w_tree.get_children())

        def do_deselect_all_w():
            w_tree.selection_remove(w_tree.get_children())

        w_btns = tk.Frame(tab_w, bg=BG)
        w_btns.pack(fill=tk.X, padx=4, pady=6)
        win_button(w_btns, "모두 선택", do_select_all_w, width=10).pack(side=tk.LEFT, padx=4)
        win_button(w_btns, "선택 해제", do_deselect_all_w, width=10).pack(side=tk.LEFT, padx=4)
        win_button(w_btns, "선택 항목 예외 해제", do_remove_whitelist, width=20).pack(side=tk.LEFT, padx=4)

    # ---------- 보호된 폴더 액세스 관리 창 ----------
    def open_protect_window(self):
        res = send_daemon_cmd({"cmd": "get_state"})
        if not res or res.get("status") != "ok":
            messagebox.showerror("오류", "백그라운드 서비스 통신 실패")
            return
        st = res.get("state", {})

        if self.protect_win is not None and tk.Toplevel.winfo_exists(self.protect_win):
            self.protect_win.lift()
            return

        win = tk.Toplevel(self.root)
        self.protect_win = win
        win.title("보호된 폴더 액세스")
        win.configure(bg=BG)
        win.geometry("680x480")

        if not st.get("fanotify_available", False):
            tk.Label(win, bg=BG, fg="#b71c1c", font=FONT_B, wraplength=640, justify="left",
                     text=("이 시스템에서는 fanotify를 사용할 수 없어 실시간 쓰기 차단을 켤 수 없습니다.\n"
                           "(커널 CONFIG_FANOTIFY_ACCESS_PERMISSIONS 미지원이거나 root 권한 필요)")
                     ).pack(fill=tk.X, padx=8, pady=8)

        status_frame = bevel_frame(win)
        status_frame.pack(fill=tk.X, padx=6, pady=6)
        status_text = "보호 활성화됨 (쓰기/생성 실시간 차단 중)" if st.get("protection_active") else "보호 비활성화됨"
        tk.Label(status_frame, text=f"상태: {status_text}", bg=BG, font=FONT_B).pack(side=tk.LEFT, padx=6, pady=6)

        def do_toggle():
            r = send_daemon_cmd({"cmd": "toggle_protection"})
            if r and r.get("status") == "error":
                messagebox.showinfo("알림", r.get("msg"))
            win.destroy()
            self.open_protect_window()

        win_button(status_frame, "보호 켜기/끄기", do_toggle, width=16).pack(side=tk.RIGHT, padx=6, pady=6)

        notebook = ttk.Notebook(win)
        notebook.pack(fill=tk.BOTH, expand=True, padx=6, pady=6)

        # 탭 1: 보호된 폴더 목록
        tab_f = tk.Frame(notebook, bg=BG)
        notebook.add(tab_f, text=" 보호된 폴더 ")

        tk.Label(tab_f, text="아래 폴더의 파일을 수정/생성하려는 모든 프로그램은 확인창을 거칩니다.\n"
                              "삭제는 사전 차단이 불가능하여, 삭제가 감지되면 즉시 복구 확인창이 뜹니다.",
                 bg=BG, font=FONT, justify="left").pack(anchor="w", padx=4, pady=4)

        f_frame = tk.Frame(tab_f, bg=BG, bd=2, relief=tk.SUNKEN)
        f_frame.pack(fill=tk.BOTH, expand=True, padx=4, pady=2)
        f_list = tk.Listbox(f_frame, font=MONO)
        f_list.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        f_vsb = ttk.Scrollbar(f_frame, orient="vertical", command=f_list.yview)
        f_vsb.pack(side=tk.RIGHT, fill=tk.Y)
        f_list.configure(yscrollcommand=f_vsb.set)
        for folder in st.get("protected_folders", []):
            f_list.insert(tk.END, folder)

        def do_add_folder():
            d = filedialog.askdirectory()
            if not d:
                return
            r = send_daemon_cmd({"cmd": "add_protected_folder", "path": d})
            if r and r.get("status") == "error":
                messagebox.showinfo("알림", r.get("msg"))
            win.destroy()
            self.open_protect_window()

        def do_remove_folder():
            sel = f_list.curselection()
            if not sel:
                messagebox.showinfo("알림", "제거할 폴더를 선택하세요.")
                return
            path = f_list.get(sel[0])
            send_daemon_cmd({"cmd": "remove_protected_folder", "path": path})
            win.destroy()
            self.open_protect_window()

        f_btns = tk.Frame(tab_f, bg=BG)
        f_btns.pack(fill=tk.X, padx=4, pady=6)
        win_button(f_btns, "폴더 추가...", do_add_folder, width=14).pack(side=tk.LEFT, padx=4)
        win_button(f_btns, "선택 폴더 제거", do_remove_folder, width=14).pack(side=tk.LEFT, padx=4)

        # 탭 2: 신뢰할 수 있는 앱
        tab_a = tk.Frame(notebook, bg=BG)
        notebook.add(tab_a, text=" 신뢰할 수 있는 앱 ")

        tk.Label(tab_a, text="여기 등록된 실행 파일은 확인창 없이 항상 쓰기가 허용됩니다.",
                 bg=BG, font=FONT).pack(anchor="w", padx=4, pady=4)

        a_frame = tk.Frame(tab_a, bg=BG, bd=2, relief=tk.SUNKEN)
        a_frame.pack(fill=tk.BOTH, expand=True, padx=4, pady=2)
        a_list = tk.Listbox(a_frame, font=MONO)
        a_list.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        a_vsb = ttk.Scrollbar(a_frame, orient="vertical", command=a_list.yview)
        a_vsb.pack(side=tk.RIGHT, fill=tk.Y)
        a_list.configure(yscrollcommand=a_vsb.set)
        for app in st.get("trusted_apps", []):
            a_list.insert(tk.END, app)

        def do_add_app():
            f = filedialog.askopenfilename(title="신뢰할 실행 파일 선택")
            if not f:
                return
            r = send_daemon_cmd({"cmd": "add_trusted_app", "path": f})
            if r and r.get("status") == "error":
                messagebox.showinfo("알림", r.get("msg"))
            win.destroy()
            self.open_protect_window()

        def do_remove_app():
            sel = a_list.curselection()
            if not sel:
                messagebox.showinfo("알림", "제거할 앱을 선택하세요.")
                return
            path = a_list.get(sel[0])
            send_daemon_cmd({"cmd": "remove_trusted_app", "path": path})
            win.destroy()
            self.open_protect_window()

        a_btns = tk.Frame(tab_a, bg=BG)
        a_btns.pack(fill=tk.X, padx=4, pady=6)
        win_button(a_btns, "앱 추가...", do_add_app, width=14).pack(side=tk.LEFT, padx=4)
        win_button(a_btns, "선택 앱 제거", do_remove_app, width=14).pack(side=tk.LEFT, padx=4)

        # 탭 3: 최근 이벤트
        tab_e = tk.Frame(notebook, bg=BG)
        notebook.add(tab_e, text=" 최근 이벤트 ")

        e_frame = tk.Frame(tab_e, bg=BG, bd=2, relief=tk.SUNKEN)
        e_frame.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)
        e_tree = ttk.Treeview(e_frame, columns=("time", "action", "decision", "path", "process"),
                               show="headings", selectmode="browse")
        for col, txt, w in (("time", "시간", 130), ("action", "구분", 60),
                             ("decision", "결과", 90), ("path", "파일", 260), ("process", "프로그램", 130)):
            e_tree.heading(col, text=txt)
            e_tree.column(col, width=w)
        e_tree.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        e_vsb = ttk.Scrollbar(e_frame, orient="vertical", command=e_tree.yview)
        e_vsb.pack(side=tk.RIGHT, fill=tk.Y)
        e_tree.configure(yscrollcommand=e_vsb.set)
        for ev in reversed(st.get("protection_events", [])):
            e_tree.insert("", tk.END, values=(ev.get("time"), ev.get("action"), ev.get("decision"),
                                               ev.get("path"), ev.get("process")))

    # ---------- 시스템 점검(rkhunter) 창 ----------
    def open_rkhunter_window(self):
        res = send_daemon_cmd({"cmd": "get_state"})
        if not res or res.get("status") != "ok":
            messagebox.showerror("오류", "백그라운드 서비스 통신 실패")
            return
        state = res.get("state", {})
        rk = state.get("rkhunter", {})
        md = state.get("maldet", {})

        win = tk.Toplevel(self.root)
        win.title("시스템 점검")
        win.configure(bg=BG)
        win.geometry("580x460")

        notebook = ttk.Notebook(win)
        notebook.pack(fill=tk.BOTH, expand=True, padx=6, pady=6)

        # ---- 탭 1: rkhunter (루트킷/시스템 변조) ----
        tab_rk = tk.Frame(notebook, bg=BG)
        notebook.add(tab_rk, text=" 루트킷 점검 (rkhunter) ")

        if not rk.get("available"):
            tk.Label(tab_rk, bg=BG, fg="#b71c1c", font=FONT_B, wraplength=520, justify="left",
                     text="rkhunter 가 설치되어 있지 않습니다. 설치 스크립트를 다시 실행하면\n"
                          "자동으로 설치를 시도합니다 (실패해도 백신 본 기능에는 영향이 없습니다).",
                     ).pack(fill=tk.X, padx=8, pady=8)

        tk.Label(tab_rk, bg=BG, font=FONT, justify="left", wraplength=520,
                 text=("YARA/ClamAV 는 파일 하나하나를 실시간으로 검사하고,\n"
                       "rkhunter 는 하루 한 번 시스템 자체가 이미 변조됐는지(루트킷, 숨겨진 프로세스 등)\n"
                       "정밀 점검합니다. 배포판 특성상 정상 시스템에서도 경고가 몇 개 뜰 수 있습니다.")
                 ).pack(fill=tk.X, padx=8, pady=(4, 8))

        rk_status_frame = bevel_frame(tab_rk)
        rk_status_frame.pack(fill=tk.X, padx=8, pady=(0, 8))
        rk_last = rk.get("last")
        if rk.get("running"):
            rk_status_text = "점검 진행 중... (몇 분 걸릴 수 있습니다)"
        elif rk_last:
            wc = rk_last.get("warning_count", 0)
            rk_status_text = f"마지막 점검: {rk_last.get('time', '?')}  -  경고 {wc}개"
        else:
            rk_status_text = "아직 점검한 적이 없습니다."
        tk.Label(rk_status_frame, text=rk_status_text, bg=BG, font=FONT_B, wraplength=520,
                 justify="left").pack(anchor="w", padx=6, pady=6)

        rk_list_frame = tk.Frame(tab_rk, bg=BG, bd=2, relief=tk.SUNKEN)
        rk_list_frame.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))
        rk_listbox = tk.Listbox(rk_list_frame, font=MONO)
        rk_listbox.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        rk_vsb = ttk.Scrollbar(rk_list_frame, orient="vertical", command=rk_listbox.yview)
        rk_vsb.pack(side=tk.RIGHT, fill=tk.Y)
        rk_listbox.configure(yscrollcommand=rk_vsb.set)
        if rk_last and rk_last.get("warnings"):
            for w in rk_last["warnings"]:
                rk_listbox.insert(tk.END, w)
        else:
            rk_listbox.insert(tk.END, "(경고 없음)")

        def do_rk_check_now():
            r = send_daemon_cmd({"cmd": "run_rkhunter_check"})
            if r and r.get("status") == "error":
                messagebox.showinfo("알림", r.get("msg"))
            else:
                messagebox.showinfo("알림", "점검을 시작했습니다. 몇 분 뒤 이 창을 다시 열어 결과를 확인하세요.")
            win.destroy()

        win_button(tab_rk, "지금 점검", do_rk_check_now, width=14).pack(pady=(0, 8))

        # ---- 탭 2: Maldet (웹쉘/서버형 악성코드) ----
        tab_md = tk.Frame(notebook, bg=BG)
        notebook.add(tab_md, text=" Maldet (웹쉘/악성코드) ")

        if not md.get("available"):
            tk.Label(tab_md, bg=BG, fg="#b71c1c", font=FONT_B, wraplength=520, justify="left",
                     text="maldet 이 설치되어 있지 않습니다. 설치 스크립트를 다시 실행하면\n"
                          "자동으로 설치를 시도합니다 (실패해도 백신 본 기능에는 영향이 없습니다).",
                     ).pack(fill=tk.X, padx=8, pady=8)

        tk.Label(tab_md, bg=BG, font=FONT, justify="left", wraplength=520,
                 text=("YARA/ClamAV 보다 웹쉘, PHP 악성코드 같은 서버형 위협에 특화된 자체 시그니처를 씁니다.\n"
                       "/home, /tmp, /var/www 를 하루 한 번 훑고, 걸린 파일은 자동으로 격리소로 옮깁니다.")
                 ).pack(fill=tk.X, padx=8, pady=(4, 8))

        md_status_frame = bevel_frame(tab_md)
        md_status_frame.pack(fill=tk.X, padx=8, pady=(0, 8))
        md_last = md.get("last")
        if md.get("running"):
            md_status_text = "점검 진행 중... (몇 분 걸릴 수 있습니다)"
        elif md_last:
            hc = md_last.get("parsed_hits", 0)
            qc = md_last.get("quarantined", 0)
            md_status_text = f"마지막 점검: {md_last.get('time', '?')}  -  탐지 {hc}개, 격리 {qc}개"
        else:
            md_status_text = "아직 점검한 적이 없습니다."
        tk.Label(md_status_frame, text=md_status_text, bg=BG, font=FONT_B, wraplength=520,
                 justify="left").pack(anchor="w", padx=6, pady=6)

        md_list_frame = tk.Frame(tab_md, bg=BG, bd=2, relief=tk.SUNKEN)
        md_list_frame.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))
        md_listbox = tk.Listbox(md_list_frame, font=MONO)
        md_listbox.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        md_vsb = ttk.Scrollbar(md_list_frame, orient="vertical", command=md_listbox.yview)
        md_vsb.pack(side=tk.RIGHT, fill=tk.Y)
        md_listbox.configure(yscrollcommand=md_vsb.set)
        if md_last and md_last.get("targets"):
            md_listbox.insert(tk.END, f"검사 대상: {', '.join(md_last['targets'])}")
        if md_last and md_last.get("parsed_hits", 0) == 0 and md_last.get("reported_total_hits"):
            md_listbox.insert(tk.END, "(maldet 이 탐지를 보고했지만 세부 경로를 읽어내지 못했습니다.)")
            md_listbox.insert(tk.END, "터미널에서 'sudo maldet --report list' 로 직접 확인하세요.")
        elif not md_last or md_last.get("parsed_hits", 0) == 0:
            md_listbox.insert(tk.END, "(탐지 없음)")

        def do_md_check_now():
            r = send_daemon_cmd({"cmd": "run_maldet_scan"})
            if r and r.get("status") == "error":
                messagebox.showinfo("알림", r.get("msg"))
            else:
                messagebox.showinfo("알림", "점검을 시작했습니다. 몇 분 뒤 이 창을 다시 열어 결과를 확인하세요.")
            win.destroy()

        win_button(tab_md, "지금 점검", do_md_check_now, width=14).pack(pady=(0, 8))


def main():
    root = tk.Tk()
    app = SnhPiGuardApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
PYEOF

chmod +x "${INSTALL_DIR}/snhpiguard_gui.py"

echo "=== 7/9: 백그라운드 트레이 알림 프로그램 생성 (snhpiguard_tray.py) ==="
cat > "${INSTALL_DIR}/snhpiguard_tray.py" << 'PYEOF'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SnhPiGuard Tray - 백그라운드 상주 트레이 프로그램

메인 GUI(snhpiguard_gui.py) 창이 꺼져 있어도 로그인 세션 동안 항상 실행되며,
데몬이 위협을 탐지/격리하거나 보호된 폴더에서 접근을 차단하면
트레이 아이콘이 경고 상태로 바뀌고 데스크톱 알림을 띄운다.

트레이 표시 방식(백엔드)은 appindicator -> gtk -> xorg 순서로 자동 선택한다.
  * Wayland 세션에서는 appindicator(StatusNotifier)만 아이콘이 보인다.
  * 아이콘을 띄울 수 없는 환경이어도 알림(notify-send)은 계속 동작한다.

문제가 생겼을 때
  * 로그   : ~/.cache/snhpiguard/tray.log
  * 진단   : python3 /opt/snhpiguard/snhpiguard_tray.py --diagnose
  * 백엔드 강제 지정 : SNHPIGUARD_TRAY_BACKEND=appindicator|gtk|xorg python3 ...
"""
import os
import sys
import json
import time
import fcntl
import shutil
import socket
import logging
import logging.handlers
import importlib
import subprocess
import threading

try:
    from PIL import Image, ImageDraw
    PIL_OK = True
except Exception:
    PIL_OK = False

try:
    from gi.repository import GLib
except Exception:
    GLib = None

SOCKET_PATH = os.environ.get("SNHPIGUARD_SOCKET", "/tmp/snhpiguard.sock")
INSTALL_DIR = "/opt/snhpiguard"
GUI_SCRIPT = os.path.join(INSTALL_DIR, "snhpiguard_gui.py")
QUICK_SCAN_DIRS = [
    os.path.expanduser("~/Downloads"),
    os.path.expanduser("~/Desktop"),
    "/tmp",
]

POLL_INTERVAL_SEC = 3
STARTUP_DELAY_SEC = 3   # 로그인 직후 패널(트레이 호스트)이 뜰 시간을 준다

LOG_DIR = os.path.join(
    os.environ.get("XDG_CACHE_HOME") or os.path.expanduser("~/.cache"), "snhpiguard")
LOG_FILE = os.path.join(LOG_DIR, "tray.log")

log = logging.getLogger("snhpiguard.tray")


# --------------------------------------------------------------------------
#  로깅: autostart로 실행되면 터미널이 없어 오류가 전부 사라지므로 파일에 남긴다
# --------------------------------------------------------------------------
def setup_logging():
    log.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%Y-%m-%d %H:%M:%S")

    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")
        except Exception:
            pass

    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        fh = logging.handlers.RotatingFileHandler(
            LOG_FILE, maxBytes=256 * 1024, backupCount=1, encoding="utf-8")
        fh.setFormatter(fmt)
        log.addHandler(fh)
    except Exception:
        pass

    if sys.stderr is not None and sys.stderr.isatty():
        sh = logging.StreamHandler(sys.stderr)
        sh.setFormatter(fmt)
        log.addHandler(sh)

    def _excepthook(exc_type, exc, tb):
        log.critical("처리되지 않은 예외", exc_info=(exc_type, exc, tb))

    sys.excepthook = _excepthook
    if hasattr(threading, "excepthook"):
        def _thread_hook(args):
            log.critical("스레드 예외 (%s)", getattr(args.thread, "name", "?"),
                         exc_info=(args.exc_type, args.exc_value, args.exc_traceback))
        threading.excepthook = _thread_hook


# --------------------------------------------------------------------------
#  세션 환경 보정: sudo -u / ssh / 일부 autostart 로 실행되면 이 값들이 비어 있다
# --------------------------------------------------------------------------
def ensure_session_env():
    uid = os.getuid()
    rt = os.environ.get("XDG_RUNTIME_DIR", "")
    if not rt or not os.path.isdir(rt):
        rt = "/run/user/%d" % uid
        if os.path.isdir(rt):
            os.environ["XDG_RUNTIME_DIR"] = rt
        else:
            rt = ""

    if rt:
        bus = os.path.join(rt, "bus")
        if not os.environ.get("DBUS_SESSION_BUS_ADDRESS") and os.path.exists(bus):
            os.environ["DBUS_SESSION_BUS_ADDRESS"] = "unix:path=" + bus
        if not os.environ.get("WAYLAND_DISPLAY"):
            try:
                socks = sorted(n for n in os.listdir(rt)
                               if n.startswith("wayland-") and not n.endswith(".lock"))
            except OSError:
                socks = []
            if socks:
                os.environ["WAYLAND_DISPLAY"] = socks[0]

    if not os.environ.get("DISPLAY") and os.path.exists("/tmp/.X11-unix/X0"):
        os.environ["DISPLAY"] = ":0"
    if os.environ.get("DISPLAY") and not os.environ.get("XAUTHORITY"):
        xauth = os.path.expanduser("~/.Xauthority")
        if os.path.exists(xauth):
            os.environ["XAUTHORITY"] = xauth

    if not os.environ.get("XDG_SESSION_TYPE") or os.environ.get("XDG_SESSION_TYPE") == "tty":
        os.environ["XDG_SESSION_TYPE"] = "wayland" if os.environ.get("WAYLAND_DISPLAY") else "x11"


def is_wayland():
    return (os.environ.get("XDG_SESSION_TYPE", "").lower() == "wayland"
            or bool(os.environ.get("WAYLAND_DISPLAY")))


# --------------------------------------------------------------------------
#  중복 실행 방지 (설치 직후 실행 + 자동 시작이 겹쳐도 아이콘/알림이 두 번 뜨지 않게)
# --------------------------------------------------------------------------
_LOCK_FH = None


def lock_path():
    base = os.environ.get("XDG_RUNTIME_DIR") or "/tmp"
    return os.path.join(base, "snhpiguard-tray-%d.lock" % os.getuid())


def acquire_lock():
    global _LOCK_FH
    try:
        fh = open(lock_path(), "a+")
    except OSError as e:
        log.warning("중복 실행 방지 잠금 파일을 만들 수 없어 잠금 없이 진행합니다: %s", e)
        return True
    try:
        fcntl.flock(fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        fh.close()
        return False
    fh.seek(0)
    fh.truncate()
    fh.write(str(os.getpid()))
    fh.flush()
    _LOCK_FH = fh
    return True


def tray_already_running():
    try:
        fh = open(lock_path(), "a+")
    except OSError:
        return None
    try:
        fcntl.flock(fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
        fcntl.flock(fh, fcntl.LOCK_UN)
        return False
    except OSError:
        return True
    finally:
        fh.close()


# --------------------------------------------------------------------------
#  데몬 통신 / 데스크톱 알림
# --------------------------------------------------------------------------
def send_daemon_cmd(cmd_dict):
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(3)
        s.connect(SOCKET_PATH)
        s.sendall((json.dumps(cmd_dict) + "\n").encode("utf-8"))
        raw = ""
        while True:
            chunk = s.recv(4096).decode("utf-8")
            if not chunk:
                break
            raw += chunk
        s.close()
        return json.loads(raw)
    except Exception:
        return None


_NOTIFY_WARNED = False


def notify(title, message, urgency="critical"):
    """notify-send 를 백그라운드로 실행하고, 실패하면 이유를 로그에 남긴다."""
    def _run():
        global _NOTIFY_WARNED
        try:
            r = subprocess.run(
                ["notify-send", "-u", urgency, "-a", "SnhPiGuard",
                 "-i", "security-high", title, message],
                capture_output=True, text=True, timeout=10)
            if r.returncode != 0 and not _NOTIFY_WARNED:
                _NOTIFY_WARNED = True
                log.warning("notify-send 실패(code=%s): %s", r.returncode, (r.stderr or "").strip())
        except FileNotFoundError:
            if not _NOTIFY_WARNED:
                _NOTIFY_WARNED = True
                log.warning("notify-send 가 없습니다 -> sudo apt install libnotify-bin")
        except Exception as e:
            if not _NOTIFY_WARNED:
                _NOTIFY_WARNED = True
                log.warning("알림 표시 실패: %s", e)

    threading.Thread(target=_run, daemon=True).start()


def sni_watcher_present():
    """세션 버스에 StatusNotifierWatcher(= AppIndicator 트레이 호스트)가 있는지. 확인 불가면 None."""
    try:
        r = subprocess.run(
            ["gdbus", "call", "--session", "--dest", "org.freedesktop.DBus",
             "--object-path", "/org/freedesktop/DBus",
             "--method", "org.freedesktop.DBus.NameHasOwner",
             "org.kde.StatusNotifierWatcher"],
            capture_output=True, text=True, timeout=5)
    except Exception:
        return None
    if r.returncode != 0:
        return None
    return "true" in r.stdout


# --------------------------------------------------------------------------
#  아이콘 이미지
# --------------------------------------------------------------------------
def make_icon_image(state="ok"):
    size = 64
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    color = {
        "ok": (30, 140, 60, 255),
        "alert": (220, 30, 30, 255),
        "offline": (128, 128, 128, 255),
    }.get(state, (30, 140, 60, 255))
    white = (255, 255, 255, 255)
    draw.polygon(
        [(32, 4), (58, 16), (58, 34), (32, 60), (6, 34), (6, 16)],
        fill=color, outline=(0, 0, 0, 255)
    )
    if state == "alert":
        draw.line([(24, 20), (40, 36)], fill=white, width=5)
        draw.line([(40, 20), (24, 36)], fill=white, width=5)
    elif state == "offline":
        draw.line([(22, 28), (42, 28)], fill=white, width=5)
    else:
        draw.line([(20, 30), (28, 40)], fill=white, width=5)
        draw.line([(28, 40), (44, 18)], fill=white, width=5)
    return img


# --------------------------------------------------------------------------
#  pystray 백엔드 선택
# --------------------------------------------------------------------------
def _purge_pystray():
    for name in [n for n in sys.modules if n == "pystray" or n.startswith("pystray.")]:
        del sys.modules[name]


def backend_order():
    forced = os.environ.get("SNHPIGUARD_TRAY_BACKEND", "").strip()
    if forced:
        return [forced]
    return ["appindicator", "gtk", "xorg"]


def load_pystray(order, quiet=False):
    """order 순서대로 백엔드를 시도한다. 실패 사유를 모두 돌려주고(로그에도 남긴다)."""
    failures = []
    for name in order:
        os.environ["PYSTRAY_BACKEND"] = name
        _purge_pystray()
        try:
            mod = importlib.import_module("pystray")
            if not quiet:
                log.info("트레이 백엔드 선택: %s", name)
            return mod, name, failures
        except Exception as e:   # ImportError / ValueError(gi typelib 없음) 등
            failures.append((name, "%s: %s" % (type(e).__name__, e)))
            if not quiet:
                log.warning("트레이 백엔드 '%s' 사용 불가 -> %s: %s", name, type(e).__name__, e)
    return None, None, failures


def ui_call(backend, fn, *args):
    """GTK 계열 백엔드는 GTK 메인 루프 스레드에서 UI를 갱신해야 안전하다."""
    if GLib is not None and backend in ("appindicator", "gtk"):
        def _cb():
            try:
                fn(*args)
            except Exception:
                log.exception("트레이 UI 갱신 오류")
            return False
        GLib.idle_add(_cb)
    else:
        try:
            fn(*args)
        except Exception:
            log.exception("트레이 UI 갱신 오류")


# --------------------------------------------------------------------------
#  데몬 상태 감시 (UI와 분리: 트레이 아이콘이 없어도 알림은 보낼 수 있다)
# --------------------------------------------------------------------------
class Watcher:
    def __init__(self):
        self.known_q = set()
        self.known_ev = set()
        self.baseline_done = False
        self.online = None
        self.alert = False
        self.alert_title = ""

    def clear_alert(self):
        self.alert = False
        self.alert_title = ""

    def poll_once(self):
        """반환: (아이콘 상태 'ok'|'alert'|'offline', 툴팁 문자열, [(알림 제목, 알림 내용), ...])"""
        res = send_daemon_cmd({"cmd": "get_state"})
        if not (res and res.get("status") == "ok"):
            if self.online is not False:
                log.warning("데몬에 연결할 수 없습니다 (%s). 'sudo systemctl status snhpiguard' 로 확인하세요.",
                            SOCKET_PATH)
            self.online = False
            return "offline", "SnhPiGuard - 데몬 연결 안 됨", []
        if self.online is False:
            log.info("데몬 연결이 복구되었습니다.")
        self.online = True

        st = res.get("state", {})
        q_list = st.get("quarantine_list", [])
        ev_list = st.get("protection_events", [])
        cur_q = {i.get("id") for i in q_list}
        cur_ev = {e.get("id") for e in ev_list}
        notes = []

        if not self.baseline_done:
            # 트레이가 시작되기 전에 이미 있던 항목은 알리지 않는다
            self.baseline_done = True
        else:
            new_q = [i for i in q_list if i.get("id") not in self.known_q]
            new_ev = [e for e in ev_list if e.get("id") not in self.known_ev]

            if new_q:
                self.alert = True
                self.alert_title = "SnhPiGuard - 위협 %d건 격리됨!" % len(new_q)
                for i in new_q:
                    notes.append(("SnhPiGuard 위협 탐지",
                                  "[%s] %s 격리 완료" % (i.get("sig", "알 수 없음"), i.get("original_path", ""))))

            for e in new_ev:
                decision = e.get("decision")
                if decision == "denied" and e.get("action") == "delete":
                    self.alert = True
                    self.alert_title = "SnhPiGuard - 삭제된 파일을 복구하지 못했습니다!"
                    notes.append(("보호된 폴더 - 복구 실패",
                                  "%s 복구할 그림자 사본이 없습니다." % e.get("path", "")))
                elif decision == "denied":
                    self.alert = True
                    self.alert_title = "SnhPiGuard - 보호된 폴더 접근 차단됨!"
                    notes.append(("보호된 폴더 접근 차단",
                                  "%s -> %s" % (e.get("process", ""), e.get("path", ""))))
                elif decision == "restored":
                    notes.append(("보호된 폴더 - 삭제 복구",
                                  "%s 삭제가 취소되고 복구되었습니다." % e.get("path", "")))

        self.known_q, self.known_ev = cur_q, cur_ev

        if self.alert:
            return "alert", self.alert_title, notes
        if st.get("is_scanning"):
            tip = "SnhPiGuard - 검사 중 (%s)" % st.get("current_job", "")
        elif st.get("smart_active"):
            tip = "SnhPiGuard - 실시간 감시 중 (%s)" % st.get("smart_target", "")
        elif st.get("protection_active"):
            tip = "SnhPiGuard - 보호된 폴더 액세스 활성"
        else:
            tip = "SnhPiGuard (대기 중)"
        return "ok", tip, notes


def run_headless(watcher):
    """트레이 아이콘을 못 띄우는 환경: 아이콘 없이 알림만이라도 계속 보낸다."""
    log.error("트레이 아이콘 없이 '알림 전용 모드'로 실행합니다. "
              "원인/해결: python3 %s --diagnose", os.path.abspath(__file__))
    while True:
        try:
            _, _, notes = watcher.poll_once()
            for title, msg in notes:
                notify(title, msg)
        except Exception:
            log.exception("상태 확인 중 오류 (계속 진행)")
        time.sleep(POLL_INTERVAL_SEC)


# --------------------------------------------------------------------------
#  트레이 앱
# --------------------------------------------------------------------------
class TrayApp:
    def __init__(self, pystray_mod, backend):
        self.pystray = pystray_mod
        self.backend = backend
        self.watcher = Watcher()
        self.quit_requested = False
        self.gui_proc = None
        self.cur_state = "ok"
        self.cur_tip = "SnhPiGuard (대기 중)"
        self.icon = pystray_mod.Icon(
            "snhpiguard",
            make_icon_image("ok"),
            self.cur_tip,
            menu=self._build_menu(),
        )

    def _build_menu(self):
        Item = self.pystray.MenuItem
        Menu = self.pystray.Menu
        # xorg 백엔드는 기본(default) 항목만 동작하므로 '열기'를 기본 항목으로 지정한다
        return Menu(
            Item("SnhPiGuard 열기", lambda: self.open_gui(), default=True),
            Item("빠른 검사 실행", lambda: self.quick_scan()),
            Item("경고 확인 (아이콘 초기화)", lambda: self.clear_alert()),
            Item("알림 테스트", lambda: notify("SnhPiGuard", "알림이 정상적으로 표시됩니다.", "normal")),
            Menu.SEPARATOR,
            Item("트레이 종료", lambda: self.quit()),
        )

    # ----- 메뉴 동작 -----
    def open_gui(self):
        if self.gui_proc is not None and self.gui_proc.poll() is None:
            return   # 이미 열려 있음
        try:
            proc = subprocess.Popen([sys.executable, GUI_SCRIPT],
                                    stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
        except Exception:
            log.exception("GUI 실행 실패")
            return
        self.gui_proc = proc

        def _wait():
            _, err = proc.communicate()
            if proc.returncode:
                log.warning("GUI가 비정상 종료했습니다 (code=%s): %s",
                            proc.returncode, (err or "").strip()[-600:])
        threading.Thread(target=_wait, daemon=True).start()

    def quick_scan(self):
        def _run():
            res = send_daemon_cmd({"cmd": "start_scan", "targets": QUICK_SCAN_DIRS, "label": "빠른 검사"})
            if res is None:
                notify("SnhPiGuard", "데몬에 연결할 수 없습니다.", "normal")
            elif res.get("status") == "error":
                notify("SnhPiGuard", res.get("msg", "검사를 시작하지 못했습니다."), "normal")
        threading.Thread(target=_run, daemon=True).start()

    def clear_alert(self):
        self.watcher.clear_alert()
        self.apply("ok", "SnhPiGuard (대기 중)", [])

    def quit(self):
        self.quit_requested = True
        self.icon.stop()

    # ----- 아이콘 갱신 -----
    def _set_icon(self, state):
        self.icon.icon = make_icon_image(state)

    def _set_title(self, tip):
        self.icon.title = tip

    def apply(self, state, tip, notes):
        for title, msg in notes:
            notify(title, msg)
        if state != self.cur_state:
            self.cur_state = state
            ui_call(self.backend, self._set_icon, state)
        if tip != self.cur_tip:
            self.cur_tip = tip
            ui_call(self.backend, self._set_title, tip)

    def poll_loop(self):
        while not self.quit_requested:
            try:
                state, tip, notes = self.watcher.poll_once()
                self.apply(state, tip, notes)
            except Exception:
                log.exception("상태 확인 중 오류 (계속 진행)")
            time.sleep(POLL_INTERVAL_SEC)

    def run(self):
        def setup(icon):
            icon.visible = True
            log.info("트레이 아이콘 표시 요청 완료 (backend=%s, session=%s)",
                     self.backend, os.environ.get("XDG_SESSION_TYPE"))
            threading.Thread(target=self.poll_loop, name="snhpiguard-poll", daemon=True).start()

        self.icon.run(setup=setup)


# --------------------------------------------------------------------------
#  진단: python3 snhpiguard_tray.py --diagnose
# --------------------------------------------------------------------------
def diagnose():
    wayland = is_wayland()
    desktop = os.environ.get("XDG_CURRENT_DESKTOP", "")
    problems = []

    print("=== SnhPiGuard 트레이 진단 ===")
    print("\n[세션]")
    for key in ("XDG_SESSION_TYPE", "XDG_CURRENT_DESKTOP", "DISPLAY", "WAYLAND_DISPLAY",
                "XDG_RUNTIME_DIR", "DBUS_SESSION_BUS_ADDRESS"):
        print("  %-26s: %s" % (key, os.environ.get(key) or "(없음)"))
    if not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
        problems.append("그래픽 세션(DISPLAY/WAYLAND_DISPLAY)이 없습니다. 데스크톱에 로그인한 터미널에서 실행하세요.")
    if not os.environ.get("DBUS_SESSION_BUS_ADDRESS"):
        problems.append("D-Bus 세션 버스를 찾지 못했습니다(트레이/알림 모두 D-Bus 필요).")

    print("\n[의존성]")
    print("  Pillow(PIL)               : %s" % ("OK" if PIL_OK else "없음"))
    if not PIL_OK:
        problems.append("Pillow가 없습니다 -> sudo apt install python3-pil")

    try:
        import importlib.metadata as md
        pver = md.version("pystray")
    except Exception:
        pver = None
    print("  pystray                   : %s" % (pver or "설치 안 됨"))
    if not pver:
        problems.append("pystray가 없습니다 -> sudo pip3 install --break-system-packages pystray")

    def typelib(ns, ver):
        try:
            import gi
            gi.require_version(ns, ver)
            return True
        except Exception:
            return False

    have_gtk = typelib("Gtk", "3.0")
    have_ayatana = typelib("AyatanaAppIndicator3", "0.1")
    have_legacy = typelib("AppIndicator3", "0.1")
    print("  python3-gi + Gtk 3.0      : %s" % ("OK" if have_gtk else "없음"))
    print("  AyatanaAppIndicator3      : %s" % ("OK" if have_ayatana else "없음"))
    print("  AppIndicator3(구버전)     : %s" % ("OK" if have_legacy else "없음"))
    if not (have_ayatana or have_legacy):
        problems.append("AppIndicator 라이브러리가 없습니다 -> "
                        "sudo apt install python3-gi gir1.2-gtk-3.0 gir1.2-ayatanaappindicator3-0.1")

    print("\n[pystray 백엔드 로드 시험]")
    working = []
    for name in ("appindicator", "gtk", "xorg"):
        mod, _, fails = load_pystray([name], quiet=True)
        if mod is not None:
            working.append(name)
            print("  %-13s: 로드 가능" % name)
        else:
            print("  %-13s: 불가 (%s)" % (name, fails[0][1][:110]))
    if not working:
        problems.append("사용 가능한 트레이 백엔드가 하나도 없습니다.")
    elif wayland and "appindicator" not in working:
        problems.append("Wayland 세션에서는 appindicator 백엔드만 아이콘이 보입니다 "
                        "(gtk/xorg 백엔드는 로드돼도 아이콘이 안 뜸).")

    print("\n[트레이 호스트(패널)]")
    sni = sni_watcher_present()
    print("  StatusNotifierWatcher     : %s" % (
        "있음" if sni else ("없음" if sni is False else "확인 불가(gdbus 없음/세션 버스 없음)")))
    if sni is False:
        if "GNOME" in desktop.upper():
            problems.append("GNOME 에는 AppIndicator 확장이 필요합니다 -> "
                            "sudo apt install gnome-shell-extension-appindicator 후 로그아웃/로그인")
        elif wayland:
            problems.append("패널이 StatusNotifier(AppIndicator) 트레이를 지원하지 않는 것으로 보입니다. "
                            "(라즈베리파이 OS 라면 raspi-config 에서 Wayland 대신 X11 세션으로 전환하면 "
                            "트레이가 표시됩니다 / OS 버전에 따라 메뉴 이름이 다릅니다)")

    print("\n[알림/데몬/프로세스]")
    print("  notify-send               : %s" % (shutil.which("notify-send") or "없음"))
    if not shutil.which("notify-send"):
        problems.append("notify-send 가 없습니다 -> sudo apt install libnotify-bin")
    res = send_daemon_cmd({"cmd": "get_state"})
    daemon_ok = bool(res and res.get("status") == "ok")
    print("  데몬 연결 (%s): %s" % (SOCKET_PATH, "OK" if daemon_ok else "실패"))
    if not daemon_ok:
        problems.append("데몬에 연결할 수 없습니다 -> sudo systemctl status snhpiguard")
    running = tray_already_running()
    print("  트레이 프로세스           : %s" % (
        "실행 중" if running else ("실행 중 아님" if running is False else "확인 불가")))

    print("\n[최근 트레이 로그] %s" % LOG_FILE)
    try:
        with open(LOG_FILE, "r", encoding="utf-8", errors="replace") as f:
            for line in f.read().splitlines()[-12:]:
                print("  " + line)
    except OSError:
        print("  (로그 없음)")

    print("\n[진단 결과]")
    if problems:
        for n, p in enumerate(problems, 1):
            print("  %d) %s" % (n, p))
        return 1
    print("  뚜렷한 문제는 없습니다. 그래도 아이콘이 안 보이면 위 '최근 트레이 로그'를 확인하세요.")
    return 0


# --------------------------------------------------------------------------
def main():
    setup_logging()
    ensure_session_env()

    if "--diagnose" in sys.argv[1:]:
        sys.exit(diagnose())

    if not acquire_lock():
        log.info("이미 실행 중인 SnhPiGuard 트레이가 있어 이번 실행은 종료합니다.")
        return

    log.info("=== SnhPiGuard Tray 시작 pid=%s session=%s DISPLAY=%s WAYLAND_DISPLAY=%s DBUS=%s ===",
             os.getpid(), os.environ.get("XDG_SESSION_TYPE"), os.environ.get("DISPLAY"),
             os.environ.get("WAYLAND_DISPLAY"), bool(os.environ.get("DBUS_SESSION_BUS_ADDRESS")))

    if not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
        log.error("그래픽 세션(DISPLAY/WAYLAND_DISPLAY)을 찾지 못해 종료합니다. 데스크톱 로그인 후 다시 실행하세요.")
        sys.exit(2)

    time.sleep(STARTUP_DELAY_SEC)

    pystray_mod, backend = None, None
    if not PIL_OK:
        log.error("Pillow(python3-pil)가 없어 트레이 아이콘을 만들 수 없습니다 -> sudo apt install python3-pil")
    else:
        pystray_mod, backend, failures = load_pystray(backend_order())
        if pystray_mod is None:
            log.error("사용 가능한 트레이 백엔드가 없습니다. 시도 결과: %s",
                      "; ".join("%s -> %s" % f for f in failures))
            log.error("해결: sudo apt install python3-gi gir1.2-gtk-3.0 gir1.2-ayatanaappindicator3-0.1 "
                      "(이후 sudo pip3 install --break-system-packages -U pystray)")

    watcher = Watcher()
    if pystray_mod is not None:
        if is_wayland() and backend != "appindicator":
            log.warning("Wayland 세션에서 '%s' 백엔드는 아이콘이 보이지 않습니다. "
                        "gir1.2-ayatanaappindicator3-0.1 설치가 필요합니다.", backend)
        elif backend == "appindicator" and sni_watcher_present() is False:
            log.warning("StatusNotifierWatcher(트레이 호스트)가 세션에 없습니다. 패널이 AppIndicator 트레이를 "
                        "지원하지 않으면 아이콘이 보이지 않습니다 (X11 세션에서는 보통 자동 대체됨).")
        app = TrayApp(pystray_mod, backend)
        watcher = app.watcher
        try:
            app.run()
            if app.quit_requested:
                log.info("사용자가 트레이를 종료했습니다.")
                return
            log.warning("트레이 루프가 예기치 않게 끝났습니다 - 알림 전용 모드로 전환합니다.")
        except Exception:
            log.exception("트레이 실행 중 오류 - 알림 전용 모드로 전환합니다.")

    run_headless(watcher)


if __name__ == "__main__":
    main()
PYEOF

chmod +x "${INSTALL_DIR}/snhpiguard_tray.py"
chown -R "$REAL_USER":"$REAL_USER" "$INSTALL_DIR"

echo "=== 8/9: Systemd 서비스 등록 ==="
SERVICE_FILE="/etc/systemd/system/snhpiguard.service"
cat > "$SERVICE_FILE" << SERVICE_EOF
[Unit]
Description=SnhPiGuard Dual-Engine Antivirus Daemon
After=network.target clamav-daemon.service

[Service]
Type=simple
Environment=SNHPIGUARD_REAL_USER=${REAL_USER}
ExecStart=/usr/bin/python3 ${INSTALL_DIR}/snhpiguard_daemon.py
Restart=always
User=root

[Install]
WantedBy=multi-user.target
SERVICE_EOF

systemctl daemon-reload
systemctl enable snhpiguard.service
systemctl restart snhpiguard.service

echo "=== 9/9: 트레이 자동 시작 및 바탕화면 바로가기 등록 ==="
mkdir -p "${REAL_HOME}/.config/autostart" "${REAL_HOME}/Desktop"

cat > "$AUTOSTART_TRAY_FILE" << TRAY_EOF
[Desktop Entry]
Type=Application
Name=SnhPiGuard Tray
Comment=Dual-Engine (YARA + ClamAV) 백신 - 백그라운드 위협 알림 + 보호된 폴더
Exec=/usr/bin/python3 ${INSTALL_DIR}/snhpiguard_tray.py
Icon=security-high
X-GNOME-Autostart-enabled=true
Terminal=false
TRAY_EOF
chown "$REAL_USER":"$REAL_USER" "$AUTOSTART_TRAY_FILE"

cat > "$DESKTOP_SHORTCUT_FILE" << SHORTCUT_EOF
[Desktop Entry]
Type=Application
Name=SnhPiGuard
Comment=Dual-Engine (YARA + ClamAV) 백신 + 보호된 폴더 액세스
Exec=/usr/bin/python3 ${INSTALL_DIR}/snhpiguard_gui.py
Icon=security-high
Terminal=false
SHORTCUT_EOF
chmod +x "$DESKTOP_SHORTCUT_FILE"
chown "$REAL_USER":"$REAL_USER" "$DESKTOP_SHORTCUT_FILE"
sudo -u "$REAL_USER" gio set "$DESKTOP_SHORTCUT_FILE" metadata::trusted true 2>/dev/null || true

# --- 트레이 즉시 실행 + 진단 ---------------------------------------------------
# 트레이는 세션 환경(XDG_RUNTIME_DIR, D-Bus, Wayland/X11)을 스스로 찾아 보정하므로
# XDG_RUNTIME_DIR 만 넘겨서 로그인 사용자 권한으로 실행한다.
REAL_UID=$(id -u "$REAL_USER")
as_user() {
    if [[ "$REAL_USER" == "$(id -un)" ]]; then
        "$@"
    else
        sudo -u "$REAL_USER" "$@"
    fi
}

# 이전 버전 트레이가 떠 있으면 종료 (새 버전으로 교체)
pkill -u "$REAL_UID" -f "snhpiguard_tray.py" 2>/dev/null || true
sleep 1

if [[ -d "/run/user/${REAL_UID}" ]]; then
    as_user env XDG_RUNTIME_DIR="/run/user/${REAL_UID}" \
        setsid nohup /usr/bin/python3 "${INSTALL_DIR}/snhpiguard_tray.py" \
        > /var/log/snhpiguard/tray_launch.log 2>&1 &
    echo "  트레이를 시작했습니다. 패널이 준비될 때까지 잠시 기다립니다..."
    sleep 7
    echo ""
    as_user env XDG_RUNTIME_DIR="/run/user/${REAL_UID}" \
        /usr/bin/python3 "${INSTALL_DIR}/snhpiguard_tray.py" --diagnose || \
        echo "  → 위 진단의 '문제점' 항목을 확인하세요."
else
    echo "  [!] 그래픽 로그인 세션이 없어 지금은 트레이를 시작하지 않습니다 (다음 로그인부터 자동 실행)."
fi

echo ""
echo "================================================="
echo " SnhPiGuard Dual-Engine + 보호된 폴더 액세스 설치 완료!"
echo " - 위협 탐지 시 트레이 아이콘이 빨간색으로 바뀌고 알림이 표시됩니다."
echo " - '보호된 폴더' 버튼에서 폴더를 등록하고 보호를 켜면,"
echo "   등록되지 않은 프로그램이 그 폴더의 파일을 수정/생성할 때마다"
echo "   '파일 이름: ... [확인]/[취소]' 확인창이 뜨고, [확인]을 눌러야"
echo "   실제로 수정이 이루어집니다."
echo " - 삭제는 리눅스 커널 구조상 사전 차단이 불가능하여, 삭제가"
echo "   감지된 즉시 복구 여부를 묻는 확인창이 뜨는 방식으로 동작합니다."
echo ""
echo " [트레이 아이콘이 안 보일 때]"
echo "   1) 로그아웃 후 다시 로그인"
echo "   2) python3 ${INSTALL_DIR}/snhpiguard_tray.py --diagnose   (원인 진단)"
echo "   3) 로그 확인: ${REAL_HOME}/.cache/snhpiguard/tray.log"
echo "================================================="